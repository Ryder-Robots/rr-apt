// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_CORTEX_TRANSPORT_HPP
#define RR_EMOD_SERDE_CORTEX_TRANSPORT_HPP

#include <chrono>
#include <optional>

#include <rr_emod_serde/rr_cortex_receiver.hpp>
#include <rr_emod_serde/rr_emod_types.hpp>

#include <common/inferenceio.pb.h>

namespace cortex_serde {

// MOVED to rr_emod_types.hpp (2026-08-02), where the value and its rationale now
// live. The connect plane has to declare this number in its OpenChannel, and
// making it include a session-layer interface to learn it was backwards — a leaf
// types header is the right home for a constant both planes state.
//
// This is a using-declaration, NOT a second definition: one value, one place to
// bump. Kept so `cortex_serde::kProtocolVersion` (named canonical by
// connectio.proto and used by cortex_port.cpp) still resolves.
using rr_emod_types::kProtocolVersion;

/**
 * The session-layer seam under CortexPort: carry one request envelope to the
 * brain, own the wait, hand back the answer.
 *
 * ASYMMETRY, DELIBERATE — envelope in, raw result out. Requests rehearse the
 * wire shape; responses do not need to (the rule stated in
 * rr_cortex_receiver.hpp): the in-process brain never builds an EngramResult
 * proto — respond() delivers a raw InferenceMemResult into the mailbox — so
 * a response-envelope interface would force Engram serialization into
 * existence purely to cross an in-process seam. Instead the interface
 * returns the session-layer type. A remote implementation deserializes
 * EngramResult -> InferenceMemResult INSIDE its own exchange(); the
 * interface holds unchanged.
 *
 * CONTRACT:
 *   - Blocks up to `timeout` for the answer.
 *   - nullopt = no answer arrived (timeout, or mailbox closed for lifecycle
 *     reasons). Never a fault: the port maps this to OK + disengaged.
 *   - An engaged result is handed back verbatim — correlation checking and
 *     status mapping are the PORT's job, not the transport's. The transport
 *     moves; the port judges.
 *
 * IMPLEMENTATIONS:
 *   - Harness (now): a Python subclass via nanobind trampoline, wiring
 *     receive(envelope) -> control-loop tick -> mailbox pop_wait for the
 *     parity rig. (Harness notes: the pop_wait binding
 *     must release the GIL or a parked port starves every Python thread,
 *     and the trampoline must override all THREE virtuals — a Python
 *     subclass that forgets close()/reopen() dies at instantiation, not
 *     silently at lifecycle time.)
 *   - Production (next): an in-process implementation wrapping a minted
 *     CortexReceiver — at which point the transport owns minted identity and
 *     the port's scaffold ChannelId retires.
 *   - Remote (later): a gRPC client stub; identity granted at connection
 *     open, version check enforced there.
 */
class CortexTransport {
public:
    virtual ~CortexTransport() = default;

    virtual std::optional<rr_emod_serde::InferenceMemResult> exchange(
        rr_inference::CortexEnvelope request,
        std::chrono::milliseconds timeout) = 0;

    // Session teardown / re-arm — the MECHANISM half of the lifecycle plane.
    // The AUTHORITY is the brain (LifecycleCommand over the wire); these are
    // invoked by the cortex-side reaction path (CortexPort::close/reopen,
    // themselves driven by handle_lifecycle), never by the DNN.
    //
    // CONTRACT:
    //   - close(): any exchange() currently parked in this transport wakes
    //     and returns nullopt (the port maps that to OK + disengaged); once
    //     closed, further exchange() calls return nullopt immediately — no
    //     parking against a dead session. Idempotent.
    //   - reopen(): re-arms after a DEACTIVATE pause. Idempotent. After a
    //     SHUTDOWN the session is gone and reactivation is RECONNECTION —
    //     whether reopen() can revive it is the implementation's business;
    //     refusing (exchange keeps returning nullopt) is a valid answer.
    //   - Both may be called from a thread other than the one parked in
    //     exchange() — that is the point.
    virtual void close() = 0;
    virtual void reopen() = 0;
};

}  // namespace cortex_serde

#endif  // RR_EMOD_SERDE_CORTEX_TRANSPORT_HPP
