// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_BERT_ENCODER_HPP
#define RR_EMOD_SERDE_RR_BERT_ENCODER_HPP

#include <Eigen/Dense>
#include <cstddef>
#include <memory>

#include <rr_emod_serde/rr_emod_types.hpp>

namespace rr_emod_serde {
class BertEncoder {
public:
    virtual ~BertEncoder() = default;

    virtual Eigen::VectorXf encode(const rr_emod_types::MessageFrame& msg_payload) = 0;
    virtual rr_emod_types::MessageFrame decode(const rr_emod_types::Engram& engram) = 0;

    // No state() here by design. An encoder has no lifecycle, so it has no health to
    // report — it reports an outcome, on the value it hands back: decode() stamps its
    // condition onto the frame's `diagnostic`, which the gates and the supervisor read.
    //
    // encode() has no equivalent yet. An encoder whose model failed to load returns a
    // zero vector that the caller cannot tell from a real embedding.

    BertEncoder(const BertEncoder&) = delete;
    BertEncoder& operator=(const BertEncoder&) = delete;
    BertEncoder(BertEncoder&&) = default;
    BertEncoder& operator=(BertEncoder&&) = default;

protected:
    BertEncoder() = default;
};

// TODO: The value is chosen at compile time in CMakeLists.txt file. One CPP
// file, so that the LLVMs optimiser will optimise the whole thing out, and
// reduce indirection logic. During the development phase this can
// be either TFLite-CPU / TFLite-Coral but for the eModule it will be
// TFLite-Coral, or another TPU implementation, therefore nothing else
// is needed
std::unique_ptr<BertEncoder> make_bert_encoder();
}  // namespace rr_emod_serde

#endif  // RR_EMOD_SERDE_RR_BERT_ENCODER_HPP
