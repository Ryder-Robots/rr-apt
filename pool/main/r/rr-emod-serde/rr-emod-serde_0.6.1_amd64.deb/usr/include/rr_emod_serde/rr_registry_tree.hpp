// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_REGISTRY_TREE_HPP
#define RR_EMOD_SERDE_RR_REGISTRY_TREE_HPP

#include <memory>

#include <rr_emod_serde/rr_emod_types.hpp>
#include <rr_emod_serde/rr_lc.hpp>
#include <rr_emod_serde/rr_lc_registry.hpp>

namespace rr_emod_lc {

/**
 * Moves every registered node through one transition, in order.
 *
 * This is the only thing that walks a set of nodes, which is why a node never
 * has to know it is in one. The walk is a flat pass over the registry's view:
 * forward to bring the set up, the same pass backwards to wind it down.
 * Nothing here calls itself, and no node reaches another.
 *
 * Direction is derived from the transition rather than chosen by the caller,
 * so one place decides it and there is no way to ask for a teardown applied in
 * bring-up order.
 *
 * The registry is held privately and never handed on. That is what keeps a
 * view of raw node pointers out of reach of anything with no business moving
 * them.
 */
class RrRegistryTree {
public:
    explicit RrRegistryTree(std::unique_ptr<RrRegistry> registry);
    ~RrRegistryTree() = default;

    RrRegistryTree(const RrRegistryTree&) = delete;
    RrRegistryTree& operator=(const RrRegistryTree&) = delete;
    RrRegistryTree(RrRegistryTree&&) = delete;
    RrRegistryTree& operator=(RrRegistryTree&&) = delete;

    /**
     * Apply one transition to every node. The result is the worst any single
     * node reported; the pass always runs to the end, so one node in trouble
     * does not strand the ones behind it.
     */
    [[nodiscard]] rr_emod_types::DiagnosticState transition(LcState state);
    [[nodiscard]] const RrRegistry& registry() const {return *reg_;}

private:
    std::unique_ptr<RrRegistry> reg_;
};
}  // namespace rr_emod_lc

#endif  // RR_EMOD_SERDE_RR_REGISTRY_TREE_HPP
