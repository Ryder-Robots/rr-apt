// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <fstream>
#include <ios>

namespace rr_emod_serde {

class RrFstreamProxy {
public:
    virtual ~RrFstreamProxy() = default;

    virtual void open(const char* filename, std::ios_base::openmode mode) = 0;
    virtual void close() = 0;

    virtual void seekg(std::streampos pos) = 0;
    virtual void seekg(std::streamoff off, std::ios_base::seekdir dir) = 0;

    virtual void seekp(std::streampos pos) = 0;
    virtual void seekp(std::streamoff off, std::ios_base::seekdir dir) = 0;

    virtual std::streampos tellg() = 0;
    virtual std::streampos tellp() = 0;

    virtual void read(char* buf, std::streamsize size) = 0;
    virtual void write(const char* buf, std::streamsize size, bool retry = false) = 0;

    virtual bool good() const = 0;
    virtual bool fail() const = 0;
    virtual bool eof() const = 0;
    virtual bool is_open() const = 0;

    virtual void clear() = 0;

    virtual bool getline(std::string& line) = 0;
};

}  // namespace rr_emod_serde