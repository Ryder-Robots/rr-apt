// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
#pragma once

// One end of one channel on the connection plane: bind / listen / accept for a
// server, connect for a client, send for either. The C++ CONTRACT for
// connectio.proto's handshake — a dialer opens a channel, an accepting socket
// grants exactly ONE peer on it, and the binding it grants is held for the whole
// service life.
//
// AN INTERFACE, DELIBERATELY — the same choice CortexTransport makes, and for
// the same reasons. The accept-end mechanism is exactly the thing we are least
// sure of: gRPC looks right, but "looks right" is not "is right". An abstract
// seam lets gRPC be ONE implementation rather than THE implementation — if it
// proves wrong, you add a class, you do not rewrite this one. It also keeps the
// Python binding pointed at a stable contract while the mechanism underneath
// moves.
//
// BOTH ENDS, ONE TYPE (Aaron, 2026-07-31 — supersedes the former "SERVER SIDE
// ONLY" rule). The role split is PER PLANE, not per machine:
//
//   VISION, PROPRIOCEPTION are pure AFFERENCE. Light arrives; you do not emit
//     it. The body observes itself. One direction, cortex -> frontal, so one
//     CLIENT on the cortex and one SERVER on the frontal.
//   AUDIO, EXTEROCEPTION, TEXT, PEER are BOUNDARIES with something outside the
//     body: you hear and you speak, you touch and you push, you are addressed
//     and you answer. Reciprocal, so a SERVER at BOTH ends and two sockets per
//     end — CLIENT->SERVER each way.
//
// The majority is reciprocal, which is why the frontal cannot be a thing that
// only answers. A server that can only respond is a peripheral: the frontal
// would be able to speak solely while a cortex held a call open, and "move
// forward" waits on nothing. That dependency inversion is the whole reason a
// cortex runs a server too.
//
// UNIFORM ANYWAY, even for the afferent channels (Aaron, 2026-07-31): identical
// framework on every cortex board is what makes them HOT-SWAPPABLE on fault.
// Conformity is worth more than the two sockets it saves.
//
// ADDRESSING IS ONE-LEVEL: a ChannelId, and nothing else. (Decided 2026-07-31.)
// The two-level (Region, channel) CortexAddress was cut. Region had exactly one
// live value forever — the reserved names each turn out to want their own type
// rather than a slot on this axis — and hippocampus traffic arrives as commands
// through the frontal, never as a dial. A reserved axis that nothing will ever
// occupy is not an axis. With one socket per channel per role the socket already
// knows which channel it is, so CortexAddress carried nothing a ChannelId did
// not. The proto's region / granted_region fields go `reserved`.
//
// MEMORY IS A CHANNEL (Aaron, 2026-07-31). ChannelId::MEMORY sits past COUNT: a
// SERVICE, not a sense — no payload slot, no mask bit, no gate slot. It gets its
// own socket for the same reason the senses do, so a slow engram lookup cannot
// stall a sense. It is the ONE channel where one-peer-per-channel does NOT
// apply: many cortexes may hold it at once, and concurrency is raised by adding
// connections. The frontal serves one engram at a time regardless of how the
// request arrived, so nothing is lost by isolating it — and the pressure
// dissolves as cortexes train up and ask less. This is why the socket no longer
// knows what an InferenceMemoryIO is (see RrSockOpts).
//
// WHY MULTI-LISTENER — one socket per channel, not one listener for all of
// them. Two reasons, one structural, one capability:
//   1. All cortexes connect at once at startup (those that are present). A
//      single listener serialises that storm in an accept backlog; N sockets let
//      the only serialisation be hardware concurrency (a small routing chip on
//      the server does the fan-out, its software stand-in the rendezvous
//      registry below).
//   2. Because each listener is its own endpoint, ONE physical cortex CM5 can
//      host several DNNs side by side, each bound to its own channel. The board
//      is no longer one-model-per-machine. (Aaron, 2026-07-30.)
// The consequence names itself: "address in use" IS the one-peer-per-channel
// invariant, structural rather than policed — CONN_STATUS_ADDRESS_IN_USE.
//
// THREE NESTED LIFETIMES, DO NOT BLUR:
//   MAILBOX / IO  — brain lifetime. The mailboxes and gate slots are address-
//                   stable and exist before any cortex dials; they outlive every
//                   connection made to them.
//   CONNECTION    — accept ONCE, held until shutdown / critical failure.
//   SESSION       — the mailbox close()/reopen() on DEACTIVATE/ACTIVATE, MANY
//                   times, on a connection that never dropped.
// accept() does NOT create a mailbox — it creates a BINDING to one already
// there. That is why accept() cannot fail for want of a resource, and why
// reopen() can never re-accept: it acts on something that existed before the
// connection did. Recovery from a lost connection is a fresh service lifetime
// with a fresh accept, never an in-band re-open. This seam owns only the
// establishment; the session pause/resume is the transport's close()/reopen(),
// elsewhere.
//
// A FOURTH LIFETIME IS FORBIDDEN. Every call on this plane is UNARY — request,
// response, done. A gRPC stream would be a fourth lifetime nested inside
// CONNECTION, with its own failure and re-establishment semantics, and it would
// put the frontal's ability to speak at the mercy of a cortex keeping a stream
// open. Push is achieved by the peer running its own server, never by holding a
// channel open.
//
// NO STARTUP BARRIER — A DEGRADED RUN IS NORMAL. (Aaron, 2026-07-31.) The brain
// runs with channels missing, and often will; an absent cortex must never be
// fatal. So the supervisor binds and arms every socket and proceeds to run state
// immediately — it does NOT wait for grants, because "never" is a legitimate
// outcome for any given channel. Connections land whenever they land: on gRPC's
// handler thread remotely, via the rendezvous locally. Nothing in production is
// ever parked in accept(); its blocking form is for tests and the local rig.
// The data path costs nothing for an absent peer — a write to a channel nobody
// holds is a silent no-op by construction. A missing channel is still a fault
// worth reporting: it should raise a sticky non-fatal DiagnosticState::WTF. That
// needs a deadline (there is no event for "a cortex did not dial"), and a
// deadline is a separate-box concern — DEFERRED, not designed here. When it
// lands, note that the WTF must NOT disarm the socket: a cortex arriving late
// still gets its normal accept-once grant.
//
// THREE PLACES ADDRESS_IN_USE CAN ARISE, AND THEY ARE NOT THE SAME FAULT.
// Today they would collapse into one signal; splitting them is the whole point
// of checking at bind (Aaron, 2026-07-31 — replicate the C behaviour, where bind
// is what fails with EADDRINUSE):
//   bind()   — another socket IN THIS PROCESS already claimed this (channel,
//              role). A wiring bug, and at the Python binding level a realistic
//              USER error rather than a theoretical one. Fix the code.
//   listen() — something OUTSIDE this process holds the endpoint: a second brain
//              instance, a stale process, an ephemeral-port grab. Fix the
//              environment. (Under gRPC this is where the OS bind actually
//              happens — see listen() below.)
//   accept() — this socket has already granted its one peer; a second cortex
//              dialled a live channel. The invariant working as intended.
//              (Exempt for ChannelId::MEMORY, which is many-peer.)
// Only accept()'s goes on the wire, as an ack to a dialer; the other two are
// startup failures that never reach a client. They share the ConnStatus
// vocabulary deliberately — one status language, not three — so THE LOG LINES AT
// EACH SITE MUST BE DISTINCT. The value of the split is diagnostic, and it is
// lost entirely if all three print "address in use" on a board at boot.
//
// IMPLEMENTATIONS:
//   - Local (now): RrCortexSocketLocal — in-process; the rendezvous registry
//     stands in for the wire. The §4 parity rig runs on this.
//   - Remote (later): a gRPC server (SERVER role) or stub (CLIENT role). The
//     mapping is known and the beats survive contact with it (noted at each
//     method below); the endpoint derivation, the wire-version gate and the
//     missing-channel deadline are all separate-box concerns and are DEFERRED —
//     do not build them here.
//   - Test: a fake that runs the handler directly, for exercising callers
//     without a socket layer.

#include <cstdint>
#include <functional>
#include <optional>

#include <rr_emod_serde/rr_emod_types.hpp> 

#include <common/inferenceio.pb.h>
#include <conn/connectio.pb.h>

namespace rr_emod_serde {

/**
 * RrSockFlags — what KIND of socket this is, in the shape C's socket() takes a
 * type. (Aaron, 2026-07-31.)
 *
 * SERVER and CLIENT are MUTUALLY EXCLUSIVE on one socket — one role per socket,
 * one socket per slot. A reciprocal channel is TWO sockets, not one socket with
 * both bits; setting both is a wiring bug and bind() must refuse it. That is
 * what keeps "which direction is this?" answerable by looking at the object
 * rather than by inferring it from which methods got called.
 *
 * The role decides which beats are legal:
 *   SERVER — bind() then listen() then accept(). Owns an endpoint.
 *   CLIENT — bind() then connect(). Never listens; the far side owns the
 *            endpoint and the connection lifetime.
 * send() is legal on both, and means different things (see send()).
 */
enum class RrSockFlags : uint8_t {
    NONE     = 0x00,
    SERVER   = 0x01,  // passive open: bind -> listen -> accept
    CLIENT   = 0x02,  // active open:  bind -> connect
    NONBLOCK = 0x04,  // accept()/connect() return immediately rather than parking
};

constexpr RrSockFlags operator|(RrSockFlags a, RrSockFlags b) noexcept {
    return static_cast<RrSockFlags>(static_cast<uint8_t>(a) | static_cast<uint8_t>(b));
}
constexpr RrSockFlags operator&(RrSockFlags a, RrSockFlags b) noexcept {
    return static_cast<RrSockFlags>(static_cast<uint8_t>(a) & static_cast<uint8_t>(b));
}
constexpr bool has_flag(RrSockFlags v, RrSockFlags f) noexcept {
    return (static_cast<uint8_t>(v) & static_cast<uint8_t>(f)) != 0;
}

// The ROLE alone, with NONBLOCK and anything later stripped off.
//
// EVERY key and every role test must go through this. RrSockOpts::flags may
// carry NONBLOCK, so SERVER and SERVER|NONBLOCK are DIFFERENT values — key the
// rendezvous on the raw flags and those two become different keys, both claims
// succeed, and the ADDRESS_IN_USE collision this exists to catch walks straight
// past. Returns NONE for no role bit and SERVER|CLIENT for both; both are
// wiring bugs the caller must refuse.
constexpr RrSockFlags role_of(RrSockFlags f) noexcept {
    return f & (RrSockFlags::SERVER | RrSockFlags::CLIENT);
}

/**
 * RrSockHandler — what to do with an envelope that arrives on this channel.
 *
 * THE PROTO IS THE ROUTING TABLE (Aaron, 2026-07-31). A handler switches on
 * req.command_case() and nothing else:
 *
 *     switch (req.command_case()) {
 *       case CortexEnvelope::kEngramQuery:  ... return result;
 *       case CortexEnvelope::kPrompt:       ... return response;
 *       case CortexEnvelope::COMMAND_NOT_SET: ... return std::nullopt;
 *     }
 *
 * WHY A HANDLER AND NOT MAILBOXES. Handing the socket an InferenceMemoryIO and
 * a pair of IOCom slots made the socket know the brain: it had to decide which
 * destination each message belonged to, which is a routing decision expressed
 * twice — once in the proto's oneof and again in a switch inside the transport.
 * With a handler the socket knows only "an envelope arrived, ask the owner".
 * Everything brain-shaped — the memory IO, the gate slots, the mailbox writes —
 * is CAPTURED IN THE CLOSURE by whoever builds the handler (the supervisor, the
 * composition root, the only party that can see across planes). Consequently
 * this header includes no brain type at all, which is what lets the whole
 * library link on a cortex board unchanged.
 *
 * THE RETURN IS OPTIONAL because the channels genuinely differ. MEMORY answers
 * (an EngramQuery has a result); a sensory push does not (a frame is fire-and-
 * forget). std::nullopt means "accepted, nothing to say" and an implementation
 * turns it into an empty OK — never into an error.
 *
 * MUST NOT BLOCK for long. It runs on the receiving thread — gRPC's handler
 * thread remotely, the caller's thread locally — so a handler that waits on the
 * control loop holds a transport thread hostage. MEMORY is the one that will be
 * tempted; if a lookup cannot be answered promptly it should return nullopt and
 * let the answer come back as its own message rather than parking here.
 *
 * MAY RUN CONCURRENTLY on MEMORY (many peers, therefore many threads). Anything
 * it captures must tolerate that. On a sensory channel there is exactly one peer
 * and therefore one caller at a time.
 */
using RrSockHandler = std::function<std::optional<rr_inference::CortexEnvelope>(
        const rr_inference::CortexEnvelope& req)>;

/**
 * RrSockOpts — what bind() takes, in the shape C's bind() takes a sockaddr: the
 * channel to claim, what kind of socket it is, and what to do with what arrives.
 *
 * THREE FIELDS, AND NO BRAIN TYPES (Aaron, 2026-07-31 — supersedes the io/rx/tx
 * form). The former shape carried a shared_ptr<InferenceMemoryIO> and the two
 * gate IOCom slots, which forced this header — and therefore every cortex that
 * included it — to know what a hippocampus is. All three collapse into `handler`,
 * which closes over them at the composition root. What is left is a pure
 * transport descriptor.
 *
 * The channel lives here and nowhere else, so it cannot be stated twice and
 * disagree with itself.
 */
struct RrSockOpts {
    // What to claim. The registry keys on (channel, role); accept() grants the
    // channel as identity. MEMORY is legal here and is the many-peer exception.
    rr_emod_types::ChannelId channel = rr_emod_types::ChannelId::COUNT;

    // Which role, and any modifiers. Defaulted to SERVER because that is the
    // frontal's common case and because a socket with NO role bit is refused.
    RrSockFlags flags = RrSockFlags::SERVER;

    // What to do with an inbound envelope. REQUIRED on a SERVER (a server that
    // cannot answer is not a server); OPTIONAL on a CLIENT that only ever sends
    // and reads the unary response inline. bind() refuses a SERVER with none —
    // failing at bind names the wiring bug at the site that made it, rather than
    // at a dial arriving minutes later.
    RrSockHandler handler;
};

/**
 * RrCortexSocket — the abstract endpoint of one channel, one role.
 *
 * A pure contract: bind claims the channel and states its kind, listen arms a
 * server, accept grants the one peer, connect dials a far server, send speaks.
 * No members here — the wiring arrives through bind()'s RrSockOpts (common to
 * every implementation) and everything else that differs, credentials and
 * endpoints and threads, belongs to the concrete class (RrCortexSocketLocal
 * first; a gRPC one later). Sockets are owned by RrSupervisor (the composition
 * root), which holds them but does not converse over them.
 *
 * THE RENDEZVOUS REGISTRY (settled 2026-07-31; formerly "fork 5"). The
 * supervisor owns a registry of claimed channels, and it is not optional — two
 * decisions require it. First, bind() reports ADDRESS_IN_USE, and nothing but a
 * registry can answer "is this already claimed?" before the OS is involved.
 * Second, accept() takes no argument (below), so something has to deliver the
 * SYN to the right socket: remotely gRPC does that, and locally the registry is
 * gRPC's mirror.
 *
 * IT KEYS ON (ChannelId, role), NOT ChannelId ALONE — a reciprocal channel has
 * a SERVER and a CLIENT socket on the SAME machine for the SAME channel, and on
 * one key they would collide as a spurious ADDRESS_IN_USE at boot. When a remote
 * impl derives an endpoint from the channel it keys on that derived endpoint
 * instead, so a broken derivation mapping two channels onto one endpoint fails
 * HERE, loudly, instead of surfacing later as an indistinguishable listen()-time
 * collision.
 *
 * CONN_STATUS_UNKNOWN_ADDRESS is the registry's status, not a socket's: a SYN
 * for an unclaimed channel is refused before any socket sees it. A socket's own
 * failure modes are only VERSION_MISMATCH and ADDRESS_IN_USE.
 *
 * There is no disconnect() on the contract: dissolution rides the lifecycle
 * plane's SHUTDOWN, not a connection-plane call (connectio.proto leaves teardown
 * deliberately absent).
 */
class RrCortexSocket {
public:
    virtual ~RrCortexSocket() = default;

    // bind(): claim the channel AND state what kind of socket this is (the first
    // beat for BOTH roles; a server then listens, a client then connects). Does
    // NOT itself arm or dial — the owner calls bind() then one of them, the BSD
    // order. Idempotent re-bind to the SAME opts is a no-op; a second DISTINCT
    // bind on a live socket is a wiring bug.
    //
    // TAKES RrSockOpts, in the shape C's bind() takes a sockaddr: a descriptor
    // of the binding, not a bare name. A socket is inert until bound; opts is
    // what makes it a socket ON something.
    //
    // REFUSES, with a distinct log line each:
    //   - no role bit, or BOTH SERVER and CLIENT (one role per socket)
    //   - SERVER with an empty handler (a server that cannot answer)
    //   - a (channel, role) the registry already holds -> ADDRESS_IN_USE
    //
    // RETURNS ConnStatus so that ADDRESS_IN_USE lands here, where C puts it
    // (Aaron, 2026-07-31). The claim is made against the supervisor's registry,
    // the only party that can see across sockets. A genuine guard, not ceremony:
    // it is reachable from the Python binding, where binding one channel twice
    // is an ordinary mistake rather than a hypothetical one.
    //
    // For a gRPC SERVER this is also where the endpoint is described and the
    // service registered — AddListeningPort("0.0.0.0:" + PORT, credentials,
    // &selected_port) then RegisterService(&service) — but note gRPC only
    // RECORDS that intent; it does not touch the OS until BuildAndStart(). How
    // PORT derives from opts.channel, and which interface to bind rather than
    // 0.0.0.0, are separate-box concerns and are not settled here.
    virtual rr_conn::ConnStatus bind(const RrSockOpts& opts) = 0;

    // listen(): the passive open — arms a bound SERVER to accept a dial. Its own
    // beat by decision (Aaron, 2026-07-30): bind claims, listen arms, accept
    // grants. The seam is real, not ceremonial — there is a legitimate
    // claimed-but-not-yet-listening state, and the registry/wire arm step needs
    // somewhere to sit.
    //
    // SERVER ONLY. On a CLIENT socket this is a wiring bug: the far side owns the
    // endpoint. Implementations return CONN_STATUS_ERROR rather than silently
    // succeeding — a client that "listened" would sit waiting for a dial that by
    // construction can never arrive.
    //
    // RETURNS ConnStatus because for a remote impl THIS is where the OS bind
    // actually happens: BuildAndStart() — with AddChannelArgument(
    // GRPC_ARG_ALLOW_REUSEPORT, 0), which makes one-peer-per-endpoint an OS
    // guarantee rather than a software check — is what can fail with a real
    // EADDRINUSE. It does NOT block and does NOT need a thread of ours: gRPC
    // spawns its own serving threads and returns. In-process there is nothing to
    // collide with, so the local impl cannot fail here; the signature exists so
    // the remote impl fits the contract without changing it.
    //
    // ⚠ SIZE THE POOL. gRPC's sync server defaults assume a server-class box;
    // the frontal is a 4-core Pi5 running N of these. SetSyncServerOption
    // NUM_CQS / MIN_POLLERS / MAX_POLLERS must be set explicitly per socket or N
    // listeners will each spin up a default pool and starve cognition.
    virtual rr_conn::ConnStatus listen() = 0;

    // accept(): the ONCE-OFF establishment, SERVER side. Blocks until a peer
    // dials unless RrSockFlags::NONBLOCK was set.
    //
    // TAKES NO ARGUMENT, deliberately (2026-07-31) — as in C, accept does not
    // receive the connection, it RETURNS it. The SYN arrives from the INSIDE:
    // remotely gRPC delivers it into this socket's service handler, locally the
    // rendezvous delivers it the same way. An earlier form took the OpenChannel
    // as a parameter, assuming some outer wire-reader demuxed it first; under
    // gRPC no such caller exists — the socket is what receives the SYN — and a
    // parameter an implementation must hand to its own method belongs inside it.
    //
    // RETURNS ONLY THE ACK (2026-07-31 — supersedes AcceptOutcome). It used to
    // also return a minted CortexReceiver, because the socket owned the memory
    // wiring; with a handler it owns none, so there is nothing left to mint. The
    // ack is exactly what the wire carries and nothing more.
    //
    // Every implementation guarantees, in order:
    //   1. gate the client's wire_protocol_version — vacuous in-process (one
    //      build), and DEFERRED as policy: the local impl ECHOES the version
    //      into the ack rather than comparing, so the plumbing stays exercised
    //      and the first remote test checks a policy instead of discovering
    //      unwired fields. Where the canonical constant lives is a separate-box
    //      question, deliberately unanswered here.
    //   2. one-peer-per-channel — if already connected(), return
    //      CONN_STATUS_ADDRESS_IN_USE (the structural guard). EXEMPT for
    //      ChannelId::MEMORY, which grants every dialer.
    //   3. on success — mark connected and grant the channel as identity in the
    //      ack.
    // None of these allocates, blocks, or can fail for want of a resource, which
    // is what makes it safe to run the whole of accept() on gRPC's handler thread
    // and return the ack from that thread.
    //
    // NOT re-called on DEACTIVATE/ACTIVATE (that is the SESSION lifecycle), and
    // never awaited by the supervisor at startup (there is no barrier).
    virtual rr_conn::OpenChannelAck accept() = 0;

    // connect(): the active open, CLIENT side — dial the far server for this
    // channel and hold the result. The mirror of accept(), and the only beat a
    // client has after bind().
    //
    // CLIENT ONLY; on a SERVER socket it is a wiring bug and returns
    // CONN_STATUS_ERROR. Blocks until the far side answers unless
    // RrSockFlags::NONBLOCK was set.
    //
    // FAILURE IS ORDINARY, NOT FATAL — the far end may simply not be up yet, and
    // per the no-startup-barrier rule the brain proceeds regardless. A caller
    // retries on its own schedule; this contract does not define one, and a
    // reconnect policy is a separate-box concern (DEFERRED).
    virtual rr_conn::ConnStatus connect() = 0;

    // send(): put one envelope on this channel. Legal on BOTH roles, and it
    // means the same thing either way — speak unprompted — which is precisely
    // what a response is not.
    //
    // TWO CALLERS, ONE METHOD:
    //   - the outbound gate's wake hook, when cognition emits on this channel.
    //     The supervisor installs `tx->on_ready = [&]{ sock.send(...); }` at
    //     wiring time; the socket itself never sees an IOCom.
    //   - a CLIENT directly, to initiate (a cortex firing an EngramQuery).
    //
    // MUST NOT BLOCK ON THE WIRE. The hook above runs on the outbound gate's
    // SINGLE thread, so a synchronous network write here stalls the other five
    // channels. Implementations enqueue and return; the return value reports
    // whether it was accepted for transmission, NOT whether it arrived.
    //
    // A SEND WITH NO PEER IS A SILENT NO-OP, not an error — an unconnected
    // channel is the normal shape of a degraded run, and a fault-per-tick for an
    // absent cortex is noise. The connection-level fault has its own home (the
    // missing-channel sticky WTF, reported once).
    //
    // The reply, if the far side sends one, arrives at that peer's HANDLER as an
    // ordinary inbound envelope — correlated by correlation_id, never by
    // position. There is no in-band response here, because there is no stream.
    virtual rr_conn::ConnStatus send(const rr_inference::CortexEnvelope& msg) = 0;

    // Whether this socket has a live peer: granted (SERVER) or dialled (CLIENT).
    // Also how the supervisor observes, WITHOUT waiting, which channels came up.
    virtual bool connected() const = 0;

    // The bound channel — opts.channel, echoed back. Returns ChannelId::COUNT
    // when unbound; that is COUNT's second job and the reason MEMORY could not
    // take the value 6.
    virtual rr_emod_types::ChannelId channel() const = 0;

    // The bound role/modifiers — opts.flags, echoed back. Returns
    // RrSockFlags::NONE when unbound. The registry needs it for its key, and it
    // is how a caller checks a beat is legal before making it.
    virtual RrSockFlags flags() const = 0;
};

}  // namespace rr_emod_serde
