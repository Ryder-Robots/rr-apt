// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots

#pragma once

#include <Eigen/Dense>
#include <functional>
#include <memory>
#include <span>
#include <unordered_map>
#include <vector>

#include <rr_emod_serde/engram.hpp>
#include <rr_emod_serde/rr_emod_types.hpp>
#include <rr_emod_serde/rr_store.hpp>

namespace rr_emod_serde {

// The engram corpus: one append-only log, plus whatever is resident in RAM.
//
// There is no separate index file. Records carry their own length and CRC, so the
// id -> offset map is rebuilt by walking the log at boot, and cannot disagree with
// the corpus the way a second file could.
//
// Writes are appends. An engram whose metadata changed is appended again and the
// later record wins; compact() drops the superseded ones at a consolidation
// boundary. Nothing that is not in RAM is ever rewritten, which is what stops a
// partially loaded session from shrinking the corpus to what it happened to touch.
class EngramCache {
public:
    explicit EngramCache(const std::string& engram_file);

    static std::unique_ptr<EngramCache> create(const std::string& engram_file);

    ~EngramCache() = default;

    EngramCache(const EngramCache&) = delete;
    EngramCache& operator=(const EngramCache&) = delete;

    // Get engram from cache or disk. Returns nullptr if not found.
    rr_emod_types::Engram* get(const rr_emod_types::EngramID& id);

    // Add engram to cache. Never evicts, signals capacity state instead.
    void add(rr_emod_types::Engram&& engram);

    // Check current cache utilization.
    // Capacity check: call capacity_state() before/after consolidation
    rr_emod_types::CapacityState capacity_state() const;

    // No engrams anywhere — in RAM or on disk. The cold-start question: true here
    // means this brain has never stored anything, not that nothing is loaded yet.
    bool empty() const;

    // Nothing in RAM to write. Separate from empty() because "no work to persist"
    // and "no memories at all" are different questions and were once the same call.
    bool resident_empty() const;

    // Find engram closest to query vector. Searches everything known — resident and
    // on disk — lazy-loading as needed, and skips dormant engrams by decay.
    // current_session: session counter from XLSTMMemory for decay calculations
    rr_emod_types::Engram* find_closest(const Eigen::VectorXf& query, std::uint64_t current_session);

    // Rebuild the id -> offset map by walking the log (call at boot).
    void load_index();

    // Hands every engram in the corpus to fn, current version only, without caching
    // any of them. Boot recovery has to inspect the whole corpus to find its work,
    // and pulling it into RAM to do so would defeat the point of a lazy cache.
    // Reads through the index, so load_index() has to have run.
    RrStore::Result scan(const std::function<void(const rr_emod_types::Engram&)>& fn) const;

    // Append every resident engram, durably. Never truncates, so an engram that was
    // not loaded this session cannot be lost by a session that did not touch it.
    void persist();

    // Drop superseded versions of every engram and reclaim the space. Atomic: the
    // log is rewritten under a temp name and swapped in. Consolidation-boundary work.
    void compact();

    // Serialize engram to bytes for writing to disk.
    static std::vector<std::byte> serialize(const rr_emod_types::Engram& engram);

    // Deserialize bytes to engram. An engram with an empty embedding means the record
    // did not describe itself consistently and was refused.
    static rr_emod_types::Engram deserialize(std::span<const std::byte> bytes);

    // Bytes this engram occupies on disk. The only place the record layout is counted:
    // serialize() reserves with it, get_serialized_size() sums it, and deserialize()
    // checks the wire against the same arithmetic.
    static std::size_t record_bytes(const rr_emod_types::Engram& engram);

    size_t get_serialized_size() const;

    // Read-only view of the resident engrams (the in-memory working set: this
    // session's promoted + retrieved engrams). Used by consolidation to walk the
    // set that gets written to the training TFRecord.
    const std::unordered_map<rr_emod_types::EngramID, rr_emod_types::Engram>& entries() const {
        return cache_;
    }

    // Reset: clear engram_map for next session, reset access_count in all engrams
    void reset();

    // clear(): drop the in-RAM cache WITHOUT flushing (caller is responsible for having
    // persisted first; persist() then clear() == reset()).
    void clear();

private:
    struct EngramMetadata {
        bool loaded = false;
        uint64_t access_count = 0;
    };

    std::unordered_map<rr_emod_types::EngramID, rr_emod_types::Engram> cache_;
    std::unordered_map<rr_emod_types::EngramID, rr_emod_types::IndexEntry> index_;
    std::unordered_map<rr_emod_types::EngramID, EngramMetadata> metadata_;

    RrLogStore corpus_;

    size_t max_cache_size_;

    size_t compute_max_cache_size() const;

    rr_emod_types::Engram lazy_load_from_disk(const rr_emod_types::EngramID& id);

    // The id sits in the last 16 bytes of a record, so the boot walk can index
    // without deserializing an embedding it may never need.
    static bool id_of(std::span<const std::byte> record, rr_emod_types::EngramID& out);

    // The three variable-length fields of a record, taken from its own prefixes.
    struct RecordExtent {
        std::uint32_t raw_len = 0;
        std::uint32_t key_elems = 0;
        std::uint32_t sal_len = 0;
    };

    // Resolves a record's exact size from its length prefixes before any payload is
    // read. False means the prefixes and the record's actual length disagree.
    static bool record_extent(std::span<const std::byte> bytes, RecordExtent& out);
};

}  // namespace rr_emod_serde
