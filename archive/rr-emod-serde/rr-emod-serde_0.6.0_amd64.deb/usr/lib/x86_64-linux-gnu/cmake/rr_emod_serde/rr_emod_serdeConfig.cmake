
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was rr_emod_serdeConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/x86_64-linux-gnu/cmake/rr_emod_serde" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

# Re-find the public dependencies so consumers get Eigen3::Eigen and the torch
# imported targets transitively. The brain links LibTorch PUBLIC (cognition), so
# every consumer must resolve `torch` — hint with the build-time location; a
# consumer can still override via CMAKE_PREFIX_PATH / -DTorch_DIR.
include(CMakeFindDependencyMacro)
find_dependency(Eigen3 3.4)
find_dependency(Torch PATHS "/home/aaron/libtorch-build/share/cmake/Torch")
# Protobuf is public API surface: inference_memory_io.hpp includes the
# generated inferenceio.pb.h, and consumers (cortexes) construct the request
# messages themselves — they compile and link against protobuf directly.
find_dependency(Protobuf)

include("${CMAKE_CURRENT_LIST_DIR}/rr_emod_serdeTargets.cmake")

check_required_components(rr_emod_serde)
