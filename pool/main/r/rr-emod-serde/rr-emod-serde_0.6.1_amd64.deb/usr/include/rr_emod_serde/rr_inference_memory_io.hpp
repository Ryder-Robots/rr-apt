// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
#ifndef RR_EMOD_SERDE_RR_INFERENCE_MEMORY_IO_HPP
#define RR_EMOD_SERDE_RR_INFERENCE_MEMORY_IO_HPP

#include <common/inferenceio.pb.h>

#include <array>
#include <atomic>
#include <cstdint>
#include <deque>
#include <functional>
#include <memory>
#include <mutex>
#include <optional>
#include <rr_emod_serde/rr_cortex_receiver.hpp>
#include <rr_emod_serde/rr_emod_types.hpp>
#include <rr_emod_serde/rr_lc.hpp>
#include <rr_emod_serde/rr_logger.hpp>
#include <string>

namespace rr_emod_serde {

using DiagnosticState = rr_emod_types::DiagnosticState;

// Assumption enforced, not remembered: the mailbox array is indexed by
// ordinal ChannelId (0..COUNT-1), never by mask values. channel_mask in the
// proto message is the *query scope* bitfield and is unrelated to indexing.
static_assert(static_cast<size_t>(rr_emod_types::ChannelId::COUNT) > 0,
              "ChannelId must be an ordinal enum with a COUNT sentinel");

/**
 * Final version will be a gRPC or similar protocol to allow protobuf queries
 * to be sent to memory; this version is bound to RrSupervisor for testing in
 * a controlled environment.
 *
 * PASSIVE COMPONENT — owns no thread. Cortex threads produce requests via
 * their CortexReceiver; the RrControlLoop thread consumes via ready()/
 * get_request() (memory) and prompt_ready()/get_prompt() (prompts) and
 * routes results back via respond(). When gRPC transport is added, the
 * listener thread is started in on_activate and joined in on_deactivate;
 * it acts as one more producer on the same ingress edge, and remote
 * requests route responses by correlation_id to transient mailboxes,
 * never into the cortex channel mailboxes regardless of claimed
 * sender_id.
 *
 * INGRESS DEMUX — an inbound envelope is one of exactly TWO requests, and
 * enqueue() forwards each to its own mailbox:
 *   EngramQuery -> the memory-request mailbox (ready()/get_request()),
 *   Prompt      -> the prompt mailbox        (prompt_ready()/get_prompt()).
 * Nothing more. Any other arm — a response arriving inbound, an empty
 * envelope — is rejected AT THE EDGE: DIAG_ERR straight back to the
 * sender's mailbox (so a parked cortex unparks instead of timing out) and
 * the sticky WTF raised, on the producer's own thread. The control loop
 * never sees an envelope it cannot service; the demux branch it used to
 * carry lives here now.
 *
 * kLifecycleAck is defined on the wire (answers to supervisor-issued
 * lifecycle commands) but has NO consumer yet: nothing issues commands
 * in-process — this IO's own lifecycle methods close/reopen the mailboxes
 * directly. Until the supervisor's pending-command table exists, an ack
 * arriving here is protocol skew and takes the same rejection funnel;
 * when it lands, it routes to the supervisor, NEVER to these mailboxes.
 *
 * DATA FLOW:
 *   proto envelopes flow INWARD  (cortex -> two request mailboxes -> control loop),
 *   raw results     flow OUTWARD (control loop -> channel mailbox -> cortex),
 *   and the request envelope is the routing token on the way back.
 */
class InferenceMemoryIO : public rr_emod_lc::RrLc {
public:
    // The logger is borrowed from the composition root, not owned and not
    // optional. No other construction-time dependencies.
    explicit InferenceMemoryIO(RrLogger& logger)
        : rr_emod_lc::RrLc("InferenceMemoryIO"), logger_(logger) {}

    // --- wiring --------------------------------------------------------

    // Hand each cortex its receiver once at wiring time. Precondition:
    // channel < ChannelId::COUNT (asserted). One receiver per channel —
    // the one-consumer-per-mailbox invariant is the caller's to keep.
    // Reveivers once passed off, remain the property of the caller, or
    // what is used to perform the connection with gRPC.
    CortexReceiver receiver(rr_emod_types::ChannelId channel);

    // Consumer wake-up: fired once per enqueue, outside the queue lock. The
    // control loop registers a hook that notifies its cv, so a request
    // arriving while cognition CONTEMPLATEs wakes servicing instead of
    // sitting queued until the next percept. ready() is the LEVEL the wait
    // predicate reads; the hook is the EDGE that forces a re-read. Null (the
    // default) is fine for callers that poll.
    void set_wake_hook(std::function<void()> hook);

    // --- control-loop API (RrControlLoop thread ONLY) -------------------
    // Single-consumer invariant: ready()==true guarantees non-empty at
    // get_request() only because nothing else pops (same for the prompt
    // pair).

    // Lock-free fast paths for the tick loop, one per request mailbox.
    bool ready() const { return ready_.load(std::memory_order_acquire); }
    bool prompt_ready() const { return prompt_ready_.load(std::memory_order_acquire); }

    // Pop the oldest MEMORY request (guaranteed kEngramQuery — the ingress
    // demux admits nothing else to this mailbox). sender_id was stamped at
    // receipt for local receivers; re-validated defensively once remote
    // producers exist. ready_ is recomputed from queue state under the same
    // lock as the pop (flag is a pure function of queue emptiness — see .cpp).
    std::optional<rr_inference::CortexEnvelope> get_request();

    // Pop the oldest PROMPT request (guaranteed kPrompt, same contract as
    // get_request in every other respect, including the pause behaviour).
    std::optional<rr_inference::CortexEnvelope> get_prompt();

    // Route a result to the requesting cortex's mailbox. The envelope being
    // answered supplies the routing key (sender_id) and correlation
    // (correlation_id) — the control loop never touches the routing key
    // directly, so it cannot deliver to the wrong mailbox. Out-of-range
    // sender_id is a routing error: logged, result dropped, never
    // default-constructed into existence via operator[].
    void respond(const rr_inference::CortexEnvelope& request, InferenceMemResult result);

    // --- diagnostics -----------------------------------------------------

    // Sticky component condition, robotist-facing. WTF here is non-fatal
    // and means a result was dropped (closed mailbox / bad sender) — weird
    // behaviour worth correlating against the session log. Deliberately NOT
    // folded into the lifecycle returns: those report whether a transition
    // completed, and a non-fatal condition must not fail one. Read this
    // between transitions; sticky until on_configure() resets it to OK.
    DiagnosticState diagnostic() const { return diag_.load(std::memory_order_relaxed); }

protected:
    // --- lifecycle (RrLc) ------------------------------------------

    // Validate/reset queue and mailbox state.
    DiagnosticState on_configure() override;
    // Open the doors: reopen every mailbox and recompute the ready flags
    // from whatever survived a pause — nothing to spawn (until a gRPC
    // listener exists).
    DiagnosticState on_activate() override;
    // A PAUSE, not a teardown: leave pending requests queued to resume
    // after reactivate, and close() all mailboxes to wake any cortex
    // parked in pop_wait. Queued results survive the pause — draining/discard
    // is on_cleanup/on_shutdown.
    DiagnosticState on_deactivate() override;
    // Return to the post-construction state: discard queued work, close
    // every mailbox.
    DiagnosticState on_cleanup() override;
    // As deactivate + cleanup, only on system shutdown.
    DiagnosticState on_shutdown() override;

private:
    // Reverse half of the mutual friendship (CortexReceiver's private ctor
    // is the other): the un-nested receiver reaches enqueue() and
    // mailboxes_ — exactly the access it had as a nested class, no more.
    friend class CortexReceiver;

    // Log (correlation_id + channel via {0} placeholders, caller supplies) and
    // escalate diag_. Escalation is monotonic — never downgrades a worse condition
    // already recorded. Call sites: respond() on a dropped result, and
    // enqueue() on an ingress rejection (protocol skew).
    void note_wtf(std::string_view fmt, std::initializer_list<std::string_view> args = {});
    // Producer path shared by CortexReceiver::receive (and, later, the
    // gRPC listener). THE ingress demux: forwards kEngramQuery / kPrompt to
    // their mailboxes (push under lock, then flag, then wake); rejects
    // everything else with DIAG_ERR on the producer's thread — no wake, the
    // loop has nothing to do. Open in every phase by design: a pause stops
    // the consumer popping and results leaving, never a request landing —
    // work arriving mid-pause parks here and is answered on reactivation.
    void enqueue(rr_inference::CortexEnvelope envelope);

    std::deque<rr_inference::CortexEnvelope> memory_requests_;
    std::deque<rr_inference::CortexEnvelope> prompt_requests_;
    mutable std::mutex request_mutex_;
    std::atomic<bool> ready_{false};
    std::atomic<bool> prompt_ready_{false};
    // Guarded by request_mutex_; copied out before invocation so a producer
    // never runs foreign code while holding the queue lock.
    std::function<void()> wake_hook_;

    RrLogger& logger_;
    std::atomic<DiagnosticState> diag_{DiagnosticState::OK};

    std::array<InferenceMailbox, static_cast<size_t>(rr_emod_types::ChannelId::COUNT)> mailboxes_;
};

}  // namespace rr_emod_serde

#endif  // RR_EMOD_SERDE_RR_INFERENCE_MEMORY_IO_HPP
