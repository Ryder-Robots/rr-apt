// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
#pragma once

// The cortex-facing half of InferenceMemoryIO: everything a cortex needs to
// issue queries and collect results, and nothing of the supervisor/control-
// loop surface. Cortexes include THIS header, never rr_inference_memory_io.hpp —
// that insulation is what lets a future cortex binary (separate CM5) compile
// against the same query surface and link a gRPC client stub instead of the
// IO server. The receiver's public surface must therefore stay
// stub-mirrorable: no method on it that couldn't be implemented by a remote
// client.

#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <mutex>
#include <optional>
#include <string>
#include <memory>

#include <rr_emod_serde/engram.hpp>
#include <rr_emod_serde/rr_emod_types.hpp>

#include <common/inferenceio.pb.h>

namespace rr_emod_serde {

class InferenceMemoryIO;

enum class InferenceMemStatus : uint32_t {
    FOUND = 0,
    NOT_FOUND = 1,
    // Never travels via a mailbox: a bad sender_id means there is no valid
    // mailbox to deliver the rejection to. Receipt-side log only (and the
    // gRPC status trailer, once transport exists).
    REJECTED_BAD_SENDER = 2,
    DIAG_ERR = 3,  // consider this a WTF, WTAF or FUBAR, logs should tell more
};

/**
 * Result envelope delivered to a cortex mailbox.
 *
 * INVARIANT: engram.has_value() iff status == FOUND. Enforced by assert in
 * InferenceMailbox::put() rather than by type (variant rejected as clunkier
 * at call sites for two states).
 *
 * Engrams stay raw C++ here deliberately: the consumer is in-process, so
 * proto serialization of the response is deferred to the transport adapter
 * when gRPC arrives. Requests rehearse the wire shape; responses do not
 * need to.
 */
struct InferenceMemResult {
    InferenceMemStatus status;
    std::optional<rr_emod_types::Engram> engram;  // engaged iff FOUND
    // Correlation, echoed from the request ENVELOPE — the envelope is the
    // single source of truth for correlation; payloads carry none of their
    // own. Unique per sender: (sender_id, correlation_id) is globally unique.
    uint64_t correlation_id;
};

/**
 * Per-cortex response channel.
 *
 * INVARIANTS:
 *   - Exactly ONE consumer: the cortex whose ChannelId indexes this slot.
 *   - Producer is the control-loop thread via InferenceMemoryIO::respond().
 *
 * Consumption modes: tick-driven cortexes drain with try_pop()/drain();
 * reactive cortexes park in pop_wait(). close() unblocks waiters on
 * deactivate/shutdown; reopen() re-arms on activate.
 */
class InferenceMailbox {
public:
    InferenceMailbox() = default;  // required: std::array default-constructs elements
    InferenceMailbox(const InferenceMailbox&) = delete;
    InferenceMailbox& operator=(const InferenceMailbox&) = delete;
    InferenceMailbox(InferenceMailbox&&) = delete;
    InferenceMailbox& operator=(InferenceMailbox&&) = delete;

    // Producer side (control loop). Data lands under lock BEFORE notify.
    // Asserts the status/engram invariant documented on InferenceMemResult.
    // Returns false when the mailbox is closed: the result is DROPPED and
    // the caller escalates (see InferenceMemoryIO::note_wtf). Park-first
    // ordering means no result can legitimately arrive after close(), so a
    // drop here is always a lifecycle-ordering violation — never expected
    // consolidation noise. That is what makes the WTF trustworthy.
    bool put(InferenceMemResult result);

    // Consumer side (owning cortex only).
    std::optional<InferenceMemResult> try_pop();
    std::optional<InferenceMemResult> pop_wait(std::chrono::milliseconds timeout);

    // Drain everything in one lock acquisition. Preferred for tick-driven
    // cortexes that process all pending results per tick anyway.
    std::deque<InferenceMemResult> drain();

    // Wake any parked waiter; subsequent pop_wait returns immediately with
    // nullopt. Called from on_deactivate / on_shutdown. The one legitimate
    // notify_all in this file lives in close(): shutdown must wake a waiter
    // regardless of count.
    void close();
    void reopen();  // on_activate — clears closed flag

private:
    mutable std::mutex mutex_;
    std::condition_variable cv_;
    std::deque<InferenceMemResult> queue_;
    bool closed_{false};
};

/**
 * Cortex receiver: the request-ingress edge of InferenceMemoryIO, and the
 * ONLY surface a cortex ever sees.
 *
 * ========================== SERVER SIDE ONLY ===========================
 * This class is the SERVER-SIDE receiving end of the cortex↔memory
 * channel, and it is the permanent server implementation: it serves
 * cortexes that share a process with InferenceMemoryIO, reaching the IO
 * directly through a held reference (io_) bound at mint time. A remote
 * cortex — another CM5, a separate machine altogether — can NEVER use
 * this class: there is no server object on that machine for io_ to
 * refer to. Never hand this type across a process boundary.
 *
 * That is also why the mutual friendship with InferenceMemoryIO is
 * acceptable HERE, and only here: friendship is an in-process,
 * compile-time mechanism, and this is the in-process implementation. It
 * is not — and cannot be — the long-term client mechanism.
 *
 * LONG TERM (when the machines separate): the query surface (receive /
 * mailbox / channel) becomes a virtual interface. This class stays
 * behind it as the server-side implementation; a client-side
 * implementation speaks the wire protocol instead. Identity crosses the
 * boundary differently too. Here, the server MINTS identity: receivers
 * are created exclusively by InferenceMemoryIO::receiver(), and
 * receive() stamps sender_id on receipt from the receiver's own
 * ChannelId, overwriting anything the caller set — identity is a fact,
 * not a claim, and a cortex cannot impersonate another channel. A remote
 * client cannot be handed a minted object, so it is instead GIVEN its
 * identity by a protobuf message at connection time (an identity grant
 * in the handshake), and the transport binds that identity to the
 * CONNECTION — never to a field the client stamps itself, which would
 * make identity a claim again. Granting identity in a message is safe
 * because we own the brain end-to-end: both ends of the wire are ours.
 *
 * LIFETIME: the receiver holds a plain reference to the IO that minted
 * it — receiver() passes *this — so a receiver (and any
 * InferenceMailbox& taken from it) must not outlive that IO. This is
 * the supervisor's invariant, not the type system's: park-first
 * teardown stops every cortex BEFORE the IO is destroyed, so no
 * receiver can be alive-and-in-use when io_ dies. Deliberately NOT a
 * shared_ptr: receivers must never pin a lifecycle component alive
 * past the supervisor's decision to tear it down.
 */
class CortexReceiver {
public:
    // Receive a command envelope from this channel's cortex — in-process,
    // the cortex is the transport, calling the server edge directly
    // (later, the gRPC listener calls this same edge). Never blocks on
    // processing: push under lock, flag, return. The envelope's sender_id
    // is stamped on receipt from this receiver's channel; which command
    // the envelope carries is the control loop's concern (demux at
    // service time), not the transport's.
    void receive(rr_inference::CortexEnvelope envelope);

    // This channel's mailbox (address-stable for the life of the IO).
    InferenceMailbox& mailbox();

    rr_emod_types::ChannelId channel() const { return id_; }

private:
    friend class InferenceMemoryIO;  // sole mint — see class comment
    CortexReceiver(InferenceMemoryIO& io, rr_emod_types::ChannelId id)
        : io_(io), id_(id) {}

    InferenceMemoryIO& io_;
    rr_emod_types::ChannelId id_;
    // No owned mailbox: the response channel is the IO's array slot for this
    // ChannelId (address-stable for the IO's life). mailbox() returns that slot,
    // which is what respond() delivers into and what the lifecycle close()/reopen()s
    // — one home, so results can't land where the cortex never reads. Owning a box
    // here also made the receiver non-movable; without it, receiver() returns cleanly.
};

}  // namespace rr_emod_serde
