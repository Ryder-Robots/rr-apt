// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_SESSION_CLOCK_HPP
#define RR_EMOD_SERDE_RR_SESSION_CLOCK_HPP

#include <cstdint>
#include <array>
#include <span>
#include <cstring>

#include <rr_emod_serde/rr_store.hpp>
#include <rr_emod_serde/rr_checksum.hpp>

namespace rr_emod_serde {
struct ClockRecord {
    static constexpr std::uint32_t LEASE = 32;
    static constexpr char MAGIC[4] = {'R', 'R', 'S', 'C'};
    static constexpr std::uint16_t VERSION = 1;

    std::uint64_t reserved;  // ceiling: every number <= this is BURNT
    std::uint64_t closed;    // last number issued under a clean stop
    char magic[4] = {'R', 'R', 'S', 'C'};
    std::uint16_t version = VERSION;
    std::uint16_t pad = 0;
    std::uint32_t crc32;
    // The record aligns to 8, so these four bytes exist whether or not they are named.
    // Naming them keeps every byte the CRC covers owned by a field with a known value.
    std::uint32_t pad2 = 0;
};

// The record is written and read as raw bytes, so its layout IS the on-disk format.
static_assert(sizeof(ClockRecord) == 32, "clock record layout changed");

class SessionClock {
public:
    explicit SessionClock(const std::string& path);

    RrStore::Result boot() noexcept;
    RrStore::Result issue(std::uint64_t& n);
    RrStore::Result close() noexcept;
    bool  crashed() const noexcept;
    bool is_dirty(std::uint64_t session) const noexcept;

    // The highest number that may ever have been issued. Not the current session —
    // nothing above this can exist, which is what makes it a sanity bound on
    // anything else claiming to carry a session number.
    std::uint64_t ceiling() const noexcept { return reserved_; }

private:

    RrStore::Result write_mark(std::uint64_t reserved, std::uint64_t closed) const;

    std::uint64_t current_ = 0;
    std::uint64_t reserved_ = 0;
    std::uint64_t closed_ = 0;
    RrSnapshotStore store_;
};
}  // namespace rr_emod_serde

#endif  // RR_EMOD_SERDE_RR_SESSION_CLOCK_HPP
