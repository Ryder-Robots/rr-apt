// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <thread>
#include <atomic>
#include <array>
#include <memory>
#include <map>
#include <algorithm>
#include "rr_emod_serde/rr_checksum.hpp"
#include "rr_emod_serde/rr_mod_lc.hpp"
#include "rr_emod_serde/rr_emod_types.hpp"

namespace rr_inbound_gate
{
class InboundChannelGate : public rr_emod_lc::RrModLc
{
  using IO_COM_ARRAY =
      std::array<std::shared_ptr<rr_emod_types::IOCom>, static_cast<size_t>(rr_emod_types::ChannelId::COUNT)>;

public:
  // is_shutdown and is_consolidating are owned by RrControlLoop and shared here.
  // The control loop signals them directly — the gate must not own them independently.
  InboundChannelGate(std::shared_ptr<rr_emod_types::InboundChannel> inbound, IO_COM_ARRAY io_coms,
                     std::atomic<bool>& is_shutdown, std::atomic<bool>& is_consolidating)
    : inbound_(inbound), io_coms_(io_coms), is_shutdown_(is_shutdown), is_consolidating_(is_consolidating)
  {
  }

  // gate_loop_t must not be joinable at destruction — on_cleanup() is responsible for joining it.
  ~InboundChannelGate();

  rr_emod_lc::DiagnosticState on_configure() override;

  rr_emod_lc::DiagnosticState on_activate() override;

  rr_emod_lc::DiagnosticState on_deactivate() override;

  rr_emod_lc::DiagnosticState on_cleanup() override;

protected:
  // TODO: on WTF/WTAF detection, synthesise a TEXT channel payload describing the fault and
  // adjust frame.salience_lora to the appropriate circumplex vector once mapping is defined
  // (see RESEARCH-00025). Engram.salience_lora is already wired — no structural changes needed.
  void run();

  std::shared_ptr<rr_emod_types::InboundChannel> inbound_;
  std::thread gate_loop_t;
  IO_COM_ARRAY io_coms_;

  std::atomic<bool>& is_shutdown_;
  std::atomic<bool>& is_consolidating_;

  static constexpr std::array<rr_emod_types::ChannelIdMask, rr_emod_types::CHANNEL_COUNT> CHANNEL_TO_MASK = {
    rr_emod_types::ChannelIdMask::VISION,         rr_emod_types::ChannelIdMask::AUDIO,
    rr_emod_types::ChannelIdMask::PROPRIOCEPTION, rr_emod_types::ChannelIdMask::EXTEROCEPTION,
    rr_emod_types::ChannelIdMask::TEXT,           rr_emod_types::ChannelIdMask::PEER,
  };
};
}  // namespace rr_inbound_gate