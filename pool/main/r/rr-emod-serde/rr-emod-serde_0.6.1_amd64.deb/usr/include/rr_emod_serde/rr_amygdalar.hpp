// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_AMYGDALAR_HPP
#define RR_EMOD_SERDE_RR_AMYGDALAR_HPP

#include <rr_emod_serde/rr_mode_participant.hpp>

namespace rr_emod_serde {
class RrAmygdalar : public rr_emod_lc::RrModeParticipant {
public:
    RrAmygdalar() : rr_emod_lc::RrModeParticipant("RrAmygdalar") {}
    ~RrAmygdalar() = default;

protected:
    rr_emod_types::DiagnosticState on_configure() override {
        return rr_emod_types::DiagnosticState::OK;
    }

    rr_emod_types::DiagnosticState on_activate() override {
        return rr_emod_types::DiagnosticState::OK;
    }

    rr_emod_types::DiagnosticState on_deactivate() override {
        return rr_emod_types::DiagnosticState::OK;
    }

    rr_emod_types::DiagnosticState on_cleanup() override {
        return rr_emod_types::DiagnosticState::OK;
    }

    rr_emod_types::DiagnosticState on_shutdown() override {
        return rr_emod_types::DiagnosticState::OK;
    }

    rr_emod_types::DiagnosticState on_select_consolidate() override {
        return rr_emod_types::DiagnosticState::OK;
    }

    rr_emod_types::DiagnosticState on_select_arm() override {
        return rr_emod_types::DiagnosticState::OK;
    }
};
}  // namespace rr_emod_serde

#endif  // RR_EMOD_SERDE_RR_AMYGDALAR_HPP