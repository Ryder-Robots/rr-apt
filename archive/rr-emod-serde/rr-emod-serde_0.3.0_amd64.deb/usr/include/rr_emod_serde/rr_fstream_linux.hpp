// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <fstream>
#include "rr_fstream.hpp"

namespace rr_emod_serde {

class RrFstreamLinux : public RrFstreamProxy {
public:
    RrFstreamLinux() = default;
    ~RrFstreamLinux() override = default;

    RrFstreamLinux(const RrFstreamLinux&) = delete;
    RrFstreamLinux& operator=(const RrFstreamLinux&) = delete;

    void open(const char* filename, std::ios_base::openmode mode) override;
    void close() override;

    void seekg(std::streampos pos) override;
    void seekg(std::streamoff off, std::ios_base::seekdir dir) override;

    void seekp(std::streampos pos) override;
    void seekp(std::streamoff off, std::ios_base::seekdir dir) override;

    std::streampos tellg() override;
    std::streampos tellp() override;

    void read(char* buf, std::streamsize size) override;
    void write(const char* buf, std::streamsize size, bool retry = false) override;

    bool good() const override;
    bool fail() const override;
    bool eof() const override;
    bool is_open() const override;

    void clear() override;

    bool getline(std::string& line) override;

private:
    std::fstream file_;
};

}  // namespace rr_emod_serde
