// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_CORTEX_TRANSPORT_LOCAL_HPP
#define RR_EMOD_SERDE_CORTEX_TRANSPORT_LOCAL_HPP

#include <atomic>
#include <optional>

#include <rr_emod_serde/cortex_transport.hpp>

/**
 * CortexTransportLocal — the in-process implementation of CortexTransport.
 *
 * The seam a SAME-PROCESS cortex uses to reach the brain's memory and
 * cognition, standing in until gRPC. It lives on the cortex's side of the
 * line (namespace cortex_serde): a cortex includes cortex_transport.hpp /
 * rr_cortex_receiver.hpp, never rr_inference_memory_io.hpp. That
 * insulation is what lets a future separate-machine cortex compile against
 * this same surface and link a gRPC client stub instead of the IO server.
 *
 * NOT IN THE DATA PATH — THE SUPERVISOR. Traffic runs
 *   cortex -> memory IO -> control loop -> memory / cognition -> back.
 * The supervisor OWNS the objects this transport shares (memory_io_,
 * loop_) and is the lifecycle AUTHORITY that quiesces it, but it never
 * converses over it. Moving memory off the supervisor onto this door is
 * the whole point of the split.
 *
 * HOW IT COMMUNICATES — a shared in-process reference. The impl wraps a
 * minted CortexReceiver, which holds an InferenceMemoryIO& and reaches the
 * IO's address-stable mailbox slot. exchange() hands the envelope to
 * receive() (into the loop) and parks on that mailbox for the answer. That
 * bare reference into the server is exactly what a remote impl deletes and
 * replaces with a wire — which is why CortexReceiver is stamped SERVER-SIDE
 * ONLY and must never cross a process boundary.
 *
 * DROP-IN, SAME CONTRACT. A gRPC client stub implements the same three
 * virtuals (exchange / close / reopen), deserializing EngramResult ->
 * InferenceMemResult inside its own exchange(); the interface holds
 * unchanged (cortex_transport.hpp). The kProtocolVersion check belongs at
 * connection open — a transport's job: vacuous in-process (one build, both
 * ends), load-bearing over the wire.
 */

namespace cortex_serde {
class CortexTransportLocal : public CortexTransport {
public:
    // The mint hands the receiver over BY VALUE — the transport takes
    // ownership (move), it does not borrow. Identity + the IO seam ride in
    // with it, so the ctor needs nothing else: timeout is per-call (the
    // port's policy), and there is no connection to version-check in-process.
    explicit CortexTransportLocal(rr_emod_serde::CortexReceiver receiver)
        : receiver_(std::move(receiver)) {}

    std::optional<rr_emod_serde::InferenceMemResult> exchange(
        rr_inference::CortexEnvelope request, std::chrono::milliseconds timeout) override;

    void close() override;
    void reopen() override;

private:
    std::atomic<bool> closed_{false};
    rr_emod_serde::CortexReceiver receiver_;
};
}  // namespace cortex_serde

#endif  // RR_EMOD_SERDE_CORTEX_TRANSPORT_LOCAL_HPP
