// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_STATE_SIGNAL_HPP
#define RR_EMOD_SERDE_RR_STATE_SIGNAL_HPP

#include <condition_variable>
#include <cstdint>
#include <mutex>
#include <utility>

namespace rr_emod_lc {

/**
 * One axis's notification door: a condition variable, the lock it pairs with,
 * and a change counter, bundled so a producer and its waiters can never end up
 * on different mutexes.
 *
 * A raise says "look", never what happened. The state itself lives with
 * whoever owns it — a waiter's predicate re-reads that state and decides for
 * itself, so a wake that arrives late, spuriously, or after several changes
 * collapsed into one costs a re-read, never a wrong answer. Anything that
 * needs the story of what happened reads the log; anything that needs to
 * count changes reads the generation.
 *
 * Not a lifecycle node — no thread, no phase, no health. It holds nothing but
 * other threads' patience.
 */
class StateSignal {
public:
    StateSignal() = default;

    // One bundle per axis, and every borrower holds a reference to it. A copy
    // would split the waiters from the raiser.
    StateSignal(const StateSignal&) = delete;
    StateSignal& operator=(const StateSignal&) = delete;
    StateSignal(StateSignal&&) = delete;
    StateSignal& operator=(StateSignal&&) = delete;

    // The bundle's lock, for a producer that must write its facts just ahead
    // of a raise. Held while storing, released before raise() — a waiter is
    // either running its predicate under this lock and sees the fresh store,
    // or is asleep and the raise reaches it. There is no third place.
    [[nodiscard]] std::unique_lock<std::mutex> lock() {
        return std::unique_lock<std::mutex>(mtx_);
    }

    // Announce that the watched state moved: count the change under the lock,
    // then wake every waiter. Everyone, not someone — the consumers are
    // independent and the first to wake must not eat the second's wake.
    void raise() {
        {
            const std::lock_guard<std::mutex> lk(mtx_);
            ++generation_;
        }
        cv_.notify_all();
    }

    // Park until pred() holds. The predicate runs under the bundle's lock and
    // is re-checked on every wake. No deadline: a caller that must grade
    // silence brings its own clock, and none does yet.
    template <typename Pred>
    void wait(Pred pred) {
        std::unique_lock<std::mutex> lk(mtx_);
        cv_.wait(lk, std::move(pred));
    }

    // How many raises have happened, ever. Monotonic, so a consumer holding a
    // reading can tell "something changed since" even when the state has
    // flipped away and back.
    [[nodiscard]] std::uint64_t generation() {
        const std::lock_guard<std::mutex> lk(mtx_);
        return generation_;
    }

private:
    std::mutex mtx_;
    std::condition_variable cv_;
    std::uint64_t generation_{0U};
};
}  // namespace rr_emod_lc

#endif  // RR_EMOD_SERDE_RR_STATE_SIGNAL_HPP
