// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <Eigen/Dense>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <fstream>
#include <limits>
#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
#include <algorithm>
#include <cstdint>

#include "rr_emod_serde/engram.hpp"
#include "rr_emod_serde/engram_cache.hpp"
#include "rr_emod_serde/rr_emod_types.hpp"
#include "rr_emod_serde/rr_memory_utils.hpp"
#include "rr_emod_serde/rr_model_utils.hpp"
#include "rr_emod_serde/rr_checksum.hpp"

namespace rr_emod_serde {

// All channels active — the default lobe mask (every ChannelId bit set). The
// hippocampus is shared across lobes at a fixed CHANNEL_COUNT width; a lobe's mask
// selects which channels it owns (others are zeroed at encode in store()).
inline constexpr rr_emod_types::ChannelIdMask ALL_CHANNELS =
    static_cast<rr_emod_types::ChannelIdMask>((1u << rr_emod_types::CHANNEL_COUNT) - 1u);

class XLSTMMemory {
public:
    // TODO: load C_short and C_long from disk. Set diagnostic_ to WTAF if files
    // are missing or corrupt; leave matrices zero-initialised (EP-equivalent) and
    // continue. Caller checks state() to determine cold-start vs resumed session.
    XLSTMMemory();

    // Override: redirect all storage under base_path (engram.dat, engram_idx.dat,
    // and training.tfrecord are derived from it). For library/Python embedding and
    // test isolation — no recompile needed to move where the brain reads/writes.
    explicit XLSTMMemory(const std::string& base_path,
                         rr_emod_types::ChannelIdMask channel_mask = ALL_CHANNELS);
    ~XLSTMMemory() = default;

    // attempts to boot memory system, will send a Diagnostic state on completion.
    // This method must be ran after object has been initlized.
    rr_emod_types::DiagnosticState boot();

    XLSTMMemory(const XLSTMMemory&) = delete;
    XLSTMMemory& operator=(const XLSTMMemory&) = delete;

    // Retrieve: query the matrix memory using the provided embedding.
    // t is derived internally (session offset via the T sibling); nothing about
    // time crosses this API. d is W's dimensionality term (768 vs projected
    // head width still open — arg keeps it revisable).
    rr_emod_types::Engram retrieve(const Eigen::VectorXf& query,
                                   const Eigen::VectorXf& query_salience, float d = 9.0f);

    // Salience-less retrieve: delegates with a zero query-salience triplet, so W
    // collapses toward the floor — mirror of the 2-arg store.
    rr_emod_types::Engram retrieve(const Eigen::VectorXf& query);

    // Store: update matrix memory with key and value. Returns the engram's id
    // (the UUID v4 minted here) so the caller can map its source percept to the
    // brain-side engram — the join key for consolidation write-back (update_w)
    // and for reinforcing a recalled engram. Key and value are both derived from
    // the engram embedding in initial implementation; may diverge when projection
    // weights are trained.
    rr_emod_types::EngramID store(const Eigen::VectorXf& key, const Eigen::VectorXf& value);
    // w is the consolidation weight computed at inference (the head applies W
    // pre-activation and passes the scalar here). The brain records it as-is;
    // it is the standing weight decay operates on at retrieval and the feature
    // consolidation backprop will weight by. The brain does NOT recompute W.
    rr_emod_types::EngramID store(const Eigen::VectorXf& key, const Eigen::VectorXf& value,
                                  const Eigen::VectorXf& salience, float w = 1.0f);

    // Session boundary: the only way time advances. Called at each
    // consolidation-period boundary; boot-after-shutdown ticks via the
    // constructor. promote() NEVER calls this — promotion moves memory
    // between tiers, it does not advance time.
    void begin_session();

    rr_emod_types::DiagnosticState state() const;

    // Sweeps C_short: promotes engrams meeting both threshold conditions to C_long,
    // evicts those below θ_decay. Called after every STORING and OUTBOUND event.
    void promote();

    // always called at any write to long term, also called when disk is to be flushed.
    void persist();

    void fold();

    void reset();

    // clear(): drop working/session state WITHOUT persisting (cache RAM + engram_map +
    // promoted_ids + short_term_accesses). Pair with an explicit persist() first; the control
    // loop persists the post-training W at deactivate, THEN clears.
    void clear();

    rr_emod_types::CapacityState capacity_state();

    // Boundary PREP (promote + write_tfrecords + fold). Leaves memory resident and UNflushed
    // so the control loop can update_w the post-training W at deactivate, THEN persist + clear.
    void close_session();

    // Called after promotion, outputs training data to RR_TRAINING_FILE
    rr_emod_types::DiagnosticState write_tfrecords();
    rr_emod_types::DiagnosticState write_tfrecords(const std::string& filename);
    rr_emod_types::DiagnosticState write_record(const rr_emod_types::Engram& e, std::string& serialized);

    // Consolidation write-back: record the post-training W (recomputed by the
    // harness re-embedding the engram's raw through the updated model) onto the
    // named long-term engram. The decay curve depends on this — without it W is
    // frozen at store() time and U never falls across consolidation cycles.
    // Returns false if the id is unknown (not resident and not on disk).
    bool update_w(const rr_emod_types::EngramID& id, float w);

private:
    // Core constructor — both public ctors delegate here with fully-resolved
    // storage paths, so the member-init list lives in exactly one place.
    XLSTMMemory(std::string base_path, std::string engram_path,
                std::string index_path, std::string training_path,
                rr_emod_types::ChannelIdMask channel_mask);

    // Sibling matrices — same f'/i'/k gates as C, so blended salience and
    // blended stored-at-session correspond to blended content. Read through
    // retrieve_int unchanged (it is polymorphic over row count).
    Eigen::MatrixXf S_short_;  // CHANNEL_COUNT×768 salience
    Eigen::MatrixXf T_short_;  // 1×768 stored-at session stamp

    Eigen::MatrixXf S_long_;  // CHANNEL_COUNT×768 salience for long-term blended reads
    Eigen::MatrixXf T_long_;  // 1×768 stored-at session stamp for long-term

    // mLSTM matrix states — 768×768 (EMBEDDING_DIM_DEFAULT).
    // Operates in full embedding space; projection to BRANCH_DIM deferred
    // until impressioning provides trained projection weights.
    Eigen::MatrixXf C_short_;  // EMBEDDING_DIM_DEFAULT × EMBEDDING_DIM_DEFAULT
    Eigen::VectorXf n_short_;  // normaliser
    float m_short_ = 0.0f;     // stabiliser

    Eigen::MatrixXf C_long_;
    Eigen::VectorXf n_long_;
    float m_long_ = 0.0f;

    // Gate projection parameters — injected at impressioning.
    // Affine pre-activation: log_gate = w·key + b. Zero weights/bias (baseline,
    // unimpressed) → open gates → pure-accumulation write. Impressioning loads
    // trained values; the gate_log_* call sites never change, only this data.
    Eigen::VectorXf w_i_;  // input gate weights
    float b_i_ = 0.0f;     // input gate bias
    Eigen::VectorXf w_f_;  // forget gate weights
    float b_f_ = 0.0f;     // forget gate bias

    // Thresholds — pending EXPERIMENT-0014
    float theta_decay_ = 0.0f;
    float theta_ground_ = 0.0f;
    float theta_retrieve_ = 0.0f;  // set as zero currently TODO:

    // Capacity thresholds and computations
    size_t c_short_capacity_ = 0;
    size_t c_long_capacity_ = 0;
    size_t compute_c_short_capacity() const;
    size_t compute_c_long_capacity() const;

    std::vector<rr_emod_types::Engram> short_term_;
    std::unique_ptr<EngramCache> long_term_cache_;
    // Storage roots resolved at construction (RR_* macros by default, or the
    // base_path override). base_path_ feeds the capacity statvfs; training_path_
    // is the write_tfrecords default target.
    std::string base_path_;
    std::string training_path_;
    // Per-lobe channel mask (which ChannelIds this instance owns). Applied in
    // store(): unselected channels are zeroed before encoding, keeping engrams
    // uniform-width across lobes that share the hippocampus.
    rr_emod_types::ChannelIdMask channel_mask_ = ALL_CHANNELS;
    std::atomic<uint8_t> diagnostic_;

    Eigen::VectorXf retrieve_int(const Eigen::VectorXf& query, const Eigen::MatrixXf& c,
                                 const Eigen::VectorXf& n) const;

    // Exponential-gate log pre-activations. Written once in affine form; the
    // unimpressed→impressioned transition changes only w_*_/b_*_, never these
    // bodies. Forget gate is exponential (f = exp(f̃)), so log f = f̃ — the
    // activation is identity, and zero weights give log f = 0 (no forgetting).
    float gate_log_i(const Eigen::VectorXf& key) const;
    float gate_log_f(const Eigen::VectorXf& key) const;

    // Session clock — the sole source of time. Persisted with the matrices
    // (trajectory state). uint64: a session per minute for 100 years ≈ 5.3e7,
    // twelve orders of magnitude of headroom.
    std::uint64_t session_count_ = 1;  // boot is a boundary: load restores, then ++ (load TODO)
    // T stores stamps as float32 (exact integers only to 2^24). Rebase at a
    // consolidation period when (session_count_ - epoch_) grows large:
    //   T -= delta * n.transpose();  epoch_ += delta;   (exact — T,n are gate-siblings)
    std::uint64_t epoch_ = 0;

    // LONG_TERM t-units: 1 unit = 350 sessions. Pending calibration —
    // same status as the thetas; must be confirmed before impressioning.
    static constexpr float T_UNIT_LONG = 350.0f;

    static constexpr size_t SERIALIZE_OVERHEAD = 16 +  // engram_id (UUID v4)
                                                 8 +   // session_count (uint64)
                                                 8 +   // last_session_access (uint64)
                                                 4 +   // access_count (uint32)
                                                 4 +   // w (float, consolidation weight)
                                                 4 +   // s_memory (float, memory tier scaling)
                                                 24 +  // salience_bins[6] (6 × float32)
                                                 4 +   // checksum (CRC32)
                                                 8;    // alignment padding
    // Total: ~80 bytes

    // Keep a track of engrams for current session.
    std::unordered_map<rr_emod_types::EngramID, rr_emod_types::AccessRecord> engram_map;
    std::vector<rr_emod_types::EngramID> promoted_ids_;
    // Session short-term access tally. Blended mLSTM reads can't be attributed to
    // one engram, so promote() gates on this aggregate, not a per-engram count.
    // Reset at the boundary in close_session().
    std::uint64_t short_term_accesses_ = 0;

    void sample_memory();
};
}  // namespace rr_emod_serde