// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_MODE_CONDUCTOR_HPP
#define RR_EMOD_SERDE_RR_MODE_CONDUCTOR_HPP

#include <array>
#include <atomic>
#include <cstddef>

#include <rr_emod_serde/rr_emod_types.hpp>
#include <rr_emod_serde/rr_logger.hpp>
#include <rr_emod_serde/rr_mode_participant.hpp>
#include <rr_emod_serde/rr_state_signal.hpp>

namespace rr_emod_lc {

/**
 * Owns the mode: which one is demanded, which one has been delivered, and
 * the order participants are driven through a change.
 *
 * Not a lifecycle node — no thread, no phase, no health of its own. Its
 * performing verb relays the worst participant outcome, the way the
 * registry walk does.
 *
 * One door in, and it never performs. Anyone with a claim on the mode calls
 * enter(); that latches the demand and returns. The control loop calls
 * pump() at the top of its tick, and that is where every transition is
 * performed — on the loop's thread, between steps, never mid-step. A demand
 * arriving while a step runs lands at the next tick: unrefusable is not the
 * same as immediate. The split is also what lets the loop demand a mode of
 * itself without deadlocking against its own park.
 */
class ModeConductor {
public:
    // Grows by one with each node that converts to a participant, and the
    // composition fills every slot — a hole in the array is a mis-build,
    // not a terminator.
    static constexpr std::size_t PARTICIPANT_COUNT = 4U;

    // The array's order IS the consolidation order, written here and
    // nowhere else — never derived from the registry's slot order. Walked
    // forward to park and to run the slow work, backward to unpark.
    using ParticipantArray = std::array<RrModeParticipant*, PARTICIPANT_COUNT>;

    // The logger, the participants, and the mode's notification door are all
    // borrowed; whoever composed them keeps them alive. The array is copied
    // so the ordering is frozen at construction. Delivery is this object's
    // fact, so announcing it is this object's job — the signal arrives here
    // rather than being reached for.
    explicit ModeConductor(rr_emod_serde::RrLogger& logger, const ParticipantArray& participants,
                           StateSignal& mode_signal)
        : logger_(logger), participants_(participants), mode_signal_(mode_signal) {}

    // One conductor, one writer of the mode — a copy would be a second one.
    ModeConductor(const ModeConductor&) = delete;
    ModeConductor& operator=(const ModeConductor&) = delete;
    ModeConductor(ModeConductor&&) = delete;
    ModeConductor& operator=(ModeConductor&&) = delete;

    // Demand a mode. Quick and unrefusable: latch the word and return —
    // nothing is performed on this thread. Callable from any thread, and
    // demanding what is already latched or delivered is a no-op, not an
    // error.
    void enter(rr_emod_types::Mode next);

    // Perform whatever enter() has demanded since the last pump. Runs on
    // the pumping thread — in production that is the loop's, at the top of
    // its tick, and there is exactly one performer. Walks the array forward
    // into CONSOLIDATE (park everyone, then each participant's slow work,
    // in order) and backward out of it. Returns the worst participant
    // outcome; OK when there was nothing to do.
    [[nodiscard]] rr_emod_types::DiagnosticState pump();

    // The delivered truth — the mode the machine last cleanly landed on,
    // not the one most recently asked for. Safe to read from any thread.
    [[nodiscard]] rr_emod_types::Mode mode() const {
        return delivered_.load(std::memory_order_acquire);
    }

private:
    rr_emod_serde::RrLogger& logger_;

    const ParticipantArray participants_;

    // The latch: what has been asked for. pump() acts whenever this and the
    // delivered word disagree, so a repeated demand is naturally idempotent.
    std::atomic<rr_emod_types::Mode> demanded_{rr_emod_types::Mode::UNSET};

    // What the last completed walk landed on. Moves only when the walk was
    // clean — a troubled delivery leaves the old reading in place.
    std::atomic<rr_emod_types::Mode> delivered_{rr_emod_types::Mode::UNSET};

    // Raised once per delivery, after the word above moves. A waiter's
    // predicate re-reads the delivered word under the signal's lock, so the
    // wake can never outrun the truth it announces.
    StateSignal& mode_signal_;

    [[nodiscard]] rr_emod_types::DiagnosticState consolidate();
};
}  // namespace rr_emod_lc

#endif  // RR_EMOD_SERDE_RR_MODE_CONDUCTOR_HPP
