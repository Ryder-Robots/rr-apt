// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <array>
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "rr_emod_serde/rr_emod_types.hpp"
#include "rr_emod_serde/rr_fstream.hpp"


namespace {

// On-disk entry layout (no front header — the count is derived from the file
// size and the live session_count is read off the last entry):
//   [ parent_hash(32) | t_hash(32) | hash(32) | session_count(8) | timestamp(4) ]
constexpr std::streamoff HASH_BYTES = 32;
constexpr std::streamoff ENTRY_SIZE =
    HASH_BYTES * 3 + static_cast<std::streamoff>(sizeof(int64_t)) +
    static_cast<std::streamoff>(sizeof(int32_t));  // 108
// Field offsets within a single entry.
constexpr std::streamoff HASH_FIELD_OFFSET = HASH_BYTES * 2;     // parent + t_hash precede `hash`
constexpr std::streamoff SESSION_FIELD_OFFSET = HASH_BYTES * 3;  // three hashes precede session_count

}  // namespace

/**
 * Tamper-evident session ledger: an append-only, hash-chained record of
 * consolidation boundaries. Each entry chains to the previous via
 * hash = SHA-256(parent_hash ‖ t_hash); the sequence is the on-disk order.
 * (A hash chain, not a Merkle tree — there is no per-engram leaf set to
 * commit, and the only verifier with the key is the robot itself.)
 */
namespace rr_emod_serde {

struct LedgerEntry {
    std::array<uint8_t, 32> parent_hash{};
    std::array<uint8_t, 32> t_hash{};  // SHA-256 of this boundary's state_root
    std::array<uint8_t, 32> hash{};    // SHA-256(prev.hash ‖ t_hash) — the chain head
    int64_t session_count = 1;         // session when this was generated
    int32_t timestamp = 0;             // current epoch
};

struct EngramSessionMeta {
    uint64_t session_count = 1;
    uint64_t checksum_count = 0;

    // Create a blank ledger to stop possible memory faults.
    std::vector<LedgerEntry> entries{};
};

class RrLedger {
public:
    RrLedger(const std::string& ledger_file);
    ~RrLedger() = default;

    // Returns a copy taken under the lock; handing back a reference would escape the
    // mutex and could be read while append() mutates meta_.
    EngramSessionMeta session_meta() const {
        std::lock_guard<std::mutex> lk(mtx_);
        return meta_;
    }
    rr_emod_types::DiagnosticState append_checksum(const std::array<uint8_t, 32> chksum,
                                                   const uint64_t session_count);
    rr_emod_types::DiagnosticState read_header();
    EngramSessionMeta read_entries();

private:
    std::string ledger_file_;
    std::unique_ptr<RrFstreamProxy> ledger_;
    EngramSessionMeta meta_;
    // Serialises every file op + meta_ access: the methods share one fstream proxy,
    // and the loop (append) and supervisor (read) hold the same shared RrLedger.
    mutable std::mutex mtx_;
};
}  // namespace rr_emod_serde