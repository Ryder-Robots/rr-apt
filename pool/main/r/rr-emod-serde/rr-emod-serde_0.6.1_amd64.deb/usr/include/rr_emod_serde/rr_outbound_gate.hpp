// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_OUTBOUND_GATE_HPP
#define RR_EMOD_SERDE_RR_OUTBOUND_GATE_HPP

#include <linux/if.h>
#include <netinet/ether.h>
#include <sys/ioctl.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstring>
#include <memory>
#include <rr_emod_serde/rr_checksum.hpp>
#include <rr_emod_serde/rr_emod_types.hpp>
#include <rr_emod_serde/rr_mode_participant.hpp>
#include <rr_emod_serde/rr_model_utils.hpp>
#include <thread>
#include <utility>

namespace rr_outbound_gate {

/**
 * Splits output delivered by cognition into its output channel, each MessageFrame will be appended
 * with meta-data.
 */
class OutboundChannelGate : public rr_emod_lc::RrModeParticipant {
    using IO_COM_ARRAY =
        std::array<rr_emod_types::IOCom*, static_cast<size_t>(rr_emod_types::ChannelId::COUNT)>;

public:
    OutboundChannelGate(rr_emod_types::OutboundChannel& output, IO_COM_ARRAY io_coms)
        : rr_emod_lc::RrModeParticipant("OutboundChannelGate"),
          output_(output),
          io_coms_(io_coms),
          source_id_{} {}

    ~OutboundChannelGate();

protected:
    rr_emod_types::DiagnosticState on_select_consolidate() override;

    rr_emod_types::DiagnosticState on_select_arm() override;

    rr_emod_types::DiagnosticState on_select_unset() override;

    rr_emod_types::DiagnosticState on_consolidate() override;

    rr_emod_types::DiagnosticState on_configure() override;

    rr_emod_types::DiagnosticState on_activate() override;

    rr_emod_types::DiagnosticState on_deactivate() override;

    rr_emod_types::DiagnosticState on_cleanup() override;

    rr_emod_types::DiagnosticState on_shutdown() override;

    void run();

    // Per-session stop for the run() thread: wakes run(), makes it exit, and joins. Idempotent.
    // Called by on_deactivate(), the destructor, and on_activate() (to start from a known-stopped
    // state). Mirrors RrControlLoop::stop_run_thread().
    void stop_run_thread();

    rr_emod_types::OutboundChannel& output_;
    std::thread gate_loop_t;
    IO_COM_ARRAY io_coms_;

    // Per-session stop flag: set by stop_run_thread(), cleared on activate. The only
    // signal that makes run() exit and the join return — machine power-down arrives
    // here as a lifecycle deactivate, not as a broadcast flag. Plain bool: every
    // access is under output_.mtx, so the mutex is its whole guard.
    bool deactivating_{false};

    // Mode word, gate-owned: written only by the mode hooks, read by run()'s
    // predicate. True parks dispatch without ending the thread. Atomic so the
    // word can be read without taking the channel lock; the writes still go
    // under output_.mtx anyway, because run() reads it inside its wait
    // predicate and a write outside that lock can slip between the predicate
    // and the wait blocking, losing the notify.
    std::atomic<bool> is_consolidating_{false};

    // Note sequence will reset after 255
    uint8_t sequence_ = 0;
    uint8_t source_id_[6];
};
}  // namespace rr_outbound_gate

#endif  // RR_EMOD_SERDE_RR_OUTBOUND_GATE_HPP
