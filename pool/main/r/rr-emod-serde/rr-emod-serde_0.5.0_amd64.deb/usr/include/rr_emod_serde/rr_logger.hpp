// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.


#pragma once

#include <string>
#include <atomic>
#include <vector>
#include <mutex>
#include <chrono>
#include <cstdint>
#include "rr_emod_serde/rr_emod_types.hpp"


// contains indivual logging item.
struct rr_log_item {
    uint64_t timestamp = 0;
    rr_emod_types::DiagnosticState state = rr_emod_types::DiagnosticState::OK;
    std::string process;
    std::string msg;
};

namespace rr_emod_serde {
    /**
     * Under normal circumstances logging messages can be considered noop calls, however when toggled
     * on they will print to a log file, which can be retrieved by DIAG. Note that logging is expensive.
     * it will possibly block threads while waiting. It will also have no visibility over what cortexes
     * are doing.
     */
    class RrLogger {
        public:
        RrLogger() = default;
        ~RrLogger() = default;
        void info(std::string msg, std::string process);
        void wtf(std::string msg, std::string process);
        void wtaf(std::string msg, std::string process);
        void fubar(std::string msg, std::string process);
        void start_session_log();
        void end_session_log();
        std::vector<rr_log_item> session_log();

        private:
        // Ring capacity — fixed and class-scoped (no header-level namespace constant).
        static constexpr size_t MAX_LOG_SZ = 1000;

        std::atomic<bool> is_active_{false};
        std::vector<rr_log_item> items_{};  // grows to MAX_LOG_SZ, then overwrites oldest
        size_t head_ = 0;                   // index of the oldest item once the ring is full
        uint64_t dropped_ = 0;              // items overwritten since the last drain

        void write_record(std::string msg, std::string process, rr_emod_types::DiagnosticState diag);

        std::mutex mtx_;
    };
}