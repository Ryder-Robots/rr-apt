// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_COGNITION_HPP
#define RR_EMOD_SERDE_RR_COGNITION_HPP

#include <Eigen/Dense>
#include <atomic>
#include <memory>
#include <rr_emod_serde/rr_cognition_com.hpp>
#include <rr_emod_serde/rr_cognition_marshaller.hpp>
#include <rr_emod_serde/rr_emod_types.hpp>
#include <rr_emod_serde/rr_logger.hpp>
#include <rr_emod_serde/rr_mode_participant.hpp>
#include <rr_emod_serde/rr_store.hpp>
#include <string>
#include <thread>
#include <utility>

namespace rr_emod_serde {

// Performs inference and backpropagation on DNN
class RrCognition : public rr_emod_lc::RrModeParticipant {
public:
    RrCognition(const std::string& weights_path, RRCognitionCom& cognition_com,
                RrLogger& logger);

    // Joins the run thread (mirrors ~RrControlLoop) — a default dtor would
    // std::terminate on a joinable cog_loop_t if destroyed while active.
    ~RrCognition();

    void step();

    float re_embed_w(const rr_emod_types::Engram& e);

protected:
    // Reached only through RrLc::transition(), which is what holds the phase. A
    // caller able to run these directly could move the node without moving what the
    // node says it is, and nothing downstream would be able to tell.
    rr_emod_types::DiagnosticState on_configure() override;
    rr_emod_types::DiagnosticState on_activate() override;
    rr_emod_types::DiagnosticState on_deactivate() override;
    rr_emod_types::DiagnosticState on_cleanup() override;
    rr_emod_types::DiagnosticState on_shutdown() override;

    // The mode plane's park and unpark. Quick: flag under the com's mutex,
    // wake the worker, return — the pump runs on the loop's thread and must
    // never wait on a thought.
    rr_emod_types::DiagnosticState on_select_consolidate() override;
    rr_emod_types::DiagnosticState on_select_arm() override;
    rr_emod_types::DiagnosticState on_select_unset() override;
    rr_emod_types::DiagnosticState on_consolidate() override;

private:
    void run();

    rr_emod_types::Engram to_engram(const Fused& res);
    // Asks the loop for a recall and blocks. False means the stop woke us instead of
    // an answer, and `out` holds nothing worth acting on.
    [[nodiscard]] bool request_and_wait(const Eigen::VectorXf& query_embedding,
                                        rr_emod_types::Engram& out);
    void stop_on_thread();
    // Reads the net's learned state off disk and proves it fits before letting it
    // stand. Anything other than Ok means the brain does not know what it is, and
    // that is for the caller to turn into a verdict.
    [[nodiscard]] RrStore::Result load_weights(const std::string& path);

    // Borrowed, never held. This is the channel between cognition and the control
    // loop, and a channel with two ends is owned by neither of them — it belongs to
    // whoever composed them. It has to outlive this object by more than a hair: the
    // destructor takes its mutex and joins a thread on it.
    RRCognitionCom& cognition_com_;

    RrLogger& logger_;

    // Holds the net. Declared after the logger it borrows, because members are built
    // in declaration order and a marshaller built first would take a reference to
    // something that is not there yet.
    RrCognitionMarshaller marshaller_;

    std::thread cog_loop_t;
    std::atomic<bool> deactivating_{false};

    // The park: while the plane holds CONSOLIDATE the trainer owns the
    // weights, so the worker must not think. Owned here rather than read off
    // the mode word, because the word flips only after the hook returns — a
    // worker woken in that gap would read the old mode and sleep through the
    // change.
    std::atomic<bool> parked_{false};

    std::string weights_path_;
    bool weights_loaded_{false};
};
}  // namespace rr_emod_serde

#endif  // RR_EMOD_SERDE_RR_COGNITION_HPP
