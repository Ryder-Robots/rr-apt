// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_LC_REGISTRY_HPP
#define RR_EMOD_SERDE_RR_LC_REGISTRY_HPP

#include <array>
#include <cstddef>
#include <memory>
#include <rr_emod_serde/rr_cognition_com.hpp>
#include <rr_emod_serde/rr_emod_types.hpp>
#include <rr_emod_serde/rr_lc.hpp>
#include <rr_emod_serde/rr_logger.hpp>
#include <rr_emod_serde/rr_state_signal.hpp>
#include <rr_emod_serde/rr_store.hpp>
#include <string>

namespace rr_emod_serde {
// Held here by unique_ptr and nothing more, so the nodes' own headers stay out of
// this one. Including each of them would make composing the brain mean compiling
// all of it.
class XLSTMMemory;
class RrCognition;
class RrControlLoop;
class InferenceMemoryIO;
class RrAmygdalar;
}  // namespace rr_emod_serde

namespace rr_outbound_gate {
class OutboundChannelGate;
}  // namespace rr_outbound_gate

namespace rr_inbound_gate {
class InboundChannelGate;
}  // namespace rr_inbound_gate

namespace rr_emod_lc {

// Held by unique_ptr for the same reason the nodes above are: composing the
// brain must not mean compiling the mode plane into every holder.
class ModeConductor;

enum class RrLcSlots : std::size_t {
    XLSTM_MEM,
    COGNITION,
    // Before the loop deliberately: this order is the wind order, and the
    // loop's run thread pumps the mode plane from the moment it starts, so
    // every participant has to be ACTIVE by then or the first walks are
    // refusals. The reverse holds on the way down — the producer stops
    // before the egress closes, so the gate drains what the last ticks
    // queued.
    OUTBOUND_CH_GATE,
    CTL_LOOP,
    MEM_INFER_IO,
    AMYGDALAR,
    // Senses last: the gate's run thread assembles percepts from the moment it
    // starts, so everything downstream of it has to be standing first. The
    // reverse holds on the way down — the senses close before anything they
    // feed.
    INBOUND_CH_GATE,

    // must be last: the slot count everything below sizes itself by.
    NODE_COUNT,
};

// Everything a node needs at construction that is not the logger. The defaults name
// where each thing belongs on an installed robot rather than promising it is there,
// and a test overrides only what it cares about:
//   RrConfigItems cfg = rr_default_config();
//   auto reg = RrRegistry::create(cfg);
struct RrConfigItems {
    std::string weights_path;

    // Where the memory keeps its store. Empty means the installed location the
    // build compiled in — a harness or test that boots a brain MUST name its
    // own directory here, or the walk opens the real corpus.
    std::string memory_base_path;
};

// Declared here and built beside the nodes. The path it fills in comes from a build
// macro the library keeps to itself, and a body in this header would compile that
// macro into every translation unit that includes it — so anything outside the
// library that only wants to hold a registry fails to build over a path it never
// asked about. Out of line, the macro stays where it is known and this stays a name.
[[nodiscard]] RrConfigItems rr_default_config();

using rr_emod_serde::RrLogger;
using rr_emod_serde::RrStore;

/**
 * Creates and owns every lifecycle node, and hands out one flat view of them.
 *
 * This is the only place a node is built, so it is the only place that has to
 * know what a node needs in order to exist. Everything downstream borrows.
 *
 * Ownership sits in the unique_ptr members. The array beside them is a
 * borrowed view over those same objects in the order they are to be wound up,
 * so there is one sequence rather than a list and a copy of it to keep in
 * step.
 *
 * It runs nothing and knows nothing about what the nodes do. Deciding when
 * they move is somebody else's job.
 */
class RrRegistry {
public:
    // The only path that hands back a registry, and so the only one that could hand
    // back a half-built one — which it does not. nullptr means a node could not be
    // built or a slot was left empty; there is no way to hold a registry that has
    // not been composed.
    static std::unique_ptr<RrRegistry> create(const RrConfigItems& cfg);

    // Out of line because the nodes are forward-declared above: the destructor is
    // where their unique_ptrs need a complete type, and that belongs beside the
    // code that built them.
    ~RrRegistry();

    // Sole owner of every node. A copy would hand out a second view over
    // objects that stayed owned here; a move would leave the pointers in that
    // view aimed at nothing.
    RrRegistry(const RrRegistry&) = delete;
    RrRegistry& operator=(const RrRegistry&) = delete;
    RrRegistry(RrRegistry&&) = delete;
    RrRegistry& operator=(RrRegistry&&) = delete;

    // Canonical wind order. Unwind is the reverse of this sequence.
    [[nodiscard]] const std::array<RrLc*, static_cast<size_t>(RrLcSlots::NODE_COUNT)>& get_nodes()
        const {
        return owned_;
    }

    // The one logger in the process. Every node and every service borrows it,
    // so there is a single ring to drain rather than one per holder — reading
    // the log has to return the whole trace, not this object's share of it.
    [[nodiscard]] RrLogger& logger() const { return *logger_; }

    // The one writer of the running mode. Commanders demand through it and
    // the loop performs. It lives here because composing it takes the nodes
    // built below; everyone else borrows.
    [[nodiscard]] ModeConductor& conductor() const { return *conductor_; }

    // The notification doors, one per axis and never merged: a phase waiter
    // must not eat mode wakes, nor the reverse. Owned here for the same
    // reason the logger is — one owner, every producer and every consumer
    // borrows a reference at compose, and the bundles outlive them all.
    [[nodiscard]] StateSignal& phase_signal() const { return *phase_signal_; }
    [[nodiscard]] StateSignal& mode_signal() const { return *mode_signal_; }

    // The mode writer's command door. A commander asks for a consolidation
    // edge by calling the loop's verbs, never by writing the mode itself —
    // handing back the typed node keeps that call a call.
    [[nodiscard]] rr_emod_serde::RrControlLoop& control_loop() const { return *node_cl_; }

private:
    RrRegistry() = default;

    // Builds every node and fills its slot, then reports whether it managed to.
    // Runs exactly once, from create(), which is what makes a second composition
    // over a live set of nodes unrepresentable rather than merely discouraged.
    RrStore::Result setup(const RrConfigItems& cfg);

    void make_xlstm(const RrLcSlots slot, const RrConfigItems& cfg);

    void make_cognition(const RrLcSlots slot, const RrConfigItems& cfg);

    void make_control_loop(const RrLcSlots slot);

    void make_inference_mem_io(const RrLcSlots slot);

    void make_outbound_gate(const RrLcSlots slot);

    void make_inbound_gate(const RrLcSlots slot);

    void make_amygdalar(const RrLcSlots slot);

    // Built last: its participant array borrows nodes the calls above have to
    // have made. No slot argument — the conductor is a service, not a node.
    void make_conductor();

    // The one place a node reaches the view, so the bound is checked once rather
    // than in every make_ below. A slot past the end writes nothing and leaves a
    // null for setup() to refuse: a miscounted registry is declined at composition
    // instead of scribbling over the members beside the array.
    bool claim(RrLcSlots slot, RrLc* node);

    // Declared first, and that is load-bearing rather than tidy: every node
    // below takes the logger by reference at construction, and members are
    // built in declaration order. Move this down and each of them borrows an
    // object that does not exist yet.
    std::unique_ptr<RrLogger> logger_ = std::make_unique<RrLogger>();

    // Beside the logger, and for the logger's reason: declared before every
    // borrower so they exist first and die last. Address-stable through the
    // registry's own move into whatever drives it.
    std::unique_ptr<StateSignal> phase_signal_ = std::make_unique<StateSignal>();
    std::unique_ptr<StateSignal> mode_signal_ = std::make_unique<StateSignal>();

    // The borrowed view over the nodes owned below, in wind-up order. A slot
    // left unfilled is a null pointer the first wind will step on, so filling
    // every one of them is what construction has to guarantee.
    std::array<RrLc*, static_cast<size_t>(RrLcSlots::NODE_COUNT)> owned_{};

    std::unique_ptr<rr_emod_serde::RRCognitionCom> cogition_com_ =
        std::make_unique<rr_emod_serde::RRCognitionCom>(*logger_);

    std::unique_ptr<rr_emod_types::InboundChannel> inbound_ =
        std::make_unique<rr_emod_types::InboundChannel>();

    std::unique_ptr<rr_emod_types::OutboundChannel> outbound_ =
        std::make_unique<rr_emod_types::OutboundChannel>();

    // The endpoints, one array per direction and never shared between the
    // gates: each installs its own locking discipline into its slots at
    // configure — the inbound side one master lock spanning the array, the
    // outbound side one lock per slot — so a com sitting in both would have
    // the second wind overwrite the first. Owned beside the channels because
    // the gates only borrow their slots, and whatever carries a channel on or
    // off board will borrow the same one.
    std::array<rr_emod_types::IOCom, rr_emod_types::CHANNEL_COUNT> inbound_io_coms_{};
    std::array<rr_emod_types::IOCom, rr_emod_types::CHANNEL_COUNT> outbound_io_coms_{};

    // Destroyed before the logger above, which is the order the nodes need: a
    // node that says something on the way down is talking to an object that is
    // still there.
    std::unique_ptr<rr_emod_serde::XLSTMMemory> node_memory_;
    std::unique_ptr<rr_emod_serde::RrCognition> node_cognition_;
    std::unique_ptr<rr_emod_serde::InferenceMemoryIO> node_inference_mem_io_;
    std::unique_ptr<rr_outbound_gate::OutboundChannelGate> node_outbound_gate_;
    std::unique_ptr<rr_emod_serde::RrControlLoop> node_cl_;
    std::unique_ptr<rr_emod_serde::RrAmygdalar> node_amygdalar_;
    std::unique_ptr<rr_inbound_gate::InboundChannelGate> node_inbound_gate_;

    // A service, not a node: it holds no slot in the view above. It borrows
    // its participants from the nodes above, so it is built after them and
    // dies before them.
    std::unique_ptr<ModeConductor> conductor_;
};
}  // namespace rr_emod_lc

#endif  // RR_EMOD_SERDE_RR_LC_REGISTRY_HPP
