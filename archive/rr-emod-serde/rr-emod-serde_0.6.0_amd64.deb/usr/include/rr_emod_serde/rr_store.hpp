// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <cstdint>
#include <functional>
#include <span>
#include <string>
#include <vector>

namespace rr_emod_serde {

// Durable storage seam. Every fsync, every fault path, and the one place a cipher
// can go all live in this base, so no store can end up quietly less safe than the
// one beside it.
//
// Two shapes derive from it, because the brain writes two kinds of thing:
//
//   RrSnapshotStore  a value replaced whole (the mLSTM matrices — one blended sum,
//                    no separable history, always written in full)
//   RrLogStore       records appended one at a time (the engram corpus, the ledger —
//                    individually exact, never blended)
//
// The split is by type rather than by a mode flag so that "replace a log" — the
// truncate-then-rewrite that loses a corpus on power failure — cannot be written.
// It is not a discouraged call; it is not a call.
class RrStore {
public:
    // Every store outcome lives here. Derived types add no vocabulary of their own, so
    // a value read out of a log means the same thing whichever store produced it.
    //
    // Ordered the way faults are usually diagnosed: configuration, then permissions,
    // then IO. Absent is not a fault — a store that has never been written has no
    // file, and the caller decides whether that is a cold start or a lost one.
    //
    // Empty and NotFinite are verdicts on the payload rather than on the bytes, and
    // not every store returns them. Empty is the write side only: there is nothing
    // worth snapshotting, so an existing good file is left alone. NotFinite is both
    // sides — poison refused before it reaches disk, or found on the way back in with
    // the CRC intact. Both are kept apart from Corrupt and IoError because a poisoned
    // value is a brain fault while those two are storage faults, and the log has to
    // tell them apart. New values append, so a number in an old log still reads true.
    enum class Result { Ok, Absent, Denied, Corrupt, Truncated, Eof, IoError, Empty, NotFinite };

    virtual ~RrStore() = default;
    RrStore(const RrStore&) = delete;
    RrStore& operator=(const RrStore&) = delete;

    const std::string& path() const noexcept { return path_; }

    // Ok with the size when present, Absent when not. Anything else is a real fault.
    Result probe(std::uint64_t* size_out = nullptr) const noexcept;

    // Deletes the store and any temp left by an interrupted commit.
    Result remove() const noexcept;

protected:
    explicit RrStore(std::string path);

    // ---- primitives -------------------------------------------------------
    // Both loop over short transfers and retry EINTR, and both leave errno as the
    // fault left it.
    static Result write_all(int fd, std::span<const std::byte> src) noexcept;
    static Result read_exact(int fd, std::span<std::byte> dst) noexcept;

    // errno at the point of failure, in this enum's terms.
    static Result classify_errno() noexcept;

    // ---- commit paths -----------------------------------------------------
    // temp -> write -> fsync -> rename -> fsync(parent). A reader sees the old file
    // or the new one, never a partial, and a fault leaves the previous one intact.
    // The atomic dance exists here and nowhere else; produce() only fills the fd.
    Result commit_stream(const std::function<Result(int)>& produce) const;
    Result commit_blocks(std::span<const std::span<const std::byte>> blocks) const;

    // Extends the file and fsyncs it. Never truncates, so what is already on disk
    // survives the write of what comes next.
    Result append_blocks(std::span<const std::span<const std::byte>> blocks) const;

    // Opens for reading and hands fn the fd and the size taken from that same fd —
    // so no reader has to stat the path separately and race its own open.
    Result with_read_fd(const std::function<Result(int, std::uint64_t)>& fn) const;

    // ---- the cipher gate --------------------------------------------------
    // Every byte this class writes leaves through emit(), and every byte it reads
    // arrives through ingest(). D26 ("encrypted to the key element") overrides these
    // two and nothing else — that is the whole reason the stores share a base.
    // The defaults are transparent: blocks go straight to the fd, which is also why
    // a 2.36 MB snapshot costs no gather copy today.
    virtual Result emit(int fd, std::span<const std::span<const std::byte>> blocks) const noexcept;
    virtual Result ingest(int fd, std::span<const std::span<std::byte>> blocks) const noexcept;

    // PiCore runs from RAM: a durable commit there is not durable until it is backed
    // up. No-op everywhere else.
    virtual void post_commit() const noexcept {}

    Result fsync_parent() const noexcept;

    const std::string path_;
    const std::string tmp_path_;
    // Derived once in the constructor so fsync_parent() allocates nothing and can
    // stay noexcept on the fault path.
    const std::string dir_path_;
};

// A value that is always written whole and read whole.
class RrSnapshotStore : public RrStore {
public:
    explicit RrSnapshotStore(std::string path);

    // Atomically replaces the file with these blocks, in order.
    Result replace(std::span<const std::span<const std::byte>> blocks) const;
    Result replace(std::span<const std::byte> buf) const;

    // Fills blocks from the file. The size is checked before a single byte is read,
    // so a short file is Truncated and an over-long one Corrupt — neither is parsed.
    Result load(std::span<const std::span<std::byte>> blocks) const;

    // Whole file, when the caller does not know the size up front.
    Result load(std::vector<std::byte>& out) const;
};

// Records appended one at a time. Each carries its own length and CRC, so a reader
// can tell a torn tail (crash mid-append, discard it) from a corrupt record
// (storage rot, refuse the file).
class RrLogStore : public RrStore {
public:
    // len + crc32 of the payload. Fixed width so a partial header is detectable by
    // size alone.
    struct RecordHeader {
        std::uint32_t len = 0;
        std::uint32_t crc32 = 0;
    };
    static constexpr std::size_t RECORD_HEADER_BYTES = 8;

    // Refuses a record that cannot be framed. Nothing in this brain is close to it;
    // it exists so a corrupt length cannot ask replay() for a 4 GB allocation.
    static constexpr std::uint32_t MAX_RECORD_BYTES = 64u * 1024u * 1024u;

    explicit RrLogStore(std::string path);

    // Appends one record and fsyncs. Durable on return, or it did not happen.
    // Assumes a single writer — one brain, one corpus. Two processes appending to
    // the same log could interleave a header and its payload.
    //
    // Heals a torn tail before the first append, so a record can never land after
    // one. Writing past a torn tail would hide every record behind it: replay stops
    // at the tear and reports success, having walked only the prefix.
    Result append(std::span<const std::byte> record) const;

    // Drops a trailing partial record so the log ends on a record boundary. Ok when
    // there was nothing to drop, and Absent when there is no log yet. Idempotent.
    // append() does this for you; call it directly to recover at startup.
    Result heal() const;

    // Calls on_record for each whole record in order; return false from it to stop
    // early. A trailing partial record is not an error — it is a crash mid-append,
    // and torn_tail says so. A record whose CRC fails is Corrupt and stops the walk.
    Result replay(const std::function<bool(std::span<const std::byte>)>& on_record,
                  bool* torn_tail = nullptr) const;

    // Same walk, also handing back each record's offset. That offset is what
    // read_record takes, so a caller can build an index in one pass and afterwards
    // fetch any single record without walking the log again.
    Result replay_indexed(
        const std::function<bool(std::uint64_t, std::span<const std::byte>)>& on_record,
        bool* torn_tail = nullptr) const;

    // Reads the one record at an offset replay_indexed reported. Verifies its CRC,
    // so a rotted record is Corrupt rather than handed back. An offset that is not a
    // record boundary is Corrupt too — it is a stale index, not a readable record.
    Result read_record(std::uint64_t offset, std::vector<std::byte>& out) const;

    // Rewrites the log with the records keep() accepts and swaps it in atomically.
    // Reclaims space without ever leaving a window where the log does not exist —
    // which is what makes this safe to run at a consolidation boundary. keep() gets
    // the offset so a caller holding an index can drop superseded versions.
    Result compact(
        const std::function<bool(std::uint64_t, std::span<const std::byte>)>& keep) const;

private:
    // Walks whole records, reporting where the good prefix ends. replay() reads it,
    // heal() truncates to it.
    Result scan(const std::function<bool(std::uint64_t, std::span<const std::byte>)>& on_record,
                std::uint64_t* good_end, bool* torn_tail) const;

    // One heal per object, not one per append — the scan is O(log) and the tail can
    // only tear in a run that already ended. Follows the single-writer contract
    // above; it is a cache of work done, not shared state.
    mutable bool tail_healed_ = false;
};

// Names a Result for the log. Lives beside the enum so the table cannot drift from
// it, and is shared rather than copied so the same value never gets two spellings in
// two subsystems. Bounds-checked, so an unnamed value degrades to "Unknown" rather
// than reading off the end of the table.
const char* result_name(RrStore::Result r) noexcept;

}  // namespace rr_emod_serde
