// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_ENGRAM_HPP
#define RR_EMOD_SERDE_ENGRAM_HPP

#include <Eigen/Dense>
#include <cstdint>
#include <cstring>
#include <string_view>
#include <vector>

namespace rr_emod_types {

inline const std::vector<std::byte> EP = []() {
    constexpr std::string_view sv =
        "observation perceives patterns, understanding "
        "predicts behaviour, you wish to understand observations";
    return std::vector<std::byte>(reinterpret_cast<const std::byte*>(sv.data()),
                                  reinterpret_cast<const std::byte*>(sv.data() + sv.size()));
}();

constexpr std::size_t EMBEDDING_DIM_DEFAULT = 768;

// An engram id is this wide, in both the places it is declared — Engram::engram_id
// carries it and EngramID wraps it, and the two are copied into each other. Named so
// that they cannot disagree: every memcpy between them takes sizeof of the buffer it
// writes, which is only safe while both arrays are sized from here.
constexpr std::size_t ENGRAM_ID_BYTES = 16;

/**
 * A single memory unit — the eModule's BERT-encoded representation of a moment.
 *
 * Engrams are written to disk on salience events and restored on power-up, giving
 * the eModule continuity of state across power cycles and hardware changes.
 * The encoding follows the BERT input format so that the raw token sequence can be
 * fed back to the transformer to close the retrieval loop.
 * Invariants:
 *   - Immutable after composition, with one exception: session_count,
 *     t_count are authored by the consolidation layer
 *     and may be rewritten during the on_deactivate → consolidation →
 *     on_activate cycle.
 *   - salience_lora is reserved for Tier-3 consolidation and is empty on every
 *     current path — see the decision record at the field.
 */
struct Engram {
    Engram() = default;
    Engram(const Engram&) = delete;
    Engram& operator=(const Engram&) = delete;
    Engram(Engram&&) = default;
    Engram& operator=(Engram&&) = default;

    std::vector<std::byte> raw =
        EP;  // Original source data — fed back to transformer to close the loop
    std::vector<uint32_t> input_ids;      // Token IDs from BERT vocabulary
    std::vector<uint8_t> attention_mask;  // 1 = real token, 0 = padding
    std::vector<uint8_t>
        token_type_ids;     // Segment A = stimulus, Segment B = memory/emotional state
    uint64_t frame_id = 0;  // Originating Frame ID. 0 = no frame (internally generated, e.g. EP)
    Eigen::VectorXf embedding;
    Eigen::VectorXf key;  // the address it was filed under; unnormalised
    std::vector<std::byte>
        salience_lora;  // int8, QLoRA-adapter-compatible (bert.cpp); empty until Tier-3

    // Engram-local age in sessions. Zero at birth. Incremented by consolidation
    // at each session boundary. Used directly for SHORT_TERM eviction (t=5).
    std::uint64_t session_count = 0;

    // Tier-dependent time coordinate authored by the consolidation layer.
    // SHORT_TERM: equals session_count. LONG_TERM: scaled units (1 unit =
    // 350 sessions), rewritten at tier promotion. Input to W and E(t).
    std::uint64_t t_count = 0;

    // W-modulated retrieve (EXPERIMENT-0007 integration). query_salience is the
    // prompt salience triplet, produced OUTSIDE the brain (experiment-side head:
    // the brain stores and consumes salience, it does not produce it). t = cycle
    // multiplier from the caller; d = W dimension (9 = salience space, exp7 parity).
    float w = 1.0f;
    float s_memory = 0.0f;

    // Engram access tracking for promotion/consolidation decisions
    uint64_t access_count = 0;         // Durable count. retrieve() increments a per-session
                                       // record; fold() adds it here ONCE per session boundary
                                       // (close_session), never on retrieve or persist.
    uint64_t last_session_access = 0;  // Session number of last active retrieval

    uint8_t engram_id[ENGRAM_ID_BYTES] = {0};

    // The one sanctioned copy of an engram.
    //
    // Copy is deleted above so that ownership of a stored engram cannot be duplicated
    // by accident — an engram is a memory, and two of them are two memories that will
    // drift apart. A caller that genuinely needs its own asks for it by name, which
    // puts the ~6 KB at the call site instead of hiding it inside an assignment.
    Engram clone() const {
        Engram c;
        c.raw = raw;
        c.input_ids = input_ids;
        c.attention_mask = attention_mask;
        c.token_type_ids = token_type_ids;
        c.frame_id = frame_id;
        c.embedding = embedding;
        c.key = key;
        c.salience_lora = salience_lora;
        c.session_count = session_count;
        c.t_count = t_count;
        c.w = w;
        c.s_memory = s_memory;
        c.access_count = access_count;
        c.last_session_access = last_session_access;
        std::memcpy(c.engram_id, engram_id, sizeof(engram_id));
        return c;
    }
};

// A field added to Engram and not added to clone() would copy as its default and be
// silently lost, which is the kind of fault that only shows up as a memory that came
// back wrong. This does not catch a field swapped for another of the same width, but
// it does catch every addition — which is the way the list actually drifts.
static_assert(sizeof(Engram) == 216U,
              "Engram gained or lost a field; clone() has to copy it too");

struct AccessRecord {
    uint64_t access_count;
    float importance;
    uint64_t last_session_access;
};

struct EngramID {
    uint8_t id[ENGRAM_ID_BYTES];
    bool operator==(const EngramID& other) const {
        return std::memcmp(id, other.id, sizeof(id)) == 0;
    }
};

// Index: IndexEntry[0], IndexEntry[1], ..., IndexEntry[n_long-1]
struct IndexEntry {
    uint64_t offset;  // Byte offset in engram.dat
    uint32_t size;    // Engram size (raw_length + 3129)
};

}  // namespace rr_emod_types

namespace std {
template <>
struct hash<rr_emod_types::EngramID> {
    size_t operator()(const rr_emod_types::EngramID& id) const {
        // Hash all 16 bytes as two uint64_t chunks, XORed together
        uint64_t lo = *reinterpret_cast<const uint64_t*>(id.id);
        uint64_t hi = *reinterpret_cast<const uint64_t*>(id.id + 8);
        return std::hash<uint64_t>()(lo ^ (hi << 1) ^ (hi >> 1));
    }
};

}  // namespace std

#endif  // RR_EMOD_SERDE_ENGRAM_HPP
