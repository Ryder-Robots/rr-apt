// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_LC_HPP
#define RR_EMOD_SERDE_RR_LC_HPP

#include <cstdint>

#include <rr_emod_serde/rr_emod_types.hpp>

namespace rr_emod_lc {

/**
 * The transitions a component can be commanded through. These are edges, not
 * states — what a component currently IS is an LcPhase.
 */
enum class LcState : uint8_t { CONFIGURE, ACTIVATE, DEACTIVATE, CLEANUP, SHUTDOWN };

/**
 * Where a component currently sits. Two transitions can share a destination
 * (configure and deactivate both leave a node INACTIVE), so this is not
 * derivable from the last transition applied. FINALIZED is terminal: nothing
 * leads out of it.
 */
enum class LcPhase : uint8_t { UNCONFIGURED, INACTIVE, ACTIVE, FINALIZED };

/**
 * Abstract lifecycle interface for eModule components.
 *
 * Mirrors the ROS2 managed node lifecycle (configure -> activate -> deactivate
 * -> cleanup) adapted for the eModule context.
 *
 * A node is a SUBJECT of the lifecycle and nothing else. It can be moved
 * through a transition; it cannot move anything else. There is no registry
 * here, no parent, and no walk, so a node holds no reference to any other node
 * and the ability to drive a sequence is not something an implementor picks up
 * by inheriting. Ordering a set of nodes belongs to whoever holds the set.
 *
 * One public door in, five hooks to implement. Callers can only ask for a
 * transition; they cannot reach past it to an individual hook, so a component
 * has exactly one thing that can move it.
 *
 * A transition always runs to completion. The returned DiagnosticState reports
 * how well it went, never whether it was permitted — anything other than OK
 * leaves the caller to decide whether to retry, wind down, or escalate.
 */
class RrLc {
public:
    virtual ~RrLc() = default;

    // A node is built once, in one place, and reached from everywhere else by
    // borrowed pointer. A copy would be a second object nobody owns; a move
    // would leave every borrowed pointer aimed at a husk.
    RrLc(const RrLc&) = delete;
    RrLc& operator=(const RrLc&) = delete;
    RrLc(RrLc&&) = delete;
    RrLc& operator=(RrLc&&) = delete;

    /**
     * Move THIS component through one transition and record where it landed.
     *
     * The phase only moves on a clean transition. A component that reported
     * trouble is left in the phase it already held, so afterwards the reading
     * is "it ran, it did not land" rather than an optimistic phase covering
     * for it.
     */
    [[nodiscard]] rr_emod_types::DiagnosticState transition(LcState state);

    [[nodiscard]] LcPhase get_phase() const { return phase_; }

    // Names the component in a trace of a wind-up or wind-down — a position in
    // somebody's ordering says nothing about which component it was.
    [[nodiscard]] const char* name() const { return name_; }

protected:
    /**
     * The name is borrowed and never copied, so it has to outlive the node: a
     * string literal is what this expects.
     */
    explicit RrLc(const char* name);

    /**
     * Initialise the component.
     *
     * Called once before activation. Implementations should load configuration,
     * initialise the EP from training data, and prepare any resources needed for
     * activation. The cognitive loop does not start yet.
     */
    virtual rr_emod_types::DiagnosticState on_configure() = 0;

    /**
     * Start the component.
     *
     * Engrams are restored from disk if they exist, the queue starts processing,
     * and the eModule is ready to receive input. If no engrams exist on disk the
     * EP fires immediately.
     */
    virtual rr_emod_types::DiagnosticState on_activate() = 0;

    /**
     * Stop the component in readiness for winding down.
     *
     * Queue processing stops and the current engram is preserved. Resources are
     * held, so the component can be started again without reconfiguring — but
     * this is the pause that precedes a teardown, not the one a sleep cycle
     * uses. A component that is merely resting is still activated.
     */
    virtual rr_emod_types::DiagnosticState on_deactivate() = 0;

    /**
     * Release resources after deactivation.
     *
     * Flushes the queue to disk, releases held resources, and returns the
     * component to a pre-configure condition, leaving enough behind that a
     * subsequent configure can restore from it.
     */
    virtual rr_emod_types::DiagnosticState on_cleanup() = 0;

    /**
     * Wind down for good. There is no transition out of this one.
     */
    virtual rr_emod_types::DiagnosticState on_shutdown() = 0;

private:
    LcPhase phase_ = LcPhase::UNCONFIGURED;  // What this node currently IS.
    const char* name_ = "";                  // Borrowed; owned by whoever named the node.
};
}  // namespace rr_emod_lc

#endif  // RR_EMOD_SERDE_RR_LC_HPP
