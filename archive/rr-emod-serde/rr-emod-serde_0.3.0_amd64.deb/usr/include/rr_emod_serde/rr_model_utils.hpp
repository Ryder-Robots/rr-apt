// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <Eigen/Dense>
#include <algorithm>
#include <optional>
#include <random>
#include <cmath>
#include "rr_emod_serde/engram.hpp"

// Canonical cognition math: the single definition of W and salience for the
// positronic brain. Stateless — every function is f(inputs) -> value; state
// lives in XLSTMMemory. One compiled definition per formula (in
// rr_model_utils.cpp), resolved once at link, so the formula cannot fork.
// (RFC-0007 §8 consilience, enforced at the linker rather than by eye.)

namespace rr_model_utils {
inline constexpr float PHI = 0.6180339887f;   // reciprocal golden ratio
inline constexpr float W_CLAMP_MAX = 1.618f;  // golden ratio — amplify ceiling
inline constexpr float S_FLOOR = 1e-6f;       // keep salience away from 0

float cube_root_d(float d);

float salience_norm(const Eigen::VectorXf& sal);

// W = t * (s_memory * s_prompt)^φ / ∛d   when s_memory present (t >= 2 cycle)
// W = t *  s_prompt^φ        / ∛d        otherwise (t == 1, no prior state).
// Per-engram scalar core; s_memory = nullopt means "no prior cycle". Returns W
// clamped to W_CLAMP_MAX. Source: RESEARCH-00022 (W), RESEARCH-00024 (∛d).
float compute_w(const Eigen::VectorXf& sal_xyz, float t, float d,
                std::optional<float> s_memory = std::nullopt);

// Uncertainty primitive: U = 1 − min(W, 1)
// U ∈ [0, 1]: 0 = instinct-certain (W ≥ 1), 1 = lost (W = 0).
// Certainty saturates at W = 1; weight beyond that adds no extra certainty.
// Source: RFC-0007 §4 (instinct-is-earned frame).
float compute_u(float w);

float compute_decay(const rr_emod_types::Engram& engram, std::uint64_t session_count);

void generate_uuid(uint8_t uuid[16]);

// Quantize salience vector to int8 for compact storage in salience_lora.
// Assumes salience is in roughly [-1, 1] range; clamps and scales to [-127, 127].
std::vector<int8_t> quantize_salience(const Eigen::Vector3f& salience);

// Dequantize int8 salience back to float vector.
Eigen::Vector3f dequantize_salience(const std::vector<int8_t>& quantized);

}  // namespace rr_model_utils