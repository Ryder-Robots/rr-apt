// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <torch/torch.h>

#include <atomic>
#include <cmath>
#include <memory>
#include <thread>
#include <utility>

#include "rr_emod_serde/rr_cognition_com.hpp"
#include "rr_emod_serde/rr_emod_types.hpp"
#include "rr_emod_serde/rr_logger.hpp"
#include "rr_emod_serde/rr_mod_lc.hpp"

namespace rr_emod_serde {

struct CognitionResult {
    torch::Tensor embedding;  // fused egram -> memory argmax
    torch::Tensor logits;     // action-space store (n_zone); decision = argmax
    torch::Tensor u;          // softmax uncertaintity
};

// Performs inference and backpropagation on DNN
class RrCognition : public rr_emod_lc::RrModLc, torch::nn::Module {
public:
    RrCognition(std::size_t n_zones, std::shared_ptr<RRCognitionCom> cognition_com,
                std::shared_ptr<RrLogger> logger = nullptr);

    // Joins the run thread (mirrors ~RrControlLoop) — a default dtor would
    // std::terminate on a joinable cog_loop_t if destroyed while active.
    ~RrCognition();

    // interface
    CognitionResult forward(torch::Tensor stacked, torch::Tensor mask);

    void step();

    void consolidate();

    float re_embed_w(const rr_emod_types::Engram& e);

    rr_emod_lc::DiagnosticState on_configure() override;
    rr_emod_lc::DiagnosticState on_activate() override;
    rr_emod_lc::DiagnosticState on_deactivate() override;
    rr_emod_lc::DiagnosticState on_cleanup() override;
    rr_emod_lc::DiagnosticState on_shutdown() override;

private:
    void run();

    std::pair<torch::Tensor, torch::Tensor> to_tensors(
        const rr_emod_types::Engram& in, rr_emod_types::ChannelIdMask mask);
    rr_emod_types::Engram to_engram(const CognitionResult& res);
    rr_emod_types::Engram request_and_wait(torch::Tensor query_embedding);
    void stop_on_thread();
    std::size_t n_zones_;
    std::shared_ptr<RRCognitionCom> cognition_com_;
    std::shared_ptr<RrLogger> logger_;
    std::thread cog_loop_t;
    std::atomic<bool> deactivating_{false};

    torch::nn::Linear fuse_{nullptr};
    torch::nn::Sequential head_{nullptr};
    torch::Tensor absent_;
};
}  // namespace rr_emod_serde