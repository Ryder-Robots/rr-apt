// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <Eigen/Dense>
#include <vector>
#include <atomic>
#include <cmath>

#include "rr_emod_serde/rr_emod_types.hpp"

namespace rr_emod_serde {

class XLSTMMemory {
public:
    // TODO: load C_short and C_long from disk. Set diagnostic_ to WTAF if files
    // are missing or corrupt; leave matrices zero-initialised (EP-equivalent) and
    // continue. Caller checks state() to determine cold-start vs resumed session.
    XLSTMMemory();
    ~XLSTMMemory() = default;

    XLSTMMemory(const XLSTMMemory&) = delete;
    XLSTMMemory& operator=(const XLSTMMemory&) = delete;

    // Retrieve: query the matrix memory using the provided embedding.
    // Returns a memory engram. If no relevant memory, returns EP engram.
    rr_emod_types::Engram retrieve(const Eigen::VectorXf& query);

    // Store: update matrix memory with key and value.
    // Key and value are both derived from the engram embedding in initial
    // implementation; may diverge when projection weights are trained.
    void store(const Eigen::VectorXf& key, const Eigen::VectorXf& value);

    rr_emod_types::DiagnosticState state() const;

    // Sweeps C_short: promotes engrams meeting both threshold conditions to C_long,
    // evicts those below θ_decay. Called after every STORING and OUTBOUND event.
    void promote();

private:
    // mLSTM matrix states — 768×768 (EMBEDDING_DIM_DEFAULT).
    // Operates in full embedding space; projection to BRANCH_DIM deferred
    // until impressioning provides trained projection weights.
    Eigen::MatrixXf C_short_;  // EMBEDDING_DIM_DEFAULT × EMBEDDING_DIM_DEFAULT
    Eigen::VectorXf n_short_;  // normaliser
    float m_short_ = 0.0f;     // stabiliser

    Eigen::MatrixXf C_long_;
    Eigen::VectorXf n_long_;
    float m_long_ = 0.0f;

    // Gate projection parameters — injected at impressioning.
    // Affine pre-activation: log_gate = w·key + b. Zero weights/bias (baseline,
    // unimpressed) → open gates → pure-accumulation write. Impressioning loads
    // trained values; the gate_log_* call sites never change, only this data.
    Eigen::VectorXf w_i_;   // input gate weights
    float b_i_ = 0.0f;      // input gate bias
    Eigen::VectorXf w_f_;   // forget gate weights
    float b_f_ = 0.0f;      // forget gate bias

    // Thresholds — pending EXPERIMENT-0014
    float theta_decay_ = 0.0f;
    float theta_ground_ = 0.0f;
    float theta_retrieve_ = 0.0f; // set as zero currently TODO: 

    // Engram lists for promote() evaluation
    struct EngramEntry {
        Eigen::VectorXf embedding;
        float energy = 0.0f;
        uint32_t grounding = 0;
        uint64_t t_count = 0;
        bool is_active = true;
    };

    std::vector<EngramEntry> short_term_;
    std::vector<EngramEntry> long_term_;
     std::atomic<uint8_t> diagnostic_;

    // always called at any write to long term.
    void persist();

     Eigen::VectorXf retrieve_int(const Eigen::VectorXf& query, const Eigen::MatrixXf& c, const Eigen::VectorXf& n) const;

    // Exponential-gate log pre-activations. Written once in affine form; the
    // unimpressed→impressioned transition changes only w_*_/b_*_, never these
    // bodies. Forget gate is exponential (f = exp(f̃)), so log f = f̃ — the
    // activation is identity, and zero weights give log f = 0 (no forgetting).
    float gate_log_i(const Eigen::VectorXf& key) const;
    float gate_log_f(const Eigen::VectorXf& key) const;
};

}  // namespace rr_emod_serde