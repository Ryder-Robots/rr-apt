// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_INBOUND_GATE_HPP
#define RR_EMOD_SERDE_RR_INBOUND_GATE_HPP

#include <algorithm>
#include <array>
#include <atomic>
#include <map>
#include <memory>
#include <rr_emod_serde/rr_checksum.hpp>
#include <rr_emod_serde/rr_emod_types.hpp>
#include <rr_emod_serde/rr_mode_participant.hpp>
#include <thread>

namespace rr_inbound_gate {
class InboundChannelGate : public rr_emod_lc::RrModeParticipant {
    using IO_COM_ARRAY =
        std::array<rr_emod_types::IOCom*, static_cast<size_t>(rr_emod_types::ChannelId::COUNT)>;

public:
    InboundChannelGate(rr_emod_types::InboundChannel& inbound, IO_COM_ARRAY io_coms)
        : rr_emod_lc::RrModeParticipant("InboundChannelGate"),
          inbound_(inbound),
          io_coms_(io_coms) {}

    // gate_loop_t must not be joinable at destruction — stop_run_thread() joins it, and the
    // destructor calls it too so this holds whether or not on_deactivate() ran.
    ~InboundChannelGate();

protected:

    rr_emod_types::DiagnosticState on_select_consolidate() override;

    rr_emod_types::DiagnosticState on_select_arm() override;

    rr_emod_types::DiagnosticState on_select_unset() override;

    rr_emod_types::DiagnosticState on_consolidate() override;

    rr_emod_types::DiagnosticState on_configure() override;

    rr_emod_types::DiagnosticState on_activate() override;

    rr_emod_types::DiagnosticState on_deactivate() override;

    rr_emod_types::DiagnosticState on_cleanup() override;

    rr_emod_types::DiagnosticState on_shutdown() override;

    // TODO: on WTF/WTAF detection, synthesise a TEXT channel payload describing the fault and
    // adjust frame.salience_lora to the appropriate circumplex vector once mapping is defined
    // (see RESEARCH-00025). Engram.salience_lora is already wired — no structural changes needed.
    void run();

    // Per-session stop for the run() thread: wakes run(), makes it exit, and joins. Idempotent.
    // Called by on_deactivate(), the destructor, and on_activate() (to start from a known-stopped
    // state). Mirrors RrControlLoop::stop_run_thread().
    void stop_run_thread();

    // Set the mode word and wake run(). Write and notify go under the master lock
    // for the reason stop_run_thread() records: a bare write can land after run()'s
    // predicate read the old value and before the wait blocks, and the wake
    // reaches nobody.
    void signal_consolidating(const bool parked);

    rr_emod_types::InboundChannel& inbound_;
    std::thread gate_loop_t;
    IO_COM_ARRAY io_coms_;

    // Per-session stop flag: set by stop_run_thread(), cleared on activate. The only
    // signal that makes run() exit and the join return — machine power-down arrives
    // here as a lifecycle deactivate, not as a broadcast flag.
    std::atomic<bool> deactivating_{false};

    // Mode word, gate-owned: written only by the mode hooks, read by run()'s
    // predicate. True parks assembly without ending the thread.
    std::atomic<bool> is_consolidating_{false};

    static constexpr std::array<rr_emod_types::ChannelIdMask, rr_emod_types::CHANNEL_COUNT>
        CHANNEL_TO_MASK = {
            rr_emod_types::ChannelIdMask::VISION,
            rr_emod_types::ChannelIdMask::AUDIO,
            rr_emod_types::ChannelIdMask::PROPRIOCEPTION,
            rr_emod_types::ChannelIdMask::EXTEROCEPTION,
            rr_emod_types::ChannelIdMask::TEXT,
            rr_emod_types::ChannelIdMask::PEER,
        };
};
}  // namespace rr_inbound_gate

#endif  // RR_EMOD_SERDE_RR_INBOUND_GATE_HPP
