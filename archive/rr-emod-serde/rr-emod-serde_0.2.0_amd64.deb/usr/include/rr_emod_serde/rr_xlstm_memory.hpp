// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <Eigen/Dense>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <vector>

#include "rr_emod_serde/rr_emod_types.hpp"
#include "rr_emod_serde/rr_model_utils.hpp"

namespace rr_emod_serde {

class XLSTMMemory {
public:
    // TODO: load C_short and C_long from disk. Set diagnostic_ to WTAF if files
    // are missing or corrupt; leave matrices zero-initialised (EP-equivalent) and
    // continue. Caller checks state() to determine cold-start vs resumed session.
    XLSTMMemory();
    ~XLSTMMemory() = default;

    XLSTMMemory(const XLSTMMemory&) = delete;
    XLSTMMemory& operator=(const XLSTMMemory&) = delete;

    // Retrieve: query the matrix memory using the provided embedding.
    // t is derived internally (session offset via the T sibling); nothing about
    // time crosses this API. d is W's dimensionality term (768 vs projected
    // head width still open — arg keeps it revisable).
    rr_emod_types::Engram retrieve(const Eigen::VectorXf& query,
                                   const Eigen::VectorXf& query_salience, float d = 9.0f);

    // Salience-less retrieve: delegates with a zero query-salience triplet, so W
    // collapses toward the floor — mirror of the 2-arg store.
    rr_emod_types::Engram retrieve(const Eigen::VectorXf& query);

    // Store: update matrix memory with key and value.
    // Key and value are both derived from the engram embedding in initial
    // implementation; may diverge when projection weights are trained.
    void store(const Eigen::VectorXf& key, const Eigen::VectorXf& value);
    void store(const Eigen::VectorXf& key, const Eigen::VectorXf& value,
               const Eigen::Vector3f& salience);

    // Session boundary: the only way time advances. Called at each
    // consolidation-period boundary; boot-after-shutdown ticks via the
    // constructor. promote() NEVER calls this — promotion moves memory
    // between tiers, it does not advance time.
    void begin_session();

    rr_emod_types::DiagnosticState state() const;

    // Sweeps C_short: promotes engrams meeting both threshold conditions to C_long,
    // evicts those below θ_decay. Called after every STORING and OUTBOUND event.
    void promote();

    // always called at any write to long term, also called when disk is to be flushed.
    void persist();

private:
    // Sibling matrices — same f'/i'/k gates as C, so blended salience and
    // blended stored-at-session correspond to blended content. Read through
    // retrieve_int unchanged (it is polymorphic over row count).
    Eigen::MatrixXf S_short_;  // 3×768 salience
    Eigen::MatrixXf T_short_;  // 1×768 stored-at session stamp
    Eigen::MatrixXf S_long_;
    Eigen::MatrixXf T_long_;

    // mLSTM matrix states — 768×768 (EMBEDDING_DIM_DEFAULT).
    // Operates in full embedding space; projection to BRANCH_DIM deferred
    // until impressioning provides trained projection weights.
    Eigen::MatrixXf C_short_;  // EMBEDDING_DIM_DEFAULT × EMBEDDING_DIM_DEFAULT
    Eigen::VectorXf n_short_;  // normaliser
    float m_short_ = 0.0f;     // stabiliser

    Eigen::MatrixXf C_long_;
    Eigen::VectorXf n_long_;
    float m_long_ = 0.0f;

    // Gate projection parameters — injected at impressioning.
    // Affine pre-activation: log_gate = w·key + b. Zero weights/bias (baseline,
    // unimpressed) → open gates → pure-accumulation write. Impressioning loads
    // trained values; the gate_log_* call sites never change, only this data.
    Eigen::VectorXf w_i_;  // input gate weights
    float b_i_ = 0.0f;     // input gate bias
    Eigen::VectorXf w_f_;  // forget gate weights
    float b_f_ = 0.0f;     // forget gate bias

    // Thresholds — pending EXPERIMENT-0014
    float theta_decay_ = 0.0f;
    float theta_ground_ = 0.0f;
    float theta_retrieve_ = 0.0f;  // set as zero currently TODO:

    // Engram lists for promote() evaluation
    struct EngramEntry {
        Eigen::VectorXf embedding;
        Eigen::Vector3f salience = Eigen::Vector3f::Zero();
        float energy = 0.0f;
        uint32_t grounding = 0;
        uint64_t t_count = 0;  // stored-at session stamp (decremented on reference)
        bool is_active = true;
    };

    std::vector<EngramEntry> short_term_;
    std::vector<EngramEntry> long_term_;
    std::atomic<uint8_t> diagnostic_;

    Eigen::VectorXf retrieve_int(const Eigen::VectorXf& query, const Eigen::MatrixXf& c,
                                 const Eigen::VectorXf& n) const;

    // Exponential-gate log pre-activations. Written once in affine form; the
    // unimpressed→impressioned transition changes only w_*_/b_*_, never these
    // bodies. Forget gate is exponential (f = exp(f̃)), so log f = f̃ — the
    // activation is identity, and zero weights give log f = 0 (no forgetting).
    float gate_log_i(const Eigen::VectorXf& key) const;
    float gate_log_f(const Eigen::VectorXf& key) const;

    // Session clock — the sole source of time. Persisted with the matrices
    // (trajectory state). uint64: a session per minute for 100 years ≈ 5.3e7,
    // twelve orders of magnitude of headroom.
    std::uint64_t session_count_ = 1;  // boot is a boundary: load restores, then ++ (load TODO)
    // T stores stamps as float32 (exact integers only to 2^24). Rebase at a
    // consolidation period when (session_count_ - epoch_) grows large:
    //   T -= delta * n.transpose();  epoch_ += delta;   (exact — T,n are gate-siblings)
    std::uint64_t epoch_ = 0;

    // LONG_TERM t-units: 1 unit = 350 sessions. Pending calibration —
    // same status as the thetas; must be confirmed before impressioning.
    static constexpr float T_UNIT_LONG = 350.0f;
};
}  // namespace rr_emod_serde