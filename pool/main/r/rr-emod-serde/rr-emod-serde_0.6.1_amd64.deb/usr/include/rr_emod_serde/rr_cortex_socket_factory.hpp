// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_CORTEX_SOCKET_FACTORY_HPP
#define RR_EMOD_SERDE_RR_CORTEX_SOCKET_FACTORY_HPP

#include <memory>

#include <rr_emod_serde/rr_cortex_socket.hpp>

namespace rr_emod_serde {
class RrRendezvous;
class RrLogger;

struct MakeSocketConfig {
    std::shared_ptr<RrRendezvous> rendezvous;
    RrLogger& logger;
    rr_emod_types::ChannelId channel;

    // A BARE std::function, deliberately not an optional one. RrSockHandler is
    // already nullable and already has operator bool, so wrapping it would give
    // two ways to say "no handler" — nullopt and an empty function — and any
    // guard would only ever catch one of them. Required by make_cortex_server,
    // optional for a client (which may read the unary response inline instead).
    RrSockHandler handler = nullptr;
};

std::shared_ptr<RrCortexSocket> make_cortex_server(MakeSocketConfig conf);

std::shared_ptr<RrCortexSocket> make_cortex_client(MakeSocketConfig conf);
}  // namespace rr_emod_serde

#endif  // RR_EMOD_SERDE_RR_CORTEX_SOCKET_FACTORY_HPP
