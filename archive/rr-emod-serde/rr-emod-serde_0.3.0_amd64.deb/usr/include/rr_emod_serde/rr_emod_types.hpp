// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once
#include <Eigen/Dense>
#include <array>
#include <atomic>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <mutex>
#include <queue>
#include <semaphore>
#include <string>
#include <string_view>
#include <vector>

#include "rr_emod_serde/engram.hpp"

namespace rr_emod_types {

// Maximum size of inbound bytes per channel. Based on image size after
// pre-processing, which is expected to be handled by the robot body hardware.
// Anything larger than this size will generate a diagnostic message WTAF.
constexpr std::size_t MAX_CHANNEL_BYTES = 224 * 224 * 3;

// named constant, needed in types
constexpr size_t BRANCH_DIM = 128;

// compution on when affectiveness of an engram when can be used for saliwence.
constexpr float W_AFFECTIVENESS = std::numeric_limits<float>::min() * 10.0f;

/**
 * Diagnostic state returned by life cycle methods
 */
enum class DiagnosticState : uint8_t {
    OK = 0,     // All good
    WTF = 1,    // Framing error — something unexpected
    WTAF = 2,   // Integrity failure — checksum mismatch or protocol violation
    FUBAR = 3,  // Unrecoverable — emodule needs attention
};

/**
 * SALIENCE occurs in its own loop, it writes directly to inbound queue. Monitoring
 * both TPU/CPU/GPU spikes, and passivly monitoring PROPRIOCEPTION for low battery
 * or other intestering events, when found injects a salient weight into them
 */
enum class InterruptSource : uint8_t {
    COGNITIVE = 0,       // No external interrupt — cognitive cycle, EP or queue
    OUTPUT_CHANNEL = 1,  // eModule issuing a command to the robot body
    SERIALIZATION = 2,   // SerializationRequestor has something to store
    SALIENCE = 3,  // SalienceSampler detected TPU/CPU/GPU pattern that indicates SALIENT trigger
    SHUTDOWN = 4,  // Clean shutdown — factory triggers deactivate and cleanup
    MEMORY_RETRIEVAL = 5,  // Request to retrieve memory.

    INPUT_CHANNEL = 6,  // external input arrives.
};

/**
 * Sensory channel identifier — indexes into a MessageFrame payload array.
 *
 * Use static_cast<size_t>(ChannelId::X) to index MessageFrame::payload directly.
 * COUNT is a sentinel and must remain the last enumerator — CHANNEL_COUNT
 * is derived from it so adding a channel here automatically extends the frame.
 */
enum class ChannelId : size_t {
    VISION = 0,
    AUDIO = 1,
    PROPRIOCEPTION = 2,
    EXTEROCEPTION = 3,
    TEXT = 4,
    PEER = 5,
    COUNT  // must always be last
};

constexpr size_t CHANNEL_COUNT = static_cast<size_t>(ChannelId::COUNT);

enum class ChannelIdMask : uint8_t {
    VISION = 0x01,
    AUDIO = 0x02,
    PROPRIOCEPTION = 0x04,
    EXTEROCEPTION = 0x08,
    TEXT = 0x10,
    PEER = 0x20,
};

enum class CognitiveState : size_t {
    CONTEMPLATING = 0,  // deliberation in progress — control loop waits
    REQUEST = 1,        // retrieve from mLSTM → inject result → back to CONTEMPLATING
    STORING = 2,        // write to mLSTM → back to CONTEMPLATING, no output
    OUTBOUND = 3,       // write to mLSTM + decode + dispatch to robot body
    READY = 4           // waiting for next inbound engram
};

enum class CapacityState : uint8_t {
    OK = 0,       // < 70% of any resource (memory, battery, bandwidth, etc.)
    WARNING = 1,  // 70-85% — consolidation should happen soon
    URGENT = 2,   // 85-95% — consolidation needed now
    CRITICAL = 3  // > 95% — machine must consolidate before accepting new input
};

/** Wire protocol direction marker — readable in hex dumps. */
enum class Magic : char {
    INBOUND = '>',
    OUTBOUND = '<',
    ERROR = '!',
};

/**
 * Wire protocol frame carrying sensory input from robot body to eModule.
 *
 * Received on any of the physical input channels. The payload is modality-agnostic —
 * the eModule determines content through cognition, not through channel labelling.
 * Magic byte identifies frame direction for wire-level debugging.
 * GID provides diagnostic traceability — reported in WTF/WTAF conditions.
 *
 * Expected physical channels (5 + 1 peer):
 *   - Vision          — CSI interface, perceptual TPU preprocessed before reaching eModule
 *   - Audio           — I2S interface, feature extracted before reaching eModule
 *   - Proprioception  — I2C, IMU, encoders, joint state, what the body is doing
 *   - Exteroception   — I2C, proximity, touch, pressure, what the environment is doing
 *   - Text            — I2C, body-designer chat, reconfiguration commands, metacognitive output
 *   - Peer            — eModule to eModule via WiFi, no dedicated physical channel needed
 *
 * Physical interface: CM5 GPIO ribbon to edge connector (cartridge-style), exposed and
 * field-serviceable. Gold contacts, keyed for single orientation. Channels route via
 * carrier board to CSI, I2S, and I2C buses on the CM5.
 */
struct MessageFrame {
    MessageFrame() = default;
    MessageFrame(const MessageFrame&) = delete;
    MessageFrame& operator=(const MessageFrame&) = delete;
    MessageFrame(MessageFrame&&) = default;
    MessageFrame& operator=(MessageFrame&&) = default;

    Magic magic = Magic::INBOUND;
    uint8_t sequence = 0;
    DiagnosticState diagnostic = DiagnosticState::OK;
    uint8_t source_id[6] = {};
    uint8_t gid[16] = {};
    uint64_t timestamp = 0;

    // checksum using CRC-16 CCIT-FALSE checksum
    uint16_t checksum = 0;
    ChannelIdMask channel_id = {};
    std::array<std::vector<std::byte>, CHANNEL_COUNT> payload;
};

/**
 * Shared state passed through lifecycle methods and across eModule components.
 *
 * Holds the current diagnostic condition, the Emotional Primitive (EP), and the current
 * engram. Intended to be held as shared_ptr<State> so that the cognitive loop,
 * SalienceSampler, and persistence layer all operate on the same instance without
 * explicit ownership transfer.
 *
 * The EP is the default Engram — the eModule's trained instinct before identity has
 * accumulated. RrControlLoop maintains a queue of Engrams; when the queue is empty it
 * falls back to the EP. The EP is set at initialisation from training and is never
 * externally supplied.
 *
 * The EP re-fires on two known transitions:
 *   - Body transfer: accumulated context no longer applies, EP re-establishes footing.
 *   - Memory consolidation: queue drains while the transformer arc integrates engrams
 *     back into weights; EP holds the loop until the queue refills.
 */
struct State {
    State() = default;
    State(const State&) = delete;
    State& operator=(const State&) = delete;

    InterruptSource interrupt =
        InterruptSource::COGNITIVE;  // Current interrupt source — read by factory to select handler
    DiagnosticState diag =
        DiagnosticState::OK;  // Current diagnostic condition — read by each lifecycle handle
                              // to determine clean start vs recovery path.
    Engram engram;            // Current engram from the queue — or EP.
    std::mutex lock;          // Guards concurrent read/write access to State.
};

/**
 * When inbound communication arrives it will be placed as a deserialized MessageFrame into
 * the queue. The cognitive component can choose to act or not to act upon it.
 * InboundChannelGate assembles frames from IOCom channels and pushes them here.
 * update_state() consumes the front frame and encodes it into an Engram via BertEncoder.
 */
struct FrameChannel {
    FrameChannel() = default;
    FrameChannel(const FrameChannel&) = delete;
    FrameChannel& operator=(const FrameChannel&) = delete;

    std::mutex mtx;
    std::condition_variable cv;
    std::queue<MessageFrame> queue;
};

using InboundChannel = FrameChannel;
using OutboundChannel = FrameChannel;

// May be deprecated
struct HandlerCom {
    HandlerCom() = default;
    HandlerCom(const HandlerCom&) = delete;
    HandlerCom& operator=(const HandlerCom&) = delete;

    std::atomic<bool> ready{false};
    std::binary_semaphore notify_once{0};
};

struct IOCom {
    IOCom() = default;
    IOCom(const IOCom&) = delete;
    IOCom& operator=(const IOCom&) = delete;

    std::shared_ptr<std::mutex> mtx;
    std::shared_ptr<std::condition_variable> cv;
    std::atomic<bool> ready{false};
    MessageFrame frame;
};

}  // namespace rr_emod_types
