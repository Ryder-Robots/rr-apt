// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots

#ifndef RR_EMOD_SERDE_ENGRAM_CACHE_HPP
#define RR_EMOD_SERDE_ENGRAM_CACHE_HPP

#include <Eigen/Dense>
#include <functional>
#include <memory>
#include <optional>
#include <rr_emod_serde/engram.hpp>
#include <rr_emod_serde/rr_emod_types.hpp>
#include <rr_emod_serde/rr_logger.hpp>
#include <rr_emod_serde/rr_store.hpp>
#include <span>
#include <unordered_map>
#include <vector>

namespace rr_emod_serde {

// The engram corpus: one append-only log, plus whatever is resident in RAM.
//
// There is no separate index file. Records carry their own length and CRC, so the
// id -> offset map is rebuilt by walking the log at boot, and cannot disagree with
// the corpus the way a second file could.
//
// Writes are appends. An engram whose metadata changed is appended again and the
// later record wins; compact() drops the superseded ones at a consolidation
// boundary. Nothing that is not in RAM is ever rewritten, which is what stops a
// partially loaded session from shrinking the corpus to what it happened to touch.
class EngramCache {
public:
    // The only path that hands back a cache whose index has been built, and now the
    // only path that hands back one at all — the constructor is private below.
    // load_index() is fallible and a constructor has no channel to say so, so the walk
    // happens here: nullptr means the corpus is on disk and unreadable, and no
    // half-built cache escapes. A corpus that has never been written is not a failure.
    static std::unique_ptr<EngramCache> create(const std::string& engram_file,
                                               RrLogger& logger);

    ~EngramCache() = default;

    EngramCache(const EngramCache&) = delete;
    EngramCache& operator=(const EngramCache&) = delete;

    // Get engram from cache or disk. Returns nullptr if not found.
    rr_emod_types::Engram* get(const rr_emod_types::EngramID& id);

    // Add engram to cache. Never evicts, signals capacity state instead.
    void add(rr_emod_types::Engram&& engram);

    // Check current cache utilization.
    // Capacity check: call capacity_state() before/after consolidation
    rr_emod_types::CapacityState capacity_state() const;

    // No engrams anywhere — in RAM or on disk. The cold-start question: true here
    // means this brain has never stored anything, not that nothing is loaded yet.
    bool empty() const;

    // Nothing in RAM to write. Separate from empty() because "no work to persist"
    // and "no memories at all" are different questions and were once the same call.
    bool resident_empty() const;

    // Find engram closest to query vector. Searches everything known — resident and
    // on disk — lazy-loading as needed, and skips dormant engrams by decay.
    // current_session: session counter from XLSTMMemory for decay calculations
    //
    // out is written if and only if Ok is returned; on every other result the caller's
    // engram is left as it was.
    //
    //   Ok                 out holds the match
    //   Absent             nothing matched, or nothing is stored yet — not a fault
    //   NotFinite          the query is poison; the corpus was not searched
    //   InvalidQuery       the query is empty or has no direction
    //   DimensionMismatch  every stored engram is a different width to the query
    //   IoError/Denied/    the corpus stopped being readable partway through. The
    //     NoSpace          search is abandoned rather than answered from the part
    //                      that loaded, because a confident answer off half a corpus
    //                      is worse than no answer.
    //   Internal           this class disagreed with itself; the recall is void
    //
    // A single unreadable record is none of these: it is skipped and the search
    // continues, because one rotted engram must not cost the recall.
    RrStore::Result find_closest(const Eigen::VectorXf& query, std::uint64_t current_session,
                                 rr_emod_types::Engram& out);

    // Rebuild the id -> offset map by walking the log (call at boot).
    RrStore::Result load_index();

    // Hands every engram in the corpus to fn, current version only, without caching
    // any of them. Boot recovery has to inspect the whole corpus to find its work,
    // and pulling it into RAM to do so would defeat the point of a lazy cache.
    // Reads through the index, so load_index() has to have run.
    RrStore::Result scan(const std::function<void(const rr_emod_types::Engram&)>& fn) const;

    // Append every resident engram, durably. Never truncates, so an engram that was
    // not loaded this session cannot be lost by a session that did not touch it.
    //
    // skipped counts the resident engrams that would not serialize. They are a brain
    // fault, not a storage one, so they do not stop the flush and do not colour the
    // Result — the corpus is still written correctly for everything else. It is an
    // out-parameter rather than a return so that the storage verdict stays the
    // return, and it is always assigned, including on the failure paths.
    RrStore::Result persist(std::size_t& skipped);

    // Drop superseded versions of every engram and reclaim the space. Atomic: the
    // log is rewritten under a temp name and swapped in. Consolidation-boundary work.
    //
    // Rebuilds the index before returning: every offset it held points into a corpus
    // that no longer has it. A non-Ok result therefore means the index may describe a
    // layout that is gone, which is why the status has to reach the caller.
    RrStore::Result compact();

    // Serialize engram to bytes for writing to disk.
    static std::vector<std::byte> serialize(const rr_emod_types::Engram& engram);

    // Deserialize bytes to engram. nullopt means the record did not describe itself
    // consistently and was refused — previously signalled by handing back an engram
    // with an empty embedding, which every caller had to remember to test.
    static std::optional<rr_emod_types::Engram> deserialize(std::span<const std::byte> bytes);

    // Bytes this engram occupies on disk. The only place the record layout is counted:
    // serialize() reserves with it, get_serialized_size() sums it, and deserialize()
    // checks the wire against the same arithmetic.
    static std::size_t record_bytes(const rr_emod_types::Engram& engram);

    size_t get_serialized_size() const;

    // Read-only view of the resident engrams (the in-memory working set: this
    // session's promoted + retrieved engrams). Used by consolidation to walk the
    // set that gets written to the training TFRecord.
    const std::unordered_map<rr_emod_types::EngramID, rr_emod_types::Engram>& entries() const {
        return cache_;
    }

    // Reset: flush the resident set, then clear it for the next session. The clear is
    // conditional on the flush succeeding — a reset that drops RAM after a failed
    // persist() loses precisely what it was called to save.
    RrStore::Result reset();

    // clear(): drop the in-RAM cache WITHOUT flushing (caller is responsible for having
    // persisted first; persist() then clear() == reset()).
    void clear();

private:
    // Private so that create() is the only way in: a cache built here and not walked
    // has an empty index and a corpus full of records, and would append into a log
    // whose earlier records nobody can reach. The constructor cannot do the walk
    // itself because the walk can fail and it has nowhere to say so.
    EngramCache(const std::string& engram_file, RrLogger& logger);

    // Below this magnitude a vector has no direction worth measuring, so cosine
    // similarity against it is noise divided by noise. A geometric floor on the
    // embedding axis and nothing else — it is not rr_model_utils::S_FLOOR, which
    // floors salience, and the two must not be merged because they happen to agree
    // on a number.
    static constexpr float kVectorNormEpsilon = 1e-6F;

    // The weakest match worth returning, not a seed for the running best. At zero an
    // engram must point at least somewhat the same way as the query; a negative
    // cosine means the query points away from that memory, and the nearest thing
    // pointing away is not a recall — it is a miss with a number attached.
    static constexpr float kMinimumSimilarity = 0.0F;

    // Two maps, and deliberately not three. There was a metadata_ map beside these
    // carrying a `loaded` flag and an access count: the flag was written twice and
    // read nowhere, and the count was never touched at all. `loaded` is anyway not a
    // fact of its own — it is `cache_.count(id) != 0` — so keeping it was keeping a
    // second answer to a question that already had one, which is how the two drift.
    std::unordered_map<rr_emod_types::EngramID, rr_emod_types::Engram> cache_;
    std::unordered_map<rr_emod_types::EngramID, rr_emod_types::IndexEntry> index_;

    RrLogStore corpus_;

    size_t max_cache_size_;

    size_t compute_max_cache_size() const;

    // nullopt with the reason in result: Absent when the id is not in the index at
    // all, otherwise whatever the corpus said, or Corrupt when the bytes came back
    // but did not deserialize. result is assigned on every path.
    [[nodiscard]] std::optional<rr_emod_types::Engram> lazy_load_from_disk(
        const rr_emod_types::EngramID& id, RrStore::Result& result);

    // The id sits in the last 16 bytes of a record, so the boot walk can index
    // without deserializing an embedding it may never need.
    static bool id_of(std::span<const std::byte> record, rr_emod_types::EngramID& out);

    // The three variable-length fields of a record, taken from its own prefixes.
    struct RecordExtent {
        std::uint32_t raw_len = 0;
        std::uint32_t key_elems = 0;
        std::uint32_t sal_len = 0;
    };

    // Resolves a record's exact size from its length prefixes before any payload is
    // read. False means the prefixes and the record's actual length disagree.
    static bool record_extent(std::span<const std::byte> bytes, RecordExtent& out);

    // Borrowed, not owned. The cache is one of many voices in a single session log,
    // so there is exactly one ring and this object is not its owner.
    RrLogger& logger_;
};

}  // namespace rr_emod_serde

#endif  // RR_EMOD_SERDE_ENGRAM_CACHE_HPP
