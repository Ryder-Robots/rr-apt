// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_EMOD_TYPES_HPP
#define RR_EMOD_SERDE_RR_EMOD_TYPES_HPP
#include <Eigen/Dense>
#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <queue>
#include <semaphore>
#include <string>
#include <string_view>
#include <vector>

#include <rr_emod_serde/engram.hpp>

namespace rr_emod_types {

// Maximum size of inbound bytes per channel. Based on image size after
// pre-processing, which is expected to be handled by the robot body hardware.
// Anything larger than this size will generate a diagnostic message WTAF.
constexpr std::size_t MAX_CHANNEL_BYTES = 224 * 224 * 3;

// named constant, needed in types
constexpr size_t BRANCH_DIM = 128;

// compution on when affectiveness of an engram when can be used for saliwence.
constexpr float W_AFFECTIVENESS = std::numeric_limits<float>::min() * 10.0f;

constexpr float ABSENT_SALIENCE = 0.5;

// Steady-state cadence for the brain's own loops — the control loop and the supervisor both
// wake at this rate when nothing else has woken them.
//
// A loop that waits ONLY on a predicate has no floor: if the predicate is ever true at rest
// (a level rather than an edge) it stops blocking and burns a core. That has now happened
// twice in the control loop's wait — once on is_consolidating_ (EXP-0021 R1) and once on the
// cognitive state. A stated tick makes the failure mode "wakes at 50 Hz" instead of "spins",
// and it is what a periodic duty like capacity polling actually needs: an idle brain with a
// filling disk must still notice, and no event will tell it.
//
// 50 Hz. Changing this changes both the idle CPU floor and the worst-case latency for
// noticing anything nobody signals — it is a control-loop parameter, not a magic number.
constexpr std::chrono::milliseconds LOOP_TICK{20};

/**
 * Diagnostic state returned by life cycle methods
 */
enum class DiagnosticState : uint8_t {
    OK = 0,     // All good
    WTF = 1,    // Framing error — something unexpected
    WTAF = 2,   // Integrity failure — checksum mismatch or protocol violation
    FUBAR = 3,  // Unrecoverable — emodule needs attention
};

/**
 * The running machine's mode — what it is FOR right now. ARM is inference;
 * CONSOLIDATE parks inference so training can run over a quiet machine.
 * UNSET is the boot door and the teardown floor: everything starts there and
 * returns there last, but nothing running is ever sent there.
 */
enum class Mode : uint8_t { UNSET, ARM, CONSOLIDATE };

/**
 * SALIENCE occurs in its own loop, it writes directly to inbound queue. Monitoring
 * both TPU/CPU/GPU spikes, and passivly monitoring PROPRIOCEPTION for low battery
 * or other intestering events, when found injects a salient weight into them
 */
enum class InterruptSource : uint8_t {
    COGNITIVE = 0,       // No external interrupt — cognitive cycle, EP or queue
    OUTPUT_CHANNEL = 1,  // eModule issuing a command to the robot body
    SERIALIZATION = 2,   // SerializationRequestor has something to store
    SALIENCE = 3,  // SalienceSampler detected TPU/CPU/GPU pattern that indicates SALIENT trigger
    SHUTDOWN = 4,  // Clean shutdown — factory triggers deactivate and cleanup
    MEMORY_RETRIEVAL = 5,  // Request to retrieve memory.

    INPUT_CHANNEL = 6,  // external input arrives.
};

/**
 * Channel identifier — the SENSES index into a MessageFrame payload array.
 *
 * Use static_cast<size_t>(ChannelId::X) to index MessageFrame::payload directly.
 */
enum class ChannelId : size_t {
    VISION = 0,
    AUDIO = 1,
    PROPRIOCEPTION = 2,
    EXTEROCEPTION = 3,
    TEXT = 4,
    PEER = 5,

    // COUNT bounds THE SENSES ONLY, and it is NOT free to change: CHANNEL_COUNT is a
    // TRAINED WEIGHT DIMENSION. Cognition's fuse layer is Linear(CHANNEL_COUNT *
    // BRANCH_DIM -> EMBEDDING_DIM) and its absent_ parameter is CHANNEL_COUNT x
    // BRANCH_DIM; the hippocampus salience matrices (S_short_/S_long_) are CHANNEL_COUNT
    // rows wide. Moving this number resizes all of them — it invalidates every trained
    // checkpoint AND every stored engram, so it is a retrain plus a store migration, not
    // an edit. A NEW SENSE goes BEFORE this line and pays that price.
    COUNT = 6,

    // Past the sentinel DELIBERATELY — COUNT is no longer the last enumerator, and the
    // gap at 6 is intentional: COUNT's own value is used as the unbound/null sentinel by
    // cortex sockets, so nothing else may share it.
    //
    // MEMORY is a SERVICE, not a wire. It gets no payload slot, no ChannelIdMask bit and
    // no gate slot, because it carries no sensory frame — it is the engram/prompt request
    // path, which funnels into the two request mailboxes and whose responses route back by
    // correlation_id, never through the per-channel array. Consequently the one-peer-per-
    // channel rule and ADDRESS_IN_USE do NOT apply here: many cortexes may connect, and
    // concurrency is raised by adding connections. It is separated out precisely so a
    // slow engram lookup cannot stall a sense.
    //
    // Every `< COUNT` guard in the tree (receiver()'s precondition, the sender_id range
    // check in InferenceMemoryIO) therefore excludes MEMORY on purpose. That is the
    // design, not an oversight — do not "fix" them to admit it.
    MEMORY = 7,
    FRONTAL = 8,
};

constexpr size_t CHANNEL_COUNT = static_cast<size_t>(ChannelId::COUNT);

// True for the frontal-side SERVICES — the channels past the COUNT sentinel.
//
// Everything below COUNT is a sense: one wire, one peer, and a second dialer is
// ADDRESS_IN_USE. Everything above it is a request path that many cortexes share
// (MEMORY for engram retrieval, FRONTAL for prompts), where a second dialer is
// how you add concurrency, not a collision. Any one-peer guard must ask THIS,
// not `== MEMORY` — that spelling silently omits FRONTAL and turns the sixth
// cortex's dial into a bogus ADDRESS_IN_USE.
//
// COUNT itself is neither: it is the unbound sentinel and is never on the wire.
constexpr bool is_service(ChannelId c) noexcept { return c > ChannelId::COUNT; }

// The OPERATIONAL protocol version — what both ends promise to speak on
// CortexEnvelopes. Bump on any breaking change to envelope or payload semantics
// (the contract stated on CortexEnvelope in inferenceio.proto).
//
// IT IS NOT THE HANDSHAKE'S VERSION. connectio.proto is deliberately its own
// plane on its own cadence: the handshake can stay frozen while the operational
// wire evolves, and neither drags a bump onto the other. This number is the one
// the handshake DECLARES and gates on — OpenChannel.wire_protocol_version — so
// that build skew between two physically separate boards becomes a loud
// CONN_STATUS_VERSION_MISMATCH before a single data envelope flows, rather than
// a misparse a week later. In-process the check is vacuous (one build, both
// ends), but every envelope still carries the truth.
//
// LIVES HERE, in the leaf types header, and NOWHERE ELSE. It was in
// cortex_transport.hpp, which meant the connect plane had to include a
// session-layer interface to learn a number; a second copy is how the two planes
// silently disagree about what they are speaking.
//
// v2 (2026-07-26): control plane removed — the envelope carries exactly two
// requests (engram_query, prompt) and two responses (engram_result,
// prompt_response); oneof arms 20-22 and STATUS_QUIESCING retired.
inline constexpr uint32_t kProtocolVersion = 2;

enum class ChannelIdMask : uint8_t {
    VISION = 0x01,
    AUDIO = 0x02,
    PROPRIOCEPTION = 0x04,
    EXTEROCEPTION = 0x08,
    TEXT = 0x10,
    PEER = 0x20,
};

enum class CognitiveState : size_t {
    CONTEMPLATING = 0,  // deliberation in progress — control loop waits
    REQUEST = 1,        // retrieve from mLSTM → inject result → back to CONTEMPLATING
    STORING = 2,        // write to mLSTM → back to CONTEMPLATING, no output
    OUTBOUND = 3,       // write to mLSTM + decode + dispatch to robot body
    READY = 4           // waiting for next inbound engram
};

enum class CapacityState : uint8_t {
    OK = 0,       // < 70% of any resource (memory, battery, bandwidth, etc.)
    WARNING = 1,  // 70-85% — consolidation should happen soon
    URGENT = 2,   // 85-95% — consolidation needed now
    CRITICAL = 3  // > 95% — machine must consolidate before accepting new input
};

/** Wire protocol direction marker — readable in hex dumps. */
enum class Magic : char {
    INBOUND = '>',
    OUTBOUND = '<',
    ERROR = '!',
};

/**
 * Wire protocol frame carrying sensory input from robot body to eModule.
 *
 * Received on any of the physical input channels. The payload is modality-agnostic —
 * the eModule determines content through cognition, not through channel labelling.
 * Magic byte identifies frame direction for wire-level debugging.
 * GID provides diagnostic traceability — reported in WTF/WTAF conditions.
 *
 * Expected physical channels (5 + 1 peer):
 *   - Vision          — CSI interface, perceptual TPU preprocessed before reaching eModule
 *   - Audio           — I2S interface, feature extracted before reaching eModule
 *   - Proprioception  — I2C, IMU, encoders, joint state, what the body is doing
 *   - Exteroception   — I2C, proximity, touch, pressure, what the environment is doing
 *   - Text            — I2C, body-designer chat, reconfiguration commands, metacognitive output
 *   - Peer            — eModule to eModule via WiFi, no dedicated physical channel needed
 *
 * Physical interface: CM5 GPIO ribbon to edge connector (cartridge-style), exposed and
 * field-serviceable. Gold contacts, keyed for single orientation. Channels route via
 * carrier board to CSI, I2S, and I2C buses on the CM5.
 */
struct MessageFrame {
    MessageFrame() = default;
    MessageFrame(const MessageFrame&) = delete;
    MessageFrame& operator=(const MessageFrame&) = delete;
    MessageFrame(MessageFrame&&) = default;
    MessageFrame& operator=(MessageFrame&&) = default;

    Magic magic = Magic::INBOUND;
    uint8_t sequence = 0;
    DiagnosticState diagnostic = DiagnosticState::OK;
    uint8_t source_id[6] = {};
    uint8_t gid[16] = {};
    uint64_t timestamp = 0;

    // checksum using CRC-16 CCIT-FALSE checksum
    uint16_t checksum = 0;
    ChannelIdMask channel_id = {};
    std::array<std::vector<std::byte>, CHANNEL_COUNT> payload;
};

/**
 * Shared state passed through lifecycle methods and across eModule components.
 *
 * Holds the current diagnostic condition, the Emotional Primitive (EP), and the current
 * engram. Intended to be held as shared_ptr<State> so that the cognitive loop,
 * SalienceSampler, and persistence layer all operate on the same instance without
 * explicit ownership transfer.
 *
 * The EP is the default Engram — the eModule's trained instinct before identity has
 * accumulated. RrControlLoop maintains a queue of Engrams; when the queue is empty it
 * falls back to the EP. The EP is set at initialisation from training and is never
 * externally supplied.
 *
 * The EP re-fires on two known transitions:
 *   - Body transfer: accumulated context no longer applies, EP re-establishes footing.
 *   - Memory consolidation: queue drains while the transformer arc integrates engrams
 *     back into weights; EP holds the loop until the queue refills.
 */
struct State {
    State() = default;
    State(const State&) = delete;
    State& operator=(const State&) = delete;

    InterruptSource interrupt =
        InterruptSource::COGNITIVE;  // Current interrupt source — read by factory to select handler
    DiagnosticState diag =
        DiagnosticState::OK;  // Current diagnostic condition — read by each lifecycle handle
                              // to determine clean start vs recovery path.
    Engram engram;            // Current engram from the queue — or EP.
    std::mutex lock;          // Guards concurrent read/write access to State.
};

/**
 * When inbound communication arrives it will be placed as a deserialized MessageFrame into
 * the queue. The cognitive component can choose to act or not to act upon it.
 * InboundChannelGate assembles frames from IOCom channels and pushes them here.
 * update_state() consumes the front frame and encodes it into an Engram via BertEncoder.
 */
struct FrameChannel {
    FrameChannel() = default;
    FrameChannel(const FrameChannel&) = delete;
    FrameChannel& operator=(const FrameChannel&) = delete;

    std::mutex mtx;
    std::condition_variable cv;
    std::queue<MessageFrame> queue;
};

using InboundChannel = FrameChannel;
using OutboundChannel = FrameChannel;

// May be deprecated
struct HandlerCom {
    HandlerCom() = default;
    HandlerCom(const HandlerCom&) = delete;
    HandlerCom& operator=(const HandlerCom&) = delete;

    std::atomic<bool> ready{false};
    std::binary_semaphore notify_once{0};
};

struct IOCom {
    IOCom() = default;
    IOCom(const IOCom&) = delete;
    IOCom& operator=(const IOCom&) = delete;

    std::shared_ptr<std::mutex> mtx;
    std::shared_ptr<std::condition_variable> cv;
    std::atomic<bool> ready{false};
    MessageFrame frame;

    // Wake hook, installed by whatever carries this slot off-board (a cortex socket
    // at bind()), left empty when nothing does. Its PRESENCE is the liveness signal —
    // no separate connected flag exists, and a write to a slot with no hook is a
    // no-op by design, which is what makes a degraded run free rather than merely
    // tolerated. Set before the owning gate activates, never mutated after; the
    // installer must clear it before it dies. MUST NOT BLOCK: it runs on the gate's
    // thread, so a blocking hook stalls every other channel.
    std::function<void()> on_ready;
};

// hardware mappings
struct Endpoint {
  std::uint32_t ip;    // host byte order — convert with htonl at use
  std::uint16_t port;
};


// BASE_PORT must sit BELOW Linux's ephemeral range, which starts at 32768
// (net.ipv4.ip_local_port_range). Above it, an outgoing connection can grab one
// of these as a SOURCE port before the listener binds, and the failure is an
// intermittent EADDRINUSE on a different channel every boot, tied to nothing the
// operator can see. The first draft used 50051..50058 and sat inside that range.
//
// 16-ALIGNED DELIBERATELY: every ChannelId fits in 4 bits (max is FRONTAL = 8),
// so BASE_PORT + id and BASE_PORT | id are the SAME number. If the map is ever
// replaced by a derivation, the two forms cannot silently disagree.
inline constexpr std::uint16_t BASE_PORT = 0x7000;  // 28672
static_assert(BASE_PORT % 16 == 0, "BASE_PORT must be 16-aligned so + and | agree");
static_assert(BASE_PORT + 16 < 32768, "channel ports must sit below the ephemeral range");

// IP identifies the SLOT; PORT identifies the CHANNEL. Both are needed: slot 1
// carries VISION and AUDIO on one address, so the port is the only thing that
// separates them. The address belongs to the slot, not the module — swap a CM5
// and the replacement answers here unchanged (HARDWARE-0009 §12.1).
inline const std::unordered_map<ChannelId, Endpoint>& channel_map() {
  static const std::unordered_map<ChannelId, Endpoint> m{

    // Audio / Vision on CM5 slot 1 — 192.168.1.141
    {ChannelId::VISION,         {0xC0A8018D, BASE_PORT + 0}},   // 28672
    {ChannelId::AUDIO,          {0xC0A8018D, BASE_PORT + 1}},   // 28673

    // sensory input and output on CM5 slot 2 — 192.168.1.142
    {ChannelId::PROPRIOCEPTION, {0xC0A8018E, BASE_PORT + 2}},   // 28674
    {ChannelId::EXTEROCEPTION,  {0xC0A8018E, BASE_PORT + 3}},   // 28675

    // Text and PEER on CM5 slot 3 — 192.168.1.143
    {ChannelId::TEXT,           {0xC0A8018F, BASE_PORT + 4}},   // 28676
    {ChannelId::PEER,           {0xC0A8018F, BASE_PORT + 5}},   // 28677

    // FRONTAL server, MEMORY and prompt handling — 192.168.1.144.
    // NOTE THE GAP AT BASE_PORT + 6: that is COUNT, the unbound sentinel, and it
    // is never a channel. MEMORY and FRONTAL sit past it, exactly as the enum does.
    {ChannelId::MEMORY,         {0xC0A80190, BASE_PORT + 7}},   // 28679
    {ChannelId::FRONTAL,        {0xC0A80190, BASE_PORT + 8}}    // 28680
  };
  return m;
}


}  // namespace rr_emod_types

#endif  // RR_EMOD_SERDE_RR_EMOD_TYPES_HPP
