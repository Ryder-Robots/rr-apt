// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <debug/debugio.pb.h>

#include <rr_emod_serde/rr_cognition_com.hpp>  // DiagStats
#include <rr_emod_serde/rr_emod_types.hpp>     // DiagnosticState / CapacityState / CognitiveState
#include <rr_emod_serde/rr_ledger.hpp>         // EngramSessionMeta
#include <rr_emod_serde/rr_logger.hpp>         // rr_log_item
#include <rr_emod_serde/supervisor.hpp>        // ConsilidationState

// ---------------------------------------------------------------------------
// The DEBUG channel's C++ face: accept a debugio.proto ObservationEnvelope,
// produce the report. Read-only observation of the RUNNING bot — its VITALS,
// never its MIND.
//
// EXISTENCE IS THE CONSENT. Nothing here is standing infrastructure. The bot
// that never chose debug mode holds a NullDebugPort (below) — a port that
// answers every question with "not engaged" and touches no brain state. The
// observing port (LiveDebugPort) is constructed only on debug-mode entry. So a
// cable in the debug socket of a bot that did not consent reaches an object
// that is DELIBERATELY BLIND, and one that did not even choose to be blind
// reaches nothing. The dummy is present so the robot never null-derefs a
// mis-wired debug path (fail-safe, not fail-crash); the real observer is
// present only by consent.
//
// OBSERVATION IS DONE *TO* THE BOT, NOT ADVERTISED BY IT. The supervisor does
// not implement an observability interface — that would bake "I can be watched"
// into its identity. Instead a DebugSource sits OUTSIDE it, holds a handle to
// it, and reaches in through the existing cmd_* readers. The supervisor stays
// ignorant of being observed (the agency line: channels are what I am ASKED;
// debug is what is DONE TO me).
//
// NOT the DIAGNOSTIC runlevel: that is the hidden physical port, non-proto,
// entered at boot with cognition parked. Nothing here reaches it. The lifetime
// bracket enforces the split for free — the mailbox and the live port live
// between on_activate() and on_deactivate(), so this channel answers only while
// the brain is RUNNING. A wedged or parked brain is the diagnostic channel's
// job, never this one.
//
// BINDING SURFACE (all Python glue lives in the harness repo, never here). The
// shapes below are the API-contract that survives the nanobind boundary:
// DebugPort is a virtual interface the harness can call or (for a harness-side
// fake) subclass via trampoline; DebugMailbox mirrors InferenceMailbox — value
// semantics, optional returns, bounded take_wait, fail-closed close()/reopen().
// ---------------------------------------------------------------------------

namespace rr_emod_serde {

// Forward-declared: only SupervisorDebugSource's IMPLEMENTATION needs the
// complete type (to call cmd_*), and it lives in the .cpp. Keeping the concrete
// supervisor out of this header keeps the brain (and torch) from following it.
class RrSupervisor;

// The debug wire versions independently of the cortex/operational wire (leaf
// rule, debugio.proto). Stamped onto every report; bumped only when the
// observation vocabulary changes, never for an operational proto change.
inline constexpr uint32_t kDebugProtocolVersion = 1;

/**
 * The read-only projection of the supervisor's observable state — one accessor
 * per debugio subject. "Read-only by vocabulary": the guarantee is the ABSENCE
 * of any mutating verb here, not const-ness (the underlying cmd_* are non-const
 * and one, cmd_drain_diag, is destructive — see diag_stats). A LiveDebugPort
 * only ever holds a DebugSource, so from the wire side a mutation is unreachable
 * by type; the fully-const read-view that would make the reads const too is the
 * "very technical" option, deliberately NOT taken.
 *
 * Abstract for the same reason CortexTransport is: the concrete supervisor-
 * backed source (SupervisorDebugSource) is what gets constructed on debug
 * entry, while a fake stands in to unit-test the port's subject->wire mapping
 * against canned readings, and a remote source is where "fan out to hardware"
 * would land. Every accessor must read a LOCK-FREE snapshot — never the
 * cognitive loop's locks (debugio.proto: "drained/atomic copies"; the
 * instrument must not steal a tick).
 */
class DebugSource {
public:
    virtual ~DebugSource() = default;

    // MODE — current runlevel.
    // ⚠ GAP: no SupervisorMode enum exists yet (the one debug subject still
    // blocked on a data-structure decision — its set couples to the runlevel
    // model, and to the "may I build a LiveDebugPort" transition). Returned as
    // the wire scalar until the enum is homed in rr_emod_types; the deliberate
    // inconsistency with the typed accessors below MARKS the gap.
    virtual uint32_t mode() = 0;

    // DIAG_STATE — per-component health, one snapshot. (name, DiagnosticState)
    virtual std::vector<std::pair<std::string, rr_emod_types::DiagnosticState>>
    component_diag() = 0;

    // CAPACITY / COGNITIVE / CONSOLIDATION — canonical scalar states.
    virtual rr_emod_types::CapacityState capacity() = 0;
    virtual rr_emod_types::CognitiveState cognitive() = 0;
    virtual ConsilidationState consolidation() = 0;

    // DIAG_STATS — NON-draining image of the running sums.
    // ⚠ GAP: the supervisor only has the DRAINING cmd_drain_diag (it resets the
    // sums). This needs a non-destructive peek (split cmd_drain_diag into
    // peek + reset); the draining verb must never be reachable from here.
    virtual DiagStats diag_stats() = 0;

    // LEDGER_META — ledger counters only, never engram content.
    virtual EngramSessionMeta ledger_meta() = 0;

    // LOG_TAIL — records with absolute seq > cursor, oldest first, at most
    // max_items. seq is the record's monotonic absolute position (the ring
    // holds a trailing window and carries no seq — the source mints it from a
    // total-records counter the logger must grow; that counter is the remaining
    // LOG_TAIL gap). Contiguity lets one first_seq label the page:
    // record[i].seq == first_seq + i, next_cursor == first_seq + size.
    struct LogTail {
        std::vector<rr_log_item> records;  // oldest first
        uint64_t first_seq = 0;            // absolute seq of records.front()
        uint64_t next_cursor = 0;          // pass back as cursor to continue
        bool truncated = false;            // ring overwrote between cursor and oldest kept
    };
    virtual LogTail log_tail(uint64_t cursor, uint32_t max_items) = 0;
};

/**
 * The concrete source wired to a live brain — the observer that reaches in.
 * Constructed on debug entry with a non-owning reference to the supervisor it
 * watches. Every accessor forwards to the supervisor's cmd_* readers.
 *
 * ⚠ IMPLEMENTATION DEFERRED to the supervisor-wiring step (after the IO-into-
 * ctor move). It is DECLARED here because it is the shape Aaron's redirection
 * settled — source outside the supervisor, holding a handle, calling commands
 * itself — and declaring it now is the design record of that decision. Its
 * three blockers are the three GAPs noted above: SupervisorMode (mode()), a
 * non-draining diag peek (diag_stats()), and the logger's total-records counter
 * (log_tail()). Until those land and the supervisor constructs one, this class
 * is never instantiated, so the absent .cpp definitions cost nothing.
 */
class SupervisorDebugSource : public DebugSource {
public:
    explicit SupervisorDebugSource(RrSupervisor& supervisor) : supervisor_(supervisor) {}

    uint32_t mode() override;
    std::vector<std::pair<std::string, rr_emod_types::DiagnosticState>> component_diag() override;
    rr_emod_types::CapacityState capacity() override;
    rr_emod_types::CognitiveState cognitive() override;
    ConsilidationState consolidation() override;
    DiagStats diag_stats() override;
    EngramSessionMeta ledger_meta() override;
    LogTail log_tail(uint64_t cursor, uint32_t max_items) override;

private:
    // Non-owning: the supervisor outlives this session. It is ALSO what keeps
    // the ownership acyclic — the supervisor holds shared_ptr<DebugPort>, the
    // port holds shared_ptr<DebugSource>; if this back-edge to the supervisor
    // were a shared_ptr too it would close a leak-cycle. A raw reference is the
    // deliberate break in the ring.
    RrSupervisor& supervisor_;
};

/**
 * The debug channel's single-slot, latest-wins inbox — the async seam between
 * the thread that RECEIVES a query (the Python binding, or the wire listener
 * when it lands) and the thread that ANSWERS it (the supervisor's run_loop).
 *
 * ONE SLOT, LATEST WINS. post() overwrites any unanswered query; there is no
 * queue. Not a limitation to apologise for — it is "one question, one answer"
 * made structural. Safe ONLY because every query is a side-effect-free read
 * (debugio.proto, read-only by vocabulary): dropping a superseded query loses
 * nothing but a repeat of a pure read, and it bounds a chatty observer to its
 * own channel — it can never make run_loop fall behind cognition. The single
 * slot PRESUMES a synchronous observer (one query outstanding); two in flight
 * and you meant to lose one.
 *
 * QUERY-ONLY, ONE DIRECTION. The report does not return through here — the
 * synchronous binding gets it as serve()'s return value; the wire path sends
 * it back over the transport. The mailbox carries the question across the
 * thread boundary, nothing more.
 *
 * Binding-shaped like InferenceMailbox. (Harness note: a take_wait binding must
 * release the GIL, same as the cortex pop_wait, or a parked run_loop starves
 * every Python thread.)
 */
class DebugMailbox {
public:
    DebugMailbox() = default;
    DebugMailbox(const DebugMailbox&) = delete;
    DebugMailbox& operator=(const DebugMailbox&) = delete;
    DebugMailbox(DebugMailbox&&) = delete;
    DebugMailbox& operator=(DebugMailbox&&) = delete;

    // Producer (binding / wire listener). Overwrites the slot; latest wins,
    // silently — the overwrite is the contract, not a fault. Returns false and
    // leaves the slot untouched only when the mailbox is closed (the query is
    // dropped; a closed debug channel is not answering).
    bool post(rr_debug::ObservationEnvelope query);

    // Consumer (run_loop). Non-blocking take — empty most ticks.
    std::optional<rr_debug::ObservationEnvelope> try_take();

    // Consumer, reactive variant: park until a query arrives, the timeout
    // elapses, or the mailbox closes. nullopt = nothing to serve (timed out or
    // closed) — never a fault.
    std::optional<rr_debug::ObservationEnvelope> take_wait(std::chrono::milliseconds timeout);

    // Wake any parked consumer; subsequent take_wait returns nullopt until
    // reopen(). Called from on_deactivate / on_shutdown — the SAME lifetime
    // bracket that governs whether the debug channel answers at all.
    void close();
    void reopen();

    bool closed() const;  // port-local state, never a question asked of the brain

private:
    mutable std::mutex mutex_;
    std::condition_variable cv_;
    std::optional<rr_debug::ObservationEnvelope> slot_;
    bool closed_{false};
};

/**
 * The debug servicer interface — and THE shared-pointer type the supervisor
 * holds. Virtual on purpose: it lets a NullDebugPort stand in as the boot
 * default (so the robot never holds a null debug handle), and it is the
 * trampoline seam a harness-side fake can subclass. One question in, one answer
 * out; synchronous.
 */
class DebugPort {
public:
    virtual ~DebugPort() = default;

    /**
     * Service one query envelope, return the report envelope. A non-query arm
     * or an unserved subject is ANSWERED, never dropped (ERROR / UNSUPPORTED
     * with the correlation echoed), so a synchronous observer learns of the
     * fault instead of timing out.
     */
    virtual rr_debug::ObservationEnvelope serve(const rr_debug::ObservationEnvelope& query) = 0;
};

/**
 * The boot default and the debug-off state: a port that reveals nothing. Every
 * serve() returns OBS_STATUS_UNSUPPORTED ("debug channel not engaged"), echoing
 * the correlation and subject, touching no brain state — there is no source
 * behind it to touch. This is the "dummy to protect the robot": the supervisor
 * always holds a valid DebugPort, so run_loop never guards a null; a cable in
 * the socket of a non-consenting bot reaches THIS and learns only that the door
 * is shut.
 */
class NullDebugPort : public DebugPort {
public:
    rr_debug::ObservationEnvelope serve(const rr_debug::ObservationEnvelope& query) override;
};

/**
 * The observing port: constructed on debug-mode entry with a DebugSource.
 * Dispatches on the query's subject, reads the source's lock-free snapshot,
 * converts canonical -> wire (uint32 scalar + the canonical C++ enum as source
 * of truth, per house pattern), echoes the query's correlation onto the report,
 * and stamps kDebugProtocolVersion. Never blocks on cognition, never mutates
 * the brain.
 *
 * DELIVERY-AGNOSTIC. Today the Python harness calls serve() directly — the
 * binding IS the debug peer. Tomorrow run_loop drains a DebugMailbox query into
 * this same call. The overwrite/synchronous contract lives at the mailbox, not
 * here; serve() is the shared, pure core both paths reach.
 */
class LiveDebugPort : public DebugPort {
public:
    explicit LiveDebugPort(std::shared_ptr<DebugSource> source,
                           uint32_t protocol_version = kDebugProtocolVersion)
        : source_(std::move(source)), protocol_version_(protocol_version) {}

    rr_debug::ObservationEnvelope serve(const rr_debug::ObservationEnvelope& query) override;

private:
    // Subject switch -> report body. The one place canonical state becomes wire
    // scalars; the only place the DebugSource is read.
    rr_debug::ObservationReport dispatch(const rr_debug::ObservationQuery& query);

    std::shared_ptr<DebugSource> source_;
    uint32_t protocol_version_;
};

}  // namespace rr_emod_serde
