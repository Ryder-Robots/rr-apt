// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <memory>
#include <atomic>
#include <mutex>
#include <condition_variable>
#include "rr_emod_serde/rr_emod_types.hpp"

namespace rr_emod_serde
{
/**
 * used to provide channel between cognition and the control loop. Expected to
 * a shared pointer available to both cognition, and control loop objects.
 */

class RRCognitionCom
{
public:
  RRCognitionCom() = default;
  ~RRCognitionCom() = default;

  rr_emod_types::InterruptSource get_interrupt();
  rr_emod_types::CognitiveState get_state();
  rr_emod_types::Engram get_request();

  // intended to be only used by cognition
  void set_interrupt(rr_emod_types::InterruptSource interrupt);
  void set_state(rr_emod_types::CognitiveState state);
  void inbound(rr_emod_types::Engram inbound);
  rr_emod_types::Engram decision();
  std::mutex mtx;
  std::condition_variable cv;

protected:
  std::atomic<bool> ready_{ false };
  rr_emod_types::CognitiveState state_;
  rr_emod_types::InterruptSource interrupt_;
  rr_emod_types::Engram inbound_;
};
}  // namespace rr_emod_serde