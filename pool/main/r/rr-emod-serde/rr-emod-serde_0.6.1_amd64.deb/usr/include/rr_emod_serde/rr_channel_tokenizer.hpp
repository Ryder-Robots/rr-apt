// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_CHANNEL_TOKENIZER_HPP
#define RR_EMOD_SERDE_RR_CHANNEL_TOKENIZER_HPP

#include <cstddef>
#include <cstdint>
#include <memory>
#include <vector>

#include <rr_emod_serde/rr_emod_types.hpp>

namespace rr_emod_serde {

struct TokenisedInput {
    std::vector<uint32_t> input_ids;
    std::vector<uint8_t>  attention_mask;
    std::vector<uint8_t>  token_type_ids;
};

// Per-channel BERT input sequence lengths.
// VISION: 14×14 patch grid (16×16 px patches over 224×224 image) = 196 patches + 1 [CLS] token.
// AUDIO: mel-spectrogram frame chunks.
// PROPRIOCEPTION/EXTEROCEPTION: structured fixed-length body/environment state vectors.
// TEXT/PEER: standard WordPiece, matching BERT-base capacity.
constexpr size_t VISION_MAX_SEQ_LEN         = 197;
constexpr size_t AUDIO_MAX_SEQ_LEN          = 128;
constexpr size_t PROPRIOCEPTION_MAX_SEQ_LEN = 64;
constexpr size_t EXTEROCEPTION_MAX_SEQ_LEN  = 64;
constexpr size_t TEXT_MAX_SEQ_LEN           = 512;
constexpr size_t PEER_MAX_SEQ_LEN           = 512;

constexpr size_t channel_max_seq_len(rr_emod_types::ChannelId ch) noexcept {
    switch (ch) {
        case rr_emod_types::ChannelId::VISION:         return VISION_MAX_SEQ_LEN;
        case rr_emod_types::ChannelId::AUDIO:          return AUDIO_MAX_SEQ_LEN;
        case rr_emod_types::ChannelId::PROPRIOCEPTION: return PROPRIOCEPTION_MAX_SEQ_LEN;
        case rr_emod_types::ChannelId::EXTEROCEPTION:  return EXTEROCEPTION_MAX_SEQ_LEN;
        case rr_emod_types::ChannelId::TEXT:           return TEXT_MAX_SEQ_LEN;
        case rr_emod_types::ChannelId::PEER:           return PEER_MAX_SEQ_LEN;
        // None is a sense: COUNT is the sentinel, MEMORY and FRONTAL are services
        // with no payload. Listed rather than defaulted so a new sense breaks the build.
        case rr_emod_types::ChannelId::COUNT:          return 0;
        case rr_emod_types::ChannelId::MEMORY:         return 0;
        case rr_emod_types::ChannelId::FRONTAL:        return 0;
    }
    return 0;
}

class ChannelTokenizer {
public:
    virtual ~ChannelTokenizer() = default;

    // Tokenise raw channel bytes into BERT input format.
    // All three output vectors always have exactly max_seq_len() elements.
    // Real tokens have attention_mask=1; zero-padded trailing positions have attention_mask=0.
    // Truncates payload if it exceeds the channel's token capacity.
    virtual TokenisedInput tokenise(const std::vector<std::byte>& payload) = 0;

    // Returns the absence sentinel for this channel.
    // Must not be all-zero: the encoder uses this to distinguish absent channels
    // from zero-padded real channels. See RESEARCH-00027 §2.4.
    virtual TokenisedInput absent_sentinel() = 0;

    virtual std::size_t max_seq_len() const noexcept = 0;

    ChannelTokenizer(const ChannelTokenizer&) = delete;
    ChannelTokenizer& operator=(const ChannelTokenizer&) = delete;
    ChannelTokenizer(ChannelTokenizer&&) = default;
    ChannelTokenizer& operator=(ChannelTokenizer&&) = default;

protected:
    ChannelTokenizer() = default;
};

std::unique_ptr<ChannelTokenizer> make_channel_tokenizer(rr_emod_types::ChannelId channel);

}  // namespace rr_emod_serde

#endif  // RR_EMOD_SERDE_RR_CHANNEL_TOKENIZER_HPP
