// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_MEMORY_TRACKER_HPP
#define RR_EMOD_SERDE_RR_MEMORY_TRACKER_HPP

#include <cstdint>

namespace rr_emod_serde {

/**
 * MemoryTracker: Persistent metadata for memory subsystem continuity.
 *
 * The eModule's memory is distributed across two storage tiers (SESSION-0047,
 * SESSION-0048):
 *   - C_short_: in-memory, volatile, session-local
 *   - C_long_: on-disk, persistent, survives shutdown
 *
 * This struct tracks global state that must survive power-loss and hardware
 * changes. It answers three critical questions:
 *   1. "What session am I in?" (needed for dormancy, temporal coordinates)
 *   2. "Is my hardware still the same?" (capacity may change between sessions)
 *   3. "How long have I felt wrong?" (memory distress escalation)
 *
 * Persisted to disk at each consolidation boundary, read at boot.
 * Location: $HOME/.ryder/engrams/memory_tracker.bin (or robot-local equivalent)
 *
 * Design philosophy: The machine knows itself. When something is wrong, it
 * *feels* wrong (MEMORY_DISTRESS interrupt), escalating over repeated cycles
 * until human intervention (robologist appointment) restores coherence.
 */
struct MemoryTracker {
    // ========================================================================
    // SESSION TIMELINE (SESSION-0047 consolidation integration)
    // ========================================================================

    uint64_t session_count = 1;
    // Absolute session counter. Boot-after-shutdown increments this AFTER
    // loading from disk. Used to calculate:
    //   - dormancy_age = current_session - engram.last_session_access
    //   - temporal coordinates for T matrix (E(t) decay)
    //   - importance metric: (w × access_count) / (sessions_since_access + 1)
    // Invariant: session_count only increases; never reset. Monotonic,
    // allowing unbounded operation.

    uint64_t epoch = 0;
    // Time-base rebase offset for T matrix (SESSION-0047 §4A).
    // When session_count grows large, float32 precision in T loses exactness
    // at integer boundaries (bits only to 2^24). Periodically: rebase by
    // subtracting delta from T and adding delta to epoch. Allows unlimited
    // session operation without T precision loss. Persisted here so post-rebase
    // consolidation preserves the new epoch across shutdown/restart.

    uint64_t last_consolidation_session = 0;
    // Which session completed the last consolidation (promotion, training,
    // capacity check, dormancy marking)? Used to detect incomplete/crashed
    // consolidation: if (current_session - last_consolidation_session) > 1,
    // boot assumes crashed consolidation and triggers recovery:
    //   - Validate index file (does it match C_long_ size?)
    //   - Proceed with new session

    // ========================================================================
    // HARDWARE & CAPACITY TRACKING
    // ========================================================================

    uint64_t last_c_short_capacity_computed = 0;
    // Hardware capacity value computed in the session stored in
    // last_c_short_capacity_session below. Used to detect hardware changes:
    //   - At boot: if (current_capacity != last_c_short_capacity_computed):
    //       hardware changed, trigger MEMORY_DISTRESS
    //   - Capacity upgrades: adjust c_short_capacity_ upward, proceed normally
    //   - Capacity downgrades: adjust c_short_capacity_ downward, may need
    //       immediate consolidation to evict excess engrams
    // Computed via: size_t compute_c_short_capacity() in XLSTMMemory
    // (queries /proc/meminfo or equivalent OS API)

    uint64_t last_c_short_capacity_session = 0;
    // Which session was last_c_short_capacity_computed measured in? Allows:
    //   - Detecting stale capacity: if > N sessions old, re-measure
    //   - Logging when capacity was last validated: "hardware unchanged
    //       since session 412"

    // ========================================================================
    // MEMORY INTEGRITY & VALIDATION (SESSION-0048 disk persistence)
    // ========================================================================

    uint64_t last_memory_validation_session = 0;
    // Which session was the last memory validation performed? Validation checks:
    //   - Index file size matches engram_count_long (no missing entries)
    //   - Index offsets are monotonically increasing (no overlaps)
    //   - Sample-read first/last/random engrams from engram.dat (I/O health)
    //   - All engram_id values are unique (no collisions)
    // Trigger re-validation if: (current_session - last_memory_validation_session)
    // > VALIDATION_INTERVAL (suggest: every 10 sessions or on distress escalation)
    // Result of validation stored in corruption_detected below.

    bool corruption_detected = false;
    // Set to true if the last validation found any integrity issue:
    //   - Index file mismatch (missing engrams)
    //   - Unreadable engrams on disk (I/O error, corrupted sector)
    //   - engram_id collision or invalid data
    // Does NOT trigger immediate failure. Instead:
    //   - Sets MEMORY_DISTRESS interrupt in control loop
    //   - Control loop can decide: pause ops, trigger validation, or proceed
    // Cleared to false when next validation passes cleanly.

    // ========================================================================
    // MACHINE HEALTH & ESCALATION (control loop integration)
    // ========================================================================

    uint64_t consecutive_distress_cycles = 0;
    // Counter: how many consecutive sessions has the machine been "uncomfortable"
    // (memory capacity high, validation failed, or hardware changed)?
    // Allows graded escalation instead of binary healthy/unhealthy:
    //
    // DISTRESS GRADING:
    //   0 cycles: OK state, normal operation
    //   1-2 cycles: MILD — log concern, continue monitoring
    //   3-10 cycles: WARNING — surface to control loop, prepare consolidation
    //   10-20 cycles: URGENT — pause non-critical ops, trigger consolidation
    //   >20 cycles: CRITICAL — activate fail-safe (forced consolidation, flag
    //       for manual inspection)
    //
    // Each session:
    //   - If validation fails OR capacity_state==CRITICAL OR
    //       hardware_changed: consecutive_distress_cycles++
    //   - If validation passes AND capacity_state==OK AND hardware_unchanged:
    //       consecutive_distress_cycles = 0 (discomfort resolved)
    //
    // Control loop reads this to decide urgency level:
    //   if (distress > 20): force consolidation NOW
    //   if (distress > 10): consolidate at next boundary
    //   if (distress > 2): log "memory health declining"
    //
    // Philosophy: Machine communicates internal distress in a continuous,
    // escalatable way (like embodied unease), not as discrete error codes.

    // ========================================================================
    // STORAGE ACCOUNTING (SESSION-0048 disk management)
    // ========================================================================

    uint64_t engram_count_long = 0;
    // How many engrams are stored in C_long_ (on disk)? Derived from index
    // file size, but cached here for quick capacity checks without reading
    // index. Used to:
    //   - Detect index corruption: does index_file.size() == engram_count_long?
    //   - Monitor capacity utilization: engram_count_long / c_long_capacity_
    //   - Plan consolidation: how many more can we fit?
    // Updated at each persist() call (after engrams serialized to disk).

    uint64_t total_raw_bytes_used = 0;
    // Total disk space consumed by raw stimulus preservation (the original
    // sensory input: images, audio, text, proprioception). Does NOT include
    // embedding, metadata, or index. Used to:
    //   - Monitor storage pressure: "raw data is consuming 87% of available disk"
    //   - Plan eviction policies: if raw exceeds threshold, mark oldest engrams
    //   - Diagnostic logging: "machine has lived through N engrams, raw data
    //       is Y GB, that's Z KB per engram on average"
    // Updated at persist() time by summing raw.size() across all persisted engrams.

    // ========================================================================
    // IMPLEMENTATION NOTES
    // ========================================================================

    // Serialization format:
    // Binary, fixed-size (~80 bytes). Write-then-rename for atomicity.
    // Location: $HOME/.ryder/engrams/memory_tracker.bin
    //
    // Boot sequence:
    //   1. Load memory_tracker.bin (if exists)
    //   2. Compute current c_short_capacity, compare to last_c_short_capacity_computed
    //   3. If different: set consecutive_distress_cycles++, trigger MEMORY_DISTRESS
    //   4. If (current_session - last_consolidation_session) > 1: crashed consolidation detected
    //   5. If (current_session - last_memory_validation_session) > VALIDATION_INTERVAL:
    //       schedule validation for this session
    //   6. Increment session_count++ to mark this session as active
    //   7. Load C_long_ matrices and index file from disk
    //
    // Persist sequence (at consolidation boundary):
    //   1. Consolidate engrams (promotion, training, dormancy marking)
    //   2. Serialize C_long_ matrices + long_term_ engrams to disk
    //   3. Write index file
    //   4. Update this tracker: session_count, epoch, last_consolidation_session,
    //       engram_count_long, total_raw_bytes_used
    //   5. Write memory_tracker.bin (write-then-rename for crash safety)
    //
    // Validation sequence:
    //   1. Open engram.dat and index file
    //   2. Verify index_file.size() == engram_count_long
    //   3. Spot-check read 5 random engrams (verify deserialization)
    //   4. If all checks pass: corruption_detected = false, last_memory_validation_session = current_session
    //   5. If any check fails: corruption_detected = true, set MEMORY_DISTRESS interrupt
};

}  // namespace rr_emod_serde

#endif  // RR_EMOD_SERDE_RR_MEMORY_TRACKER_HPP
