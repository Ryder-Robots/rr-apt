// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
#pragma once

// RrCortexSocketBase — the TRANSPORT-FREE half of RrCortexSocket.
//
// RrCortexSocket states the contract; this states the part of it that is the
// same whether the peer is a pointer away or a switch away. The four verbs are
// FINAL here and each ends in a hook: the base owns the state machine (the role
// gates, the claim, armed-ness, the one-peer grant, the identity in the ack) and
// a transport owns only the step that genuinely differs.
//
// THE SHAPE IS rclcpp_lifecycle::LifecycleNode's, and deliberately so (Aaron,
// 2026-08-02). Public non-virtual verbs that run the bookkeeping, protected
// virtual hooks that do the work, and shared collaborators injected through a
// PROTECTED CONSTRUCTOR that every derived class must call. A transport cannot
// forget to wire the registry, because the registry is not a member it assigns —
// it is a base it has to construct.
//
// WHAT IS PROTECTED, AND WHY THAT LINE IS WHERE IT IS. The rule is invariant,
// not convenience:
//
//   - rendezvous_, logger_, mtx_ are PROTECTED DATA. The first two are const and
//     set once at construction; a mutex has no invariant of its own. There is no
//     rule a derived class could break by touching any of them.
//   - opts_, connected_, listening_ are PRIVATE. They ARE the state machine. If
//     connected_ were protected, every transport could grant a peer by its own
//     rule and skip the one-peer gate — which is exactly the bug that had accept()
//     and submit() granting by two different paths. grant_peer() is the one door.
//
// LOCK ORDER IS ALWAYS SOCKET-THEN-REGISTRY. Every verb below takes mtx_ and
// then, if it needs one, the rendezvous lock. Nothing anywhere takes them in the
// other order. Hooks are called WITH mtx_ HELD; see each for what that permits.

#include <atomic>
#include <memory>
#include <mutex>
#include <optional>
#include <string>

#include <rr_emod_serde/rr_cortex_socket.hpp>
#include <rr_emod_serde/rr_emod_types.hpp>

namespace rr_emod_serde {

class RrLogger;
class RrRendezvous;

class RrCortexSocketBase : public RrCortexSocket,
                           public std::enable_shared_from_this<RrCortexSocketBase> {
public:
    // ── the contract, FINAL ───────────────────────────────────────────────────
    // A transport overrides none of these. Everything a transport can vary is a
    // do_* hook below, which is what makes "the gRPC socket forgot the role gate"
    // unspellable rather than merely unlikely.
    rr_conn::ConnStatus bind(const RrSockOpts& opts) final;
    rr_conn::ConnStatus listen() final;
    rr_conn::OpenChannelAck accept() final;
    rr_conn::ConnStatus connect() final;
    rr_conn::ConnStatus send(const rr_inference::CortexEnvelope& msg) final;

    // ATOMIC, not mtx_-guarded: polled by the gates and by diagnostics on threads
    // that must never block behind a dial in flight. Written under mtx_ (so it
    // stays consistent with the transport's peer edge) and read without it here.
    bool connected() const final { return connected_.load(std::memory_order_acquire); }

    rr_emod_types::ChannelId channel() const final;
    RrSockFlags flags() const final;

protected:
    // PROTECTED, like LifecycleNode's: this class is never stood up alone, and a
    // protected constructor makes that a compile error rather than a convention.
    //
    // ⚠ shared_from_this() IS UNUSABLE IN HERE. The weak reference is not wired
    // until the enclosing make_shared completes, so a claim made from a
    // constructor throws bad_weak_ptr — the same crash as calling it in an
    // rclcpp::Node ctor. That is why bind(), not construction, claims.
    explicit RrCortexSocketBase(std::weak_ptr<RrRendezvous> rendezvous,
                                std::shared_ptr<RrLogger> logger = nullptr)
        : rendezvous_(std::move(rendezvous)), logger_(std::move(logger)) {}

    // ── the hooks ─────────────────────────────────────────────────────────────
    //
    // DEFAULTED where forgetting fails LOUDLY, PURE where it fails SILENTLY.
    // That split is the whole design rule here: a transport that omits do_arm()
    // never starts serving and the first dial says so at boot, but a transport
    // that omits do_dial() would report connected() == true with no peer, and
    // every send() after it would be a silent no-op that prints nothing, ever.

    // What refusals are logged under. Derived classes name themselves so the log
    // says which TRANSPORT refused rather than which base class did.
    virtual const char* tag() const noexcept = 0;

    // Called with mtx_ HELD, AFTER the registry claim succeeds and before opts_
    // is recorded. Transport setup that belongs at bind time; for gRPC that is
    // AddListeningPort() + RegisterService(), which only RECORD the intent — the
    // OS is not touched until do_arm(). A non-ACCEPTED return releases the claim.
    virtual rr_conn::ConnStatus do_bind(const RrSockOpts& opts);

    // Called with mtx_ HELD, on a bound SERVER, from listen(). Arms the endpoint.
    // In process there is nothing to arm; for gRPC this is BuildAndStart() — the
    // call that can fail with a real EADDRINUSE, and the one that must set
    // SetSyncServerOption NUM_CQS / MIN_POLLERS / MAX_POLLERS explicitly or N
    // listeners on a 4-core Pi5 each spin up a default pool and starve cognition.
    virtual rr_conn::ConnStatus do_arm(const RrSockOpts& opts);

    // Called from accept() OWNING lk. The implementation MAY unlock, park, and
    // re-lock — it must return with the lock HELD. This is the one verb whose
    // blocking behaviour genuinely differs by transport: in process a dialer
    // arrives through the rendezvous, remotely through gRPC's completion queue.
    //
    // FILLS `syn` with what the dialer sent. That out-parameter is the point of
    // parking — a dial IS the arrival of a SYN — and it is what lets accept()
    // and a transport's own receipt path both end in the same grant().
    //
    // PURE: a default returning ACCEPTED would grant a phantom peer to a dialer
    // that never arrived, burning the one-peer gate on nobody.
    virtual rr_conn::ConnStatus do_await_dial(std::unique_lock<std::mutex>& lk,
                                              rr_conn::OpenChannel& syn) = 0;

    // One envelope to the far end; its answer, if any, comes BACK through
    // `reply`. Called with NO lock held.
    //
    // THE ANSWER IS A RETURN, NOT A SECOND PUSH (2026-08-02). RrSockHandler
    // already returns std::optional<CortexEnvelope>, which is exactly gRPC's
    // unary shape — stub->Speak(&ctx, req, &rsp) — so modelling the reply as
    // another delivery was an artifact of the in-process implementation and
    // nothing the contract asked for. Two things fall out of dropping it: a
    // many-peer service cannot mis-route an answer, because there is no reply
    // address stored to get wrong; and the one-hop rule stops being a flag that
    // has to be threaded and becomes the absence of a code path.
    //
    // The status is the TRANSPORT's, not the handler's: a dead peer or a broken
    // stream. A handler with nothing to say is ACCEPTED with `reply` empty.
    virtual rr_conn::ConnStatus do_deliver(const rr_inference::CortexEnvelope& msg,
                                           std::optional<rr_inference::CortexEnvelope>& reply) = 0;

    // Called with mtx_ HELD, on a bound CLIENT, from connect(). Finds the far
    // server and records the peer edge. A find-miss must return
    // UNKNOWN_ADDRESS *silently* — at boot the dialer is expected to retry, and a
    // log line here fires on every start of every board.
    //
    // PURE: a default returning ACCEPTED is the silent failure described above.
    virtual rr_conn::ConnStatus do_dial(const RrSockOpts& opts) = 0;

    // ── state access ──────────────────────────────────────────────────────────

    // The binding, or nullptr when unbound. CALL WITH mtx_ HELD — the pointer is
    // into opts_ and is only valid for as long as the lock is.
    const RrSockOpts* bound() const noexcept { return opts_ ? &*opts_ : nullptr; }

    // THE ONLY DOOR TO connected_. Call with mtx_ HELD. Returns false when the
    // one-peer gate refuses, which is the caller's cue to answer ADDRESS_IN_USE.
    //
    // The gate is a SERVER-side rule — it is the acceptor that must refuse a
    // second dialer — and it is EXEMPT for the service channels past the COUNT
    // sentinel, which are many-peer by design. A CLIENT reaches here only from
    // connect(), which has already returned early on an idempotent re-dial, so
    // there is nothing left for the gate to refuse.
    bool grant_peer();

    // THE GRANT, from either direction. accept() reaches it after parking; a
    // transport's own SYN-receipt path — RrCortexSocketLocal::submit(), gRPC's
    // service handler — reaches it directly with the SYN already in hand. Every
    // gate and the whole ack live here, so the two directions cannot drift.
    // Call with mtx_ HELD.
    //
    // WHICH CHANNEL IS GRANTED depends on whether this is a sense or a service.
    // On a sense the endpoint IS the identity, so a SYN naming a different
    // channel reached the wrong socket and is refused. On a SERVICE one door
    // serves every cortex, so the grant is the channel the DIALER named —
    // otherwise six cortexes on MEMORY are all stamped sender_id = MEMORY and
    // the hippocampus cannot tell whose engram query it is holding.
    // connectio.proto:104 states this for FRONTAL; it is the same argument.
    // That is the one place a peer's own claim reaches the grant, and it is
    // what the slot -> permitted-channels ACL will bound. Until that exists the
    // claim is trusted.
    rr_conn::OpenChannelAck grant(const rr_conn::OpenChannel& syn);

    // Run THIS socket's handler on an arriving envelope and return whatever it
    // answers. The handler is copied out under the lock and invoked with NO
    // lock held: mtx_ is not recursive, and a handler that sends on its own
    // socket is the natural shape of a forwarding cortex, not a misuse.
    //
    // Shared because both receiving sides need it — the local peer reaches it
    // through do_deliver(), and a gRPC service handler will call it directly
    // with the envelope the stream just yielded.
    std::optional<rr_inference::CortexEnvelope> run_handler(
            const rr_inference::CortexEnvelope& msg);

    // Log a refusal and return its status. Null-logger-safe by construction, so
    // an unguarded logger_-> can no longer be forgotten on a refusal path.
    rr_conn::ConnStatus refuse(const std::string& why, rr_conn::ConnStatus st) const;

    // The same, shaped as an ack. detail() and the log line are the SAME string
    // deliberately: the operator reads one wording, not two that can drift.
    rr_conn::OpenChannelAck refuse_ack(const std::string& why, rr_conn::ConnStatus st) const;

    // ── shared collaborators ──────────────────────────────────────────────────
    // const: injected once through the ctor and never reseated. Derived classes
    // read them and cannot swap them, which is a stronger guarantee than
    // `protected` alone would have given.
    const std::weak_ptr<RrRendezvous> rendezvous_;
    const std::shared_ptr<RrLogger> logger_;

    // Guards opts_ and listening_, and the derived classes' own peer edges. Not
    // recursive: a handler must be copied out and invoked with NO lock held.
    mutable std::mutex mtx_;

private:
    std::optional<RrSockOpts> opts_ = std::nullopt;
    std::atomic<bool> connected_{false};
    bool listening_{false};
};

}  // namespace rr_emod_serde
