// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_LONG_TERM_STATE_HPP
#define RR_EMOD_SERDE_LONG_TERM_STATE_HPP

#include <Eigen/Dense>
#include <cstdint>
#include <string>

#include <rr_emod_serde/engram.hpp>
#include <rr_emod_serde/rr_emod_types.hpp>
#include <rr_emod_serde/rr_checksum.hpp>
#include <rr_emod_serde/rr_store.hpp>

namespace rr_emod_serde {

// The long-term mLSTM state and its on-disk form. NOT engrams: the records
// serialise individually and exactly, this is the superposed sum they fold into.
// One header, one payload, four blocks — all four or none, because the matrices
// are gate-siblings and only mean anything in correspondence with each other.

// Fixed widths, ordered largest-first so the struct packs with no padding.
// Padding bytes are indeterminate, so writing them raw would checksum identical
// state two different ways; the static_assert below is what holds that.
struct LongTermStateHeader {
    static constexpr char MAGIC[4] = {'R', 'R', 'M', 'L'};
    static constexpr std::uint32_t VERSION = 1;

    // Trajectory scalars. Here rather than beside the matrices so they cannot be
    // persisted apart from them: the matrices are held scaled by exp(-m_long) and
    // T stamps are relative to epoch, so either one missing makes the payload
    // quietly wrong rather than obviously broken.
    std::uint64_t epoch = 0;
    std::uint64_t session_cnt = 0;

    std::uint64_t payload_len = 0;  // checked against file size; not a parser input

    char magic[4] = {'R', 'R', 'M', 'L'};  // 4 bytes on disk, not NUL-terminated
    std::uint32_t version = VERSION;

    // Refuse the file if either differs — a rebuilt binary must not read an old
    // one as garbage. Together they fix every block offset in the payload.
    std::uint32_t emb_dim = static_cast<std::uint32_t>(rr_emod_types::EMBEDDING_DIM_DEFAULT);
    std::uint32_t chan_count = static_cast<std::uint32_t>(rr_emod_types::CHANNEL_COUNT);

    float m_long = 0.0f;

    // Last, and covers every byte before it plus the whole payload, computed with
    // this field zeroed. Writer and reader must agree on that or nothing loads.
    std::uint32_t crc32 = 0;
};

static_assert(sizeof(LongTermStateHeader) == 48, "on-disk header must not carry padding");

// Contiguous float32 in this order. Offsets follow from emb_dim and chan_count:
//   c at 0, n at emb*emb, s at emb*emb + emb, t at emb*emb + emb + chan*emb.
struct LongTermStatePayload {
    Eigen::MatrixXf c_long;  // emb x emb     content
    Eigen::VectorXf n_long;  // emb           normaliser
    Eigen::MatrixXf s_long;  // chan x emb    salience
    Eigen::MatrixXf t_long;  // 1 x emb       session stamp
};

class LongTermState {
public:
    // The store's vocabulary, not a private copy of it. A fault keeps the value it
    // was produced with all the way out, so Corrupt is the same number in the log
    // wherever it came from and Denied no longer arrives disguised as IoError.
    //
    // Read here as: Absent is not an error — a new brain's first boot has no file.
    // Corrupt is bad magic, wrong version, mismatched dims, or a failed CRC, and a
    // refused read leaves this object untouched so its zeros survive. Empty is the
    // write side only: nothing has ever been folded, so there is nothing to snapshot.
    using Result = RrStore::Result;

    LongTermState();  // allocates at the compile-time dims and zeroes

    // Atomic replace: temp -> fsync -> rename. A short write is a fault rather
    // than something to retry.
    Result write(const std::string& path) const;

    Result read(const std::string& path);

    // Handed out as a set: the fold writes all four matrices and both scalars
    // together, and splitting them is the thing this class exists to prevent.
    LongTermStateHeader& header() { return header_; }
    const LongTermStateHeader& header() const { return header_; }
    LongTermStatePayload& payload() { return payload_; }
    const LongTermStatePayload& payload() const { return payload_; }

private:
    // Storage lives in RrSnapshotStore — atomic replace, fsync, and the one place a
    // cipher can go. This class owns the format and nothing below it, which is why
    // its results pass straight through rather than being translated.
    LongTermStateHeader header_;
    LongTermStatePayload payload_;
};

}  // namespace rr_emod_serde

#endif  // RR_EMOD_SERDE_LONG_TERM_STATE_HPP
