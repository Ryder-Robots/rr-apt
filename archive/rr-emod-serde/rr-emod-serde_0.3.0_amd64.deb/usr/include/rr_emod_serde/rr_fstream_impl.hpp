// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <memory>

// ============================================================================
// OS-Specific FStream Implementation Selector
// ============================================================================
// This header centralizes conditional includes for RrFstreamProxy implementations.
// Based on the target OS (set via CMake RR_TARGET_OS), we include and typedef
// the appropriate implementation. New OS targets (Jetson, etc.) can be added here.
// ============================================================================

#if defined(RR_TARGET_PICORE)
    #include "rr_emod_serde/rr_fstream_picore.hpp"
    using RrFstreamImpl = rr_emod_serde::RrFstreamPiCore;
#elif defined(RR_TARGET_JETSON)
    // Future: #include "rr_emod_serde/rr_fstream_jetson.hpp"
    // Future: using RrFstreamImpl = rr_emod_serde::RrFstreamJetson;
    #error "RR_TARGET_JETSON not yet implemented"
#else
    // Linux (default)
    #include "rr_emod_serde/rr_fstream_linux.hpp"
    using RrFstreamImpl = rr_emod_serde::RrFstreamLinux;
#endif

namespace rr_emod_serde {

// Factory function: creates OS-specific implementation agnostically
// Defined in rr_fstream_linux.cpp or rr_fstream_picore.cpp
std::unique_ptr<RrFstreamProxy> create_fstream();

}  // namespace rr_emod_serde
