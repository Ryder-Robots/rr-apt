#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "rr_emod_serde::rr_emod_serde" for configuration "Release"
set_property(TARGET rr_emod_serde::rr_emod_serde APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(rr_emod_serde::rr_emod_serde PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/librr_emod_serde.so"
  IMPORTED_SONAME_RELEASE "librr_emod_serde.so"
  )

list(APPEND _cmake_import_check_targets rr_emod_serde::rr_emod_serde )
list(APPEND _cmake_import_check_files_for_rr_emod_serde::rr_emod_serde "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/librr_emod_serde.so" )

# Import target "rr_emod_serde::rr_cortex" for configuration "Release"
set_property(TARGET rr_emod_serde::rr_cortex APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(rr_emod_serde::rr_cortex PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/librr_cortex.so.0.6.1"
  IMPORTED_SONAME_RELEASE "librr_cortex.so.0.6.1"
  )

list(APPEND _cmake_import_check_targets rr_emod_serde::rr_cortex )
list(APPEND _cmake_import_check_files_for_rr_emod_serde::rr_cortex "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/librr_cortex.so.0.6.1" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
