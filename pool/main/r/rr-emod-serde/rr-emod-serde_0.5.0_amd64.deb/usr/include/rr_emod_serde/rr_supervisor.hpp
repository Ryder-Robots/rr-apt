// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <atomic>
#include <cstddef>
#include <memory>
#include <string>
#include <vector>
#include "rr_emod_serde/rr_cognition_com.hpp"
#include "rr_emod_serde/rr_ledger.hpp"
#include "rr_emod_serde/rr_logger.hpp"
#include "rr_emod_serde/rr_xlstm_memory.hpp"

namespace rr_emod_serde {

// Forward-declared so this header stays light (doesn't pull in the loop or cognition,
// and thus the whole brain — rr_cognition.hpp would drag torch in here). The ctor/dtor
// that need the complete types live in the .cpp.
class RrControlLoop;
class RrCognition;

struct RrSupervisorConfig {
    // Empty = use the persistent compile-time default (resolved in the ctor, where
    // RR_LEDGER_FILE stays private to the .cpp and never leaks into this header).
    std::string ledger_file = "";
    // Action space for cognition's zone head. 7 = scene6ch default; EXP-0019's
    // 8x3 grid uses 24. The harness overrides per experiment.
    std::size_t n_zones = 7;
    // Empty = the memory's compile-time default store. Experiments MUST set a
    // per-run path (EXP-0021 §5.1) — the sleep/wake rung del/recreates the
    // supervisor, and doing that against the production store would trample it.
    std::string memory_base_path = "";
};

// Composition root AND lifecycle controller for the brain. Owns the modules, wires the
// shared coms, and walks lifecycle transitions in dependency order:
//   activate:   memory -> cognition -> loop -> (gate, when wired)   [senses on LAST]
//   deactivate: (gate) -> loop -> cognition -> memory               [senses off FIRST]
// Activation ABORTS on the first non-OK (never open the faucet on a dead brain);
// deactivation is BEST-EFFORT (walks the whole chain, reports the worst diag).
class RrSupervisor {
public:
    RrSupervisor(const RrSupervisorConfig& config);

    ~RrSupervisor();

    void run();

    EngramSessionMeta cmd_ledger();

    void cmd_start_session_log();

    void cmd_end_session_log();

    std::vector<rr_log_item> cmd_session_log();

    rr_emod_types::DiagnosticState cmd_start_session();

    rr_emod_types::DiagnosticState cmd_end_session();

    // Consolidation itself is PYTHON-side until cortexes exist (decision 2026-07-03).
    // start/end only bracket it: park the brain (consolidating pause-gate), let the
    // Python trainer own the weights, then persist + resume.
    //
    // TEMP SWITCH (decision 2026-07-03): the supervisor is the SOLE authority over
    // both consolidating flags (the loop's is_consolidating_ and the coms pause-gate)
    // — the brain reactivates only when the supervisor says so, via these commands.
    // This trio is the DELIBERATE python-binding surface: the harness (which owns
    // training until cortexes) grips the brain here — bind start, poll check, end.
    // The loop's flag is deliberately KEPT (not simplified away) as the seam where
    // post-cortex autonomous consolidation (CapacityState-triggered) plugs in and
    // this manual, binding-driven bracket retires.
    void cmd_start_consilidation();

    // returns true if backpropagation is in progress.
    bool cmd_check_consilidation();

    void cmd_end_consilidation();

    // DIAG surface: diagnostics are gated (silent unless enabled) and drained by the
    // supervisor — drain returns the accumulated running sums and resets them.
    void cmd_set_diagnostic(bool on);

    DiagStats cmd_drain_diag();

    // TEMP data passthrough (EXP-0021 §5.3): direct memory ops against the
    // supervisor-owned instance, keeping the one-door rule (Python never holds the
    // memory object). Same species of scaffolding as the consolidation temp switch —
    // these retire when the percept path (frames in -> cognition -> OUTBOUND store)
    // takes over at the road test.
    rr_emod_types::EngramID cmd_store(const Eigen::VectorXf& key, const Eigen::VectorXf& value,
                                      const Eigen::VectorXf& salience, float w);

    rr_emod_types::Engram cmd_retrieve(const Eigen::VectorXf& query);

    rr_emod_types::Engram cmd_retrieve(const Eigen::VectorXf& query,
                                       const Eigen::VectorXf& query_salience, float d);

    bool cmd_update_w(const rr_emod_types::EngramID& id, float w);

    rr_emod_types::CapacityState cmd_capacity_state();

private:
    std::shared_ptr<RrLedger> ledger_;
    std::shared_ptr<RrLogger> logger_;
    std::shared_ptr<XLSTMMemory> xlstm_;

    // The wiring table: channels + coms are supervisor-owned and shared into the
    // modules (the gate wake-hook wires against cognition_com_ when the gate lands).
    std::shared_ptr<rr_emod_types::InboundChannel> inbound_;
    std::shared_ptr<rr_emod_types::OutboundChannel> outbound_;
    std::shared_ptr<RRCognitionCom> cognition_com_;

    // Supervisor is the composition root for the brain. The atomics are held here
    // (the loop takes them by reference) and MUST outlive loop_ — declared before it.
    // Member order = reverse destruction order: loop_ dies first (joins its thread),
    // then cognition_, then the shared plumbing above.
    std::atomic<bool> is_shutdown_{false};
    std::atomic<bool> is_consolidating_{false};
    std::shared_ptr<RrCognition> cognition_;
    std::unique_ptr<RrControlLoop> loop_;
};
}  // namespace rr_emod_serde