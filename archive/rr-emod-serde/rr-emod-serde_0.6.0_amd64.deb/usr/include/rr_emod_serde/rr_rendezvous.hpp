// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <utility>

#include <conn/connectio.pb.h>
#include <rr_emod_serde/rr_cortex_socket.hpp>
#include <rr_emod_serde/rr_emod_types.hpp>
#include <rr_emod_serde/rr_logger.hpp>

namespace rr_emod_serde {
class RrRendezvous {
public:
    RrRendezvous(std::shared_ptr<RrLogger> logger = nullptr) : logger_(std::move(logger)) {}
    ~RrRendezvous() = default;

    rr_conn::ConnStatus claim(rr_emod_types::ChannelId channel, RrSockFlags role,
                              std::shared_ptr<RrCortexSocket> socket);

    void release(rr_emod_types::ChannelId channel, RrSockFlags role);

    std::optional<std::shared_ptr<RrCortexSocket>> find(rr_emod_types::ChannelId channel,
                                                        RrSockFlags role) const;

private:
    using Key = std::pair<rr_emod_types::ChannelId, RrSockFlags>;
    std::map<Key, std::shared_ptr<RrCortexSocket>> claims_;
    mutable std::mutex mtx_;
    std::shared_ptr<RrLogger> logger_;
};
}  // namespace rr_emod_serde