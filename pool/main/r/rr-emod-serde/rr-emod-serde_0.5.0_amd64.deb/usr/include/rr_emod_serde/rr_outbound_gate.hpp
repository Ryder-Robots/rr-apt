// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <memory>
#include <thread>
#include <atomic>
#include <utility>
#include <chrono>
#include <algorithm>
#include <sys/ioctl.h>
#include <linux/if.h>
#include <netinet/ether.h>
#include <unistd.h>
#include <cstring>
#include "rr_emod_serde/rr_mod_lc.hpp"
#include "rr_emod_serde/rr_emod_types.hpp"
#include "rr_emod_serde/rr_checksum.hpp"
#include "rr_emod_serde/rr_model_utils.hpp"

namespace rr_outbound_gate
{

/**
 * Splits output delivered by cognition into its output channel, each MessageFrame will be appended with meta-data.
 */
class OutboundChannelGate : public rr_emod_lc::RrModLc
{
  using IO_COM_ARRAY =
      std::array<std::shared_ptr<rr_emod_types::IOCom>, static_cast<size_t>(rr_emod_types::ChannelId::COUNT)>;

public:
  OutboundChannelGate(std::shared_ptr<rr_emod_types::OutboundChannel> output, IO_COM_ARRAY io_coms,
                      std::atomic<bool>& is_shutdown, std::atomic<bool>& is_consolidating)
    : output_(output), io_coms_(io_coms), is_shutdown_(is_shutdown), is_consolidating_(is_consolidating),
      source_id_{}
  {
  }

  ~OutboundChannelGate();

  rr_emod_lc::DiagnosticState on_configure() override;

  rr_emod_lc::DiagnosticState on_activate() override;

  rr_emod_lc::DiagnosticState on_deactivate() override;

  rr_emod_lc::DiagnosticState on_cleanup() override;

  rr_emod_lc::DiagnosticState on_shutdown() override;

protected:
  void run();

  std::shared_ptr<rr_emod_types::OutboundChannel> output_;
  std::thread gate_loop_t;
  IO_COM_ARRAY io_coms_;

  std::atomic<bool>& is_shutdown_;
  std::atomic<bool>& is_consolidating_;

  // Note sequence will reset after 255
  uint8_t sequence_ = 0;
  uint8_t source_id_[6];
};
}  // namespace rr_outbound_gate