// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.


#pragma once

#include <string>
#include <string_view>
#include <initializer_list>
#include <atomic>
#include <vector>
#include <mutex>
#include <charconv>
#include <chrono>
#include <cstdint>
#include <type_traits>
#include <rr_emod_serde/rr_emod_types.hpp>


// contains indivual logging item.
struct rr_log_item {
    uint64_t timestamp = 0;
    rr_emod_types::DiagnosticState state = rr_emod_types::DiagnosticState::OK;
    std::string process;
    std::string msg;
};

namespace rr_emod_serde {
    // Formats an integer (or enum) into a log argument without allocating.
    //
    // The point of the {0} placeholders is that a log line costs one atomic load when
    // logging is off. Building the message with std::to_string and + throws that away:
    // the concatenation runs on every call whether anyone is listening or not. This
    // writes into its own stack buffer instead, so the same call costs nothing.
    //
    // Lifetime is the arg-view rule: a temporary in the argument list is fine, since it
    // outlives the call it is written in. Storing one and logging it later is not.
    class LogInt {
        public:
        template <typename T>
        explicit LogInt(T v) noexcept {
            static_assert(std::is_integral_v<T> || std::is_enum_v<T>,
                          "LogInt formats integers and enums");
            if constexpr (std::is_enum_v<T>) {
                write(static_cast<std::underlying_type_t<T>>(v));
            } else {
                write(v);
            }
        }

        operator std::string_view() const noexcept { return {buf_, len_}; }

        private:
        // 20 chars covers every 64-bit value, signed or not, so to_chars cannot fail.
        template <typename U>
        void write(U v) noexcept {
            const auto r = std::to_chars(buf_, buf_ + sizeof(buf_), v);
            len_ = static_cast<std::uint8_t>(r.ptr - buf_);
        }

        char buf_[20];
        std::uint8_t len_ = 0;
    };

    /**
     * Under normal circumstances logging messages can be considered noop calls, however when toggled
     * on they will print to a log file, which can be retrieved by DIAG. Note that logging is expensive.
     * it will possibly block threads while waiting. It will also have no visibility over what cortexes
     * are doing.
     */
    class RrLogger {
        public:
        RrLogger() = default;
        ~RrLogger() = default;

        // fmt may carry {0}, {1} ... placeholders filled from args, in any order and any
        // number of times. An opening brace is the only special character — write {{ for a
        // literal one; a closing brace not ending a placeholder is already literal. A
        // placeholder with no matching argument is copied through as-is so the mismatch
        // shows up in the log rather than silently disappearing. Nothing is formatted
        // unless logging is switched on.
        //
        // args are views: everything they point at has to stay alive for the duration of
        // the call. Interpolation is synchronous, so temporaries in the argument list are
        // fine, but never hand these a view of something already destroyed.
        void info(std::string_view fmt, std::string_view process,
                  std::initializer_list<std::string_view> args = {});
        void wtf(std::string_view fmt, std::string_view process,
                 std::initializer_list<std::string_view> args = {});
        void wtaf(std::string_view fmt, std::string_view process,
                  std::initializer_list<std::string_view> args = {});
        void fubar(std::string_view fmt, std::string_view process,
                   std::initializer_list<std::string_view> args = {});
        void start_session_log();
        void end_session_log();
        std::vector<rr_log_item> session_log();

        private:
        // Ring capacity — fixed and class-scoped (no header-level namespace constant).
        static constexpr size_t MAX_LOG_SZ = 1000;

        std::atomic<bool> is_active_{false};
        std::vector<rr_log_item> items_{};  // grows to MAX_LOG_SZ, then overwrites oldest
        size_t head_ = 0;                   // index of the oldest item once the ring is full
        uint64_t dropped_ = 0;              // items overwritten since the last drain

        void write_record(std::string_view fmt, std::string_view process,
                          std::initializer_list<std::string_view> args,
                          rr_emod_types::DiagnosticState diag);

        std::mutex mtx_;
    };
}