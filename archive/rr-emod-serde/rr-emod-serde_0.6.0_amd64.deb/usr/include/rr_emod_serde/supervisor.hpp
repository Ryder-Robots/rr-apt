// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <rr_emod_serde/rr_emod_types.hpp>
#include <rr_emod_serde/rr_logger.hpp>
#include <rr_emod_serde/rr_xlstm_memory.hpp>
#include <rr_emod_serde/rr_mod_lc.hpp>

namespace rr_emod_serde {
/**
 * Base class for supervisors. Commands in this class are
 * common to cortex superviros and reasoner supervisor.
 */

enum class ConsilidationState : uint8_t {
    STARTED,
    FAILED,
    PROCESSING,
    FINISHED,
};

class SupervisorBase : public rr_emod_lc::RrModLc {
public:
    SupervisorBase() = default;
    SupervisorBase(const SupervisorBase&) = delete;
    SupervisorBase& operator=(const SupervisorBase&) = delete;
    SupervisorBase(SupervisorBase&&) = delete;
    SupervisorBase& operator=(SupervisorBase&&) = delete;
    virtual ~SupervisorBase() = default;

    virtual rr_emod_types::DiagnosticState cmd_start_session_log() = 0;
    virtual rr_emod_types::DiagnosticState cmd_end_session_log() = 0;
    virtual std::vector<rr_log_item> cmd_session_log() = 0;

    virtual rr_emod_types::DiagnosticState cmd_start_session() = 0;
    virtual rr_emod_types::DiagnosticState cmd_end_session() = 0;
    virtual rr_emod_types::DiagnosticState cmd_start_consilidation() = 0;
    virtual ConsilidationState cmd_check_consilidation() = 0;
    virtual rr_emod_types::DiagnosticState cmd_end_consilidation() = 0;

    virtual rr_emod_types::CapacityState cmd_capacity_state() = 0;

    virtual void cmd_set_diagnostic(bool on) = 0;
};
}  // namespace rr_emod_serde