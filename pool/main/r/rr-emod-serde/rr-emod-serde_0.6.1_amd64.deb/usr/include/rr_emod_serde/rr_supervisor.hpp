// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_SUPERVISOR_HPP
#define RR_EMOD_SERDE_RR_SUPERVISOR_HPP

#include <array>
#include <atomic>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <mutex>
#include <span>
#include <thread>
#include <utility>

#include <rr_emod_serde/rr_emod_types.hpp>
#include <rr_emod_serde/rr_lc.hpp>
#include <rr_emod_serde/rr_lc_registry.hpp>
#include <rr_emod_serde/rr_logger.hpp>
#include <rr_emod_serde/rr_registry_tree.hpp>

namespace rr_emod_serde {

// How far the trainer got. Written only from outside by the trainer's stamp —
// the network has no way of telling whether consolidation is done — and
// reported over the debug channel.
enum class ConsilidationState : uint8_t { STARTED, FAILED, PROCESSING, FINISHED };

class RrSupervisor {
public:
    // A supervisor exists to drive a composed registry, so one arrives at
    // construction or the supervisor does not. From here the registry is the
    // tree's alone — nothing outside reaches a raw node again.
    explicit RrSupervisor(std::unique_ptr<rr_emod_lc::RrRegistry> registry)
        : reg_tree_(std::move(registry)) {}

    // Commands — the consolidation bracket plus the stop. The only verbs that
    // mutate; everything else on this surface is a read.

    // Boots the machine and waits for the machine's own word on it: first for
    // the walk to settle — a refused boot returns the walk's grade once the
    // wind-down is quiet — then for ARM to deliver. OK means the caller is
    // standing on a live inference machine, not that a thread was launched.
    // No deadline, like the stop's join: a hung boot must look hung.
    rr_emod_types::DiagnosticState cmd_start();

    // Opens a consolidation window: latches the demand and returns, the
    // loop's tick performs it. Callers poll diag_mode_status() and train once
    // CONSOLIDATE lands; only cmd_stamp() closes the window.
    rr_emod_types::DiagnosticState cmd_end();

    // backpropagation completed, this will trigger the system to end consildation, start
    // new session and enter ARM. The outcome arrives as the argument because
    // completion — and failure — is knowledge only the trainer holds.
    rr_emod_types::DiagnosticState cmd_stamp(ConsilidationState outcome);

    // Wakes the parked walk thread for the down-walk and joins it, so this
    // returns only once every node is FINALIZED. A stop taken from ARM closes
    // the open episode through the consolidation boundary first, so a
    // commanded stop reads as a clean stop to the next boot — only a real
    // crash leaves the clock dirty. One-shot — there is no reboot, a restart
    // is a process restart.
    rr_emod_types::DiagnosticState cmd_shutdown();

    // Diag — read-only, callable forever without changing anything.

    // Where in the lifecycle each node is, indexed by registry slot. Per-node
    // because nodes legitimately disagree mid-walk, and mid-walk is when this
    // gets asked.
    [[nodiscard]] std::array<rr_emod_lc::LcPhase,
                             static_cast<std::size_t>(rr_emod_lc::RrLcSlots::NODE_COUNT)>
    diag_lc_status();

    // The delivered mode — what the machine last cleanly landed on, never what
    // was most recently asked for. Python polls it and conducts backpropagation
    // only when it reads CONSOLIDATE.
    [[nodiscard]] rr_emod_types::Mode diag_mode_status();

    // How far the training got — a different question from the mode.
    [[nodiscard]] ConsilidationState diag_consolidation_status();

    // Drains the session log into the pre-sized window below and returns a view
    // of what landed — no allocation on the read path, the window's memory is
    // spoken for at construction. The view is valid until the next drain; the
    // caller owns the events from there. Stands in for the diag channel until
    // that channel exists.
    [[nodiscard]] std::span<const rr_log_item> diag_log();

private:
    // One past the ring: a drain hands over at most the full ring plus the
    // synthetic dropped-items marker, and the marker matters most exactly
    // when the ring is full.
    std::array<rr_log_item, RrLogger::MAX_LOG_SZ + 1U> log_window_{};

    // The stop demand and the door main sleeps behind: run() parks on the CV
    // once the machine is ACTIVE and stays up until cmd_shutdown() latches the
    // demand and wakes it for the down-walk.
    std::atomic<bool> shutdown_demanded_{false};
    std::mutex stop_mtx_;
    std::condition_variable stop_cv_;

    // What the trainer last stamped. Starts at FINISHED: a machine that has
    // never opened a window has no training in flight.
    std::atomic<ConsilidationState> consolidation_state_{ConsilidationState::FINISHED};

    // The boot's settled verdict, written once by the walk thread and read by
    // the blocked start verb. Guarded by the phase signal's lock — the same
    // lock the waiting predicate runs under, so the wake and the truth can
    // never pair with different mutexes.
    bool boot_settled_{false};
    rr_emod_types::DiagnosticState boot_result_{rr_emod_types::DiagnosticState::OK};

    // main thread, performs walk up and walk down.
    void run();

    // Records the boot verdict and announces it, once: the first settle wins
    // and later calls change nothing, so a walk that parked cleanly cannot be
    // regraded by its own wind-down.
    void settle_boot(rr_emod_types::DiagnosticState grade);

    rr_emod_lc::RrRegistryTree reg_tree_;
    std::thread run_t_;
};
}  // namespace rr_emod_serde

#endif  // RR_EMOD_SERDE_RR_SUPERVISOR_HPP
