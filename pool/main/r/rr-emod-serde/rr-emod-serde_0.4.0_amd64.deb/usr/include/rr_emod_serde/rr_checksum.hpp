// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <cstdint>
#include <array>
#include <vector>
#include "rr_emod_serde/rr_emod_types.hpp"

namespace rr_util {
    class RRChecksum {
        public:

        /**
         * generate checksum CRC-16 CCIT-FALSE checksum.
         */
        static uint16_t generate(const std::array<std::vector<std::byte>, rr_emod_types::CHANNEL_COUNT>& payload);

        /**
         * Given a previous generated checksum, the method calls generate on payload, and returns the comparison.
         */
        static bool check(uint16_t checksum, const std::array<std::vector<std::byte>, rr_emod_types::CHANNEL_COUNT>& payload);

        // Generate 32 bit CRC
        static std::uint32_t generate32(const void* buf, std::size_t len);

        // Generate mask for 32 bit CRC
        static std::uint32_t mask_crc32(std::uint32_t c);
    };
}