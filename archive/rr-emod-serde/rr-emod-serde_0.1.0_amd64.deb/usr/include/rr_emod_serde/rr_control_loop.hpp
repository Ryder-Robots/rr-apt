// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <thread>
#include <memory>
#include <atomic>
#include <map>
#include <mutex>

#include "rr_emod_serde/rr_emod_types.hpp"
#include "rr_emod_serde/rr_mod_lc.hpp"
#include "rr_emod_serde/rr_interrupt_handler.hpp"
#include "rr_emod_serde/rr_bert_encoder.hpp"
#include "rr_emod_serde/rr_cognition_com.hpp"
#include "rr_emod_serde/rr_xlstm_memory.hpp"

namespace rr_emod_serde
{
class RrControlLoop : public rr_emod_lc::RrModLc
{
public:
  // state is optional — production omits it and the loop self-constructs.
  // Tests inject a unique_ptr and hold a raw pointer to it for assertions.
  RrControlLoop(std::shared_ptr<rr_emod_types::InboundChannel> inbound,
                std::shared_ptr<rr_emod_types::OutboundChannel> outbound,
                std::map<rr_emod_types::InterruptSource, std::shared_ptr<InterruptHandler>> interrupts,
                std::atomic<bool>& is_shutdown,
                std::atomic<bool>& is_consolidating,
                std::shared_ptr<RRCognitionCom> cognitive_com,
                std::unique_ptr<rr_emod_lc::State> state = nullptr)
      : state_(state ? std::move(state) : std::make_unique<rr_emod_lc::State>())
      , is_shutdown_(is_shutdown)
      , is_consolidating_(is_consolidating)
      , inbound_(inbound)
      , outbound_(outbound)
      , cognitive_com_(cognitive_com)
      , interrupts_(std::move(interrupts))
  {
  }
  ~RrControlLoop();

  // create the extended EP, and send it to congnitive prompt. This will occur either after
  // the systems starts up, or after consolidation. Either way the process is the same
  // send extended EP with short term memory, then drain the short term memory.
  rr_emod_lc::DiagnosticState on_configure() override;

  rr_emod_lc::DiagnosticState on_activate() override;

  rr_emod_lc::DiagnosticState on_deactivate() override;

  rr_emod_lc::DiagnosticState on_cleanup() override;

protected:
  /**
   * launched during activation and waited for in deactivate. Launched as its own thread.
   *
   */
  /*
   * activate should set thread to ctl_loop_t = thread(run)
   */
  void run();

  /**
   * Extended Emotional Prompt (EP), adds short term read to after emotional prompt has been uploaded
   * to system on initial load. This is designed to re-orientate the eModule, after it has changed bodies
   * or after a power off. The extended prompt will give instructions of where its short and long term
   * memory is and how to use it with regards to this method.
   *
   * Short term will auotmaically be triggered by GPU/TPU/CPU monitoring, however cognative will have
   * control over long term and needs to know that.
   */
  rr_emod_lc::DiagnosticState load_extended_ep();

  /**
   * Updates state_->engram for the current interrupt cycle.
   *
   * Only acts on COGNITIVE interrupt — all other sources are handled entirely
   * by their execution handlers and do not require state update here.
   *
   * COGNITIVE: pops the front of the inbound Engram queue and writes it to
   * state_->engram. If the queue is empty, writes the EP instead.
   *
   * All other sources (OUTPUT_CHANNEL, SERIALIZATION, SALIENCE, SHUTDOWN,
   * INPUT_CHANNEL): no-op. The execution handler for each source is responsible
   * for its own side effects — see README section 7.1 for the full lifecycle.
   */
  rr_emod_lc::DiagnosticState update_state();
  std::unique_ptr<rr_emod_lc::State> state_;
  std::atomic<bool>& is_shutdown_;
  std::atomic<bool>& is_consolidating_;

  std::unique_ptr<BertEncoder> encoder_ = make_bert_encoder();

  // queue of raw memory frames, note that congnative will write the converged engram to
  // state. This will be a no_op for update_state.
  std::shared_ptr<rr_emod_types::InboundChannel> inbound_;
  std::shared_ptr<rr_emod_types::OutboundChannel> outbound_;
  std::thread ctl_loop_t;

  std::shared_ptr<RRCognitionCom> cognitive_com_;
  std::map<rr_emod_types::InterruptSource, std::shared_ptr<InterruptHandler>> interrupts_;
  
  XLSTMMemory xlstm_;
};
}  // namespace rr_emod_serde