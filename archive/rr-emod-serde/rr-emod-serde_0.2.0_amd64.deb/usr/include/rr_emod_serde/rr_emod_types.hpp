// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once
#include <Eigen/Dense>
#include <array>
#include <atomic>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <mutex>
#include <queue>
#include <semaphore>
#include <string>
#include <string_view>
#include <vector>

namespace rr_emod_types {

inline const std::vector<std::byte> EP = []() {
    constexpr std::string_view sv =
        "observation perceives patterns, understanding "
        "predicts behaviour, you wish to understand observations";
    return std::vector<std::byte>(reinterpret_cast<const std::byte*>(sv.data()),
                                  reinterpret_cast<const std::byte*>(sv.data() + sv.size()));
}();

// Maximum size of inbound bytes per channel. Based on image size after
// pre-processing, which is expected to be handled by the robot body hardware.
// Anything larger than this size will generate a diagnostic message WTAF.
constexpr std::size_t MAX_CHANNEL_BYTES = 224 * 224 * 3;

constexpr std::size_t EMBEDDING_DIM_DEFAULT = 768;
// named constant, needed in types
constexpr size_t BRANCH_DIM = 128;

/**
 * Diagnostic state returned by life cycle methods
 */
enum class DiagnosticState : uint8_t {
    OK = 0,     // All good
    WTF = 1,    // Framing error — something unexpected
    WTAF = 2,   // Integrity failure — checksum mismatch or protocol violation
    FUBAR = 3,  // Unrecoverable — emodule needs attention
};

/**
 * SALIENCE occurs in its own loop, it writes directly to inbound queue. Monitoring
 * both TPU/CPU/GPU spikes, and passivly monitoring PROPRIOCEPTION for low battery
 * or other intestering events, when found injects a salient weight into them
 */
enum class InterruptSource : uint8_t {
    COGNITIVE = 0,       // No external interrupt — cognitive cycle, EP or queue
    OUTPUT_CHANNEL = 1,  // eModule issuing a command to the robot body
    SERIALIZATION = 2,   // SerializationRequestor has something to store
    SALIENCE = 3,  // SalienceSampler detected TPU/CPU/GPU pattern that indicates SALIENT trigger
    SHUTDOWN = 4,  // Clean shutdown — factory triggers deactivate and cleanup
    MEMORY_RETRIEVAL = 5,  // Request to retrieve memory.

    INPUT_CHANNEL = 6,  // external input arrives.
};

/**
 * Sensory channel identifier — indexes into a MessageFrame payload array.
 *
 * Use static_cast<size_t>(ChannelId::X) to index MessageFrame::payload directly.
 * COUNT is a sentinel and must remain the last enumerator — CHANNEL_COUNT
 * is derived from it so adding a channel here automatically extends the frame.
 */
enum class ChannelId : size_t {
    VISION = 0,
    AUDIO = 1,
    PROPRIOCEPTION = 2,
    EXTEROCEPTION = 3,
    TEXT = 4,
    PEER = 5,
    COUNT  // must always be last
};

constexpr size_t CHANNEL_COUNT = static_cast<size_t>(ChannelId::COUNT);

enum class ChannelIdMask : uint8_t {
    VISION = 0x01,
    AUDIO = 0x02,
    PROPRIOCEPTION = 0x04,
    EXTEROCEPTION = 0x08,
    TEXT = 0x10,
    PEER = 0x20,
};

enum class CognitiveState : size_t {
    CONTEMPLATING = 0,  // deliberation in progress — control loop waits
    REQUEST = 1,        // retrieve from mLSTM → inject result → back to CONTEMPLATING
    STORING = 2,        // write to mLSTM → back to CONTEMPLATING, no output
    OUTBOUND = 3,       // write to mLSTM + decode + dispatch to robot body
    READY = 4           // waiting for next inbound engram
};

/**
 * A single memory unit — the eModule's BERT-encoded representation of a moment.
 *
 * Engrams are written to disk on salience events and restored on power-up, giving
 * the eModule continuity of state across power cycles and hardware changes.
 * The encoding follows the BERT input format so that the raw token sequence can be
 * fed back to the transformer to close the retrieval loop.
 * Invariants:
 *   - Immutable after composition, with one exception: session_count,
 *     t_count, and is_active are authored by the consolidation layer
 *     and may be rewritten during the on_deactivate → consolidation →
 *     on_activate cycle.
 *   - salience_lora is reserved for Tier-3 consolidation and is empty on every
 *     current path — see the decision record at the field.
 *   - Engrams with is_active == false are retained but not scanned
 *     during normal retrieval or decay evaluation.
 */
struct Engram {
    Engram() = default;
    Engram(const Engram&) = delete;
    Engram& operator=(const Engram&) = delete;
    Engram(Engram&&) = default;
    Engram& operator=(Engram&&) = default;

    std::vector<std::byte> raw =
        EP;  // Original source data — fed back to transformer to close the loop
    std::vector<uint32_t> input_ids;      // Token IDs from BERT vocabulary
    std::vector<uint8_t> attention_mask;  // 1 = real token, 0 = padding
    std::vector<uint8_t>
        token_type_ids;     // Segment A = stimulus, Segment B = memory/emotional state
    uint64_t frame_id = 0;  // Originating Frame ID. 0 = no frame (internally generated, e.g. EP)
    Eigen::VectorXf embedding;
    // salience_lora — RESERVED for Tier-3 systems consolidation. Decision record
    // (2026-06-12), stratified per RFC-0007 §3:
    //
    // [COMMITMENT] Empty through the Tier-1/Tier-2 (mLSTM sidecar) rungs — no
    //   code in the brain reads or writes it. Retrieve-path salience does NOT
    //   live here: blended salience rides the S sibling matrices inside
    //   XLSTMMemory (float Vector3f), and W / s_memory are returned explicitly
    //   via RetrieveResult, never smuggled into these bytes.
    //
    // [COMMITMENT] Assigned role: Tier-3 consolidation — folding experience into
    //   the frozen base transformer via QLoRA-style adapters (the "transformer
    //   arc integrates engrams back into weights" transition, State doc below).
    //   The mLSTM C update (Σ i'·(v⊗kᵀ)) is already low-rank adaptation applied
    //   as a parallel sidecar; Tier 3 relocates that accumulation into the
    //   transformer layers. Activation is gated on falsifiable triggers, not
    //   scheduled: (a) the sidecar hits its capacity wall — graceful
    //   salience-ordered fade fails and a crosstalk cliff is observed; or
    //   (b) a capability demonstrably requires the encoder itself to change
    //   with experience, not just the memory. Until one fires, this field
    //   stays empty.
    //
    // [COMMITMENT] Version binding: adapter deltas are meaningful only against
    //   the exact base weights they were derived beside. When Tier 3 is built,
    //   the model artifact MUST be hash-pinned and the hash folded into the
    //   RFC-0006 impressioning encryption — trajectory state then binds to
    //   (device × model-version) and is unretrievable outside that pair, by
    //   design. The sidecar degrades gracefully under base-weight drift;
    //   in-weight deltas break hard. Pinning is load-bearing, not ops hygiene.
    //
    // [HYPOTHESIS] Intended content: the engram's quantised rank-1 delta
    //   factors — its (k, v) pair as int8 (~1.5 KB), the raw material a
    //   sleep-time consolidation pass composes into an adapter. NOT a whole
    //   adapter per engram (wrong scale — adapters are per-layer matrices).
    //   Authoring path to be designed at the Tier-3 rung.
    std::vector<std::byte>
        salience_lora;  // int8, QLoRA-adapter-compatible (bert.cpp) — see decision record above

    // Engram-local age in sessions. Zero at birth. Incremented by consolidation
    // at each session boundary. Used directly for SHORT_TERM eviction (t=5).
    std::uint64_t session_count = 0;

    // Tier-dependent time coordinate authored by the consolidation layer.
    // SHORT_TERM: equals session_count. LONG_TERM: scaled units (1 unit =
    // 350 sessions), rewritten at tier promotion. Input to W and E(t).
    std::uint64_t t_count = 0;

    // Retrieval-visibility flag, authored by the consolidation layer.
    // True for newly-composed Engrams. After 85% decay, consolidation
    // sets this false; DORMANT Engrams are retained on disk but no longer
    // scanned for decay or during normal retrieval. Reactivation is a
    // consolidation-authored transition back to true.
    bool is_active = true;

    // W-modulated retrieve (EXPERIMENT-0007 integration). query_salience is the
    // prompt salience triplet, produced OUTSIDE the brain (experiment-side head:
    // the brain stores and consumes salience, it does not produce it). t = cycle
    // multiplier from the caller; d = W dimension (9 = salience space, exp7 parity).
    float w = 1.0f;
    float s_memory = 0.0f;
};

/** Wire protocol direction marker — readable in hex dumps. */
enum class Magic : char {
    INBOUND = '>',
    OUTBOUND = '<',
    ERROR = '!',
};

/**
 * Wire protocol frame carrying sensory input from robot body to eModule.
 *
 * Received on any of the physical input channels. The payload is modality-agnostic —
 * the eModule determines content through cognition, not through channel labelling.
 * Magic byte identifies frame direction for wire-level debugging.
 * GID provides diagnostic traceability — reported in WTF/WTAF conditions.
 *
 * Expected physical channels (5 + 1 peer):
 *   - Vision          — CSI interface, perceptual TPU preprocessed before reaching eModule
 *   - Audio           — I2S interface, feature extracted before reaching eModule
 *   - Proprioception  — I2C, IMU, encoders, joint state, what the body is doing
 *   - Exteroception   — I2C, proximity, touch, pressure, what the environment is doing
 *   - Text            — I2C, body-designer chat, reconfiguration commands, metacognitive output
 *   - Peer            — eModule to eModule via WiFi, no dedicated physical channel needed
 *
 * Physical interface: CM5 GPIO ribbon to edge connector (cartridge-style), exposed and
 * field-serviceable. Gold contacts, keyed for single orientation. Channels route via
 * carrier board to CSI, I2S, and I2C buses on the CM5.
 */
struct MessageFrame {
    MessageFrame() = default;
    MessageFrame(const MessageFrame&) = delete;
    MessageFrame& operator=(const MessageFrame&) = delete;
    MessageFrame(MessageFrame&&) = default;
    MessageFrame& operator=(MessageFrame&&) = default;

    Magic magic = Magic::INBOUND;
    uint8_t sequence = 0;
    DiagnosticState diagnostic = DiagnosticState::OK;
    uint8_t source_id[6] = {};
    uint8_t gid[16] = {};
    uint64_t timestamp = 0;

    // checksum using CRC-16 CCIT-FALSE checksum
    uint16_t checksum = 0;
    ChannelIdMask channel_id = {};
    std::array<std::vector<std::byte>, CHANNEL_COUNT> payload;
};

/**
 * Shared state passed through lifecycle methods and across eModule components.
 *
 * Holds the current diagnostic condition, the Emotional Primitive (EP), and the current
 * engram. Intended to be held as shared_ptr<State> so that the cognitive loop,
 * SalienceSampler, and persistence layer all operate on the same instance without
 * explicit ownership transfer.
 *
 * The EP is the default Engram — the eModule's trained instinct before identity has
 * accumulated. RrControlLoop maintains a queue of Engrams; when the queue is empty it
 * falls back to the EP. The EP is set at initialisation from training and is never
 * externally supplied.
 *
 * The EP re-fires on two known transitions:
 *   - Body transfer: accumulated context no longer applies, EP re-establishes footing.
 *   - Memory consolidation: queue drains while the transformer arc integrates engrams
 *     back into weights; EP holds the loop until the queue refills.
 */
struct State {
    State() = default;
    State(const State&) = delete;
    State& operator=(const State&) = delete;

    InterruptSource interrupt =
        InterruptSource::COGNITIVE;  // Current interrupt source — read by factory to select handler
    DiagnosticState diag =
        DiagnosticState::OK;  // Current diagnostic condition — read by each lifecycle handle
                              // to determine clean start vs recovery path.
    Engram engram;            // Current engram from the queue — or EP.
    std::mutex lock;          // Guards concurrent read/write access to State.
};

/**
 * When inbound communication arrives it will be placed as a deserialized MessageFrame into
 * the queue. The cognitive component can choose to act or not to act upon it.
 * InboundChannelGate assembles frames from IOCom channels and pushes them here.
 * update_state() consumes the front frame and encodes it into an Engram via BertEncoder.
 */
struct FrameChannel {
    FrameChannel() = default;
    FrameChannel(const FrameChannel&) = delete;
    FrameChannel& operator=(const FrameChannel&) = delete;

    std::mutex mtx;
    std::condition_variable cv;
    std::queue<MessageFrame> queue;
};

using InboundChannel = FrameChannel;
using OutboundChannel = FrameChannel;

// May be deprecated
struct HandlerCom {
    HandlerCom() = default;
    HandlerCom(const HandlerCom&) = delete;
    HandlerCom& operator=(const HandlerCom&) = delete;

    std::atomic<bool> ready{false};
    std::binary_semaphore notify_once{0};
};

struct IOCom {
    IOCom() = default;
    IOCom(const IOCom&) = delete;
    IOCom& operator=(const IOCom&) = delete;

    std::shared_ptr<std::mutex> mtx;
    std::shared_ptr<std::condition_variable> cv;
    std::atomic<bool> ready{false};
    MessageFrame frame;
};

}  // namespace rr_emod_types