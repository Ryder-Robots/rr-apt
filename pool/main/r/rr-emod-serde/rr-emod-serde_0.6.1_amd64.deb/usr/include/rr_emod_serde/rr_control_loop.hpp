// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_CONTROL_LOOP_HPP
#define RR_EMOD_SERDE_RR_CONTROL_LOOP_HPP

#include <atomic>
#include <cstddef>
#include <rr_emod_serde/rr_cognition_com.hpp>
#include <rr_emod_serde/rr_emod_types.hpp>
#include <rr_emod_serde/rr_inference_memory_io.hpp>
#include <rr_emod_serde/rr_logger.hpp>
#include <rr_emod_serde/rr_mode_participant.hpp>
#include <rr_emod_serde/rr_xlstm_memory.hpp>
#include <thread>

namespace rr_emod_lc {
class ModeConductor;
}

namespace rr_emod_serde {

// The mode vocabulary is shared with everything that obeys it, so it lives
// with the other shared vocabularies; the loop keeps the short name because
// the mode is what this class runs.
using rr_emod_types::Mode;

enum class ClState { INGRESS, EGRESS, RECALL, CORTEX_MEMORY, SELF_PROMPT, IDLE };

class RrControlLoop : public rr_emod_lc::RrModeParticipant {
public:
    explicit RrControlLoop(RrLogger& logger, rr_emod_types::InboundChannel& inbound,
                           rr_emod_types::OutboundChannel& outbound, XLSTMMemory& memory,
                           RRCognitionCom& cognitive_com, InferenceMemoryIO& cortex_io);

    // Joins the run thread — a default dtor would std::terminate on a joinable
    // run_t_ if destroyed while active.
    ~RrControlLoop();

    // The plane arrives after construction: the conductor's array names this
    // loop, so the loop has to exist first and the wire comes back the other
    // way once both stand. A loop that was never handed one refuses to
    // configure — a modeless loop must not be representable past that door.
    void adopt_conductor(rr_emod_lc::ModeConductor& conductor);

    // A demand is a relay: each verb below latches its mode into the
    // conductor and the loop's own tick performs it. Unrefusable is not the
    // same as immediate.

    // The operator's ask. Blocks until the consolidation it started has ended
    // and the mode has settled back to ARM.
    void command_consolidation();

    // The far side has finished (or abandoned) training. Blocks until ARM
    // lands, so a walk that follows this call always meets a settled mode.
    void end_consolidation();

    // The Amygdalar's demand. Never blocks: the demander compels, it does not
    // wait. Compelling a machine already asleep is a no-op by idempotence.
    void compel_consolidation();

protected:
    rr_emod_types::DiagnosticState on_configure() override;
    rr_emod_types::DiagnosticState on_activate() override;
    rr_emod_types::DiagnosticState on_deactivate() override;
    rr_emod_types::DiagnosticState on_cleanup() override;
    rr_emod_types::DiagnosticState on_shutdown() override;

    // The mode plane's park and unpark — the case bodies of the old mode
    // machine, performed here. The pump runs on this loop's own thread,
    // between ticks, so nothing is ever mid-step when these fire.
    rr_emod_types::DiagnosticState on_select_consolidate() override;
    rr_emod_types::DiagnosticState on_select_arm() override;

private:
    // The thread body; on_activate starts it, on_deactivate takes it back. One
    // driver only — nothing else may run the loop.
    void run();

    // Set deactivating_ under the com's mutex, wake the cv, join. The dtor and
    // on_deactivate both funnel here.
    void stop_run_thread();

    void dispatch(ClState s);
    ClState select();
    bool clock_dirty();

    // A percept is waiting for admission — a body frame at the inbound gate or
    // a cortex prompt in its mailbox. Two doors, one row.
    bool percept_waiting();

    // ===================== handlers — bounded, blocking never ==================
    void on_ingress();
    void on_recall();
    void on_egress();
    void on_cortex_memory();
    void on_self_prompt();
    void on_idle();

    // lifecycle wants the thread back
    std::atomic<bool> deactivating_{false};

    // The bracket witness: set when this loop's park performs, re-armed when
    // a whole-bracket ask begins. The demanded/delivered pair alone cannot
    // prove the walk went THROUGH consolidation — a fast bracket could close
    // before the asker reaches its wait — so the ask waits on evidence the
    // park ran plus the delivered ARM.
    std::atomic<bool> parked_since_ask_{false};

    // The count of consecutive ARM-mode idle ticks; any other selection resets
    // it, and the period-th tick executes the self-prompt. A starting value:
    // biology's idle-thought interval is seconds, not milliseconds — tune it
    // from the instrument, not from the analogy.
    static constexpr std::size_t SELF_PROMPT_PERIOD{40U};
    std::size_t idle_run_ = 0;

    std::thread run_t_;

    // Borrowed after construction through adopt_conductor(); on_configure and
    // on_activate both refuse while this is still null, so an unwired loop
    // can neither pass CONFIGURE nor start the thread that would follow it.
    rr_emod_lc::ModeConductor* conductor_{nullptr};

    RrLogger& logger_;
    rr_emod_types::InboundChannel& inbound_;
    rr_emod_types::OutboundChannel& outbound_;
    XLSTMMemory& memory_;
    RRCognitionCom& cognitive_com_;
    InferenceMemoryIO& cortex_io_;
};
}  // namespace rr_emod_serde

#endif  // RR_EMOD_SERDE_RR_CONTROL_LOOP_HPP
