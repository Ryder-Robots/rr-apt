// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <memory>
#include <rr_emod_serde/rr_emod_types.hpp>

namespace rr_emod_serde
{

/**
 * Abstract base for all interrupt source handlers.
 *
 * Each interrupt source has a concrete implementation of this interface.
 * The factory constructs handlers once and holds them as shared_ptr — ownership
 * is shared between the factory/control loop and the service thread that calls handle().
 *
 * Per-source contract (see README section 7.1):
 *
 *   COGNITIVE        — sends state_->engram to the cognitive service.
 *   OUTPUT_CHANNEL   — reads state_->engram, converts to body command, sends to robot.
 *   SERIALIZATION    — writes state_->engram to mLSTM matrix C (volitional — cognitive decided).
 *   SALIENCE         — writes state_->engram to mLSTM matrix C (hardware-triggered — SalienceSampler).
 *   SHUTDOWN         — lifecycle teardown only, does not touch state_->engram.
 *   INPUT_CHANNEL    — uses raw input as query Q against mLSTM C, retrieves matching engram,
 *                      pushes onto the COGNITIVE inbound queue. Input never reaches cognition raw.
 *
 * Dispatch lifecycle per interrupt:
 *   service thread  →  handle()         — concrete work, sets handler_com_->ready = true
 *   control loop    →  is_ready()       — polls handler_com_->ready
 *   control loop    →  on_deactivate()  — deploys EP, resets ready, releases service thread
 *   service thread  →  [unblocks via handler_com_->notify_once]
 */
class InterruptHandler
{
public:
  InterruptHandler(
    std::shared_ptr<rr_emod_types::State> state,
    std::shared_ptr<rr_emod_types::HandlerCom> handler_com)
    : state_(state), handler_com_(handler_com)
  {
  }

  virtual ~InterruptHandler() = default;

  InterruptHandler(const InterruptHandler&) = delete;
  InterruptHandler& operator=(const InterruptHandler&) = delete;
  InterruptHandler(InterruptHandler&&) = delete;
  InterruptHandler& operator=(InterruptHandler&&) = delete;

  virtual bool is_ready() = 0;
  virtual void on_deactivate() = 0;
  virtual rr_emod_types::DiagnosticState handle(rr_emod_types::MessageFrame& frame) = 0;

protected:
  std::shared_ptr<rr_emod_types::State> state_;
  std::shared_ptr<rr_emod_types::HandlerCom> handler_com_;
};
}