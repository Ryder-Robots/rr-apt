// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_MODE_PARTICIPANT_HPP
#define RR_EMOD_SERDE_RR_MODE_PARTICIPANT_HPP

#include <atomic>
#include <rr_emod_serde/rr_emod_types.hpp>
#include <rr_emod_serde/rr_lc.hpp>

namespace rr_emod_lc {

/**
 * A lifecycle node that also obeys the running mode.
 *
 * The lifecycle says whether a component exists and is running; the mode says
 * what the running machine is FOR right now — inference or training. This
 * base grafts the second axis onto the first, and the graft point is guarded
 * once, here: a mode verb on a component that is not ACTIVE is refused
 * before any hook runs, because a mode is a property of a running thing.
 *
 * That refusal is the one contract difference from the lifecycle door.
 * transition() always runs and reports how well it went; a mode verb can be
 * refused, and a refusal (WTF) means the hook never ran.
 *
 * Four public doors, four hooks — a participant is a SUBJECT of the mode the
 * way a node is a subject of the lifecycle. It can be selected into a mode;
 * it cannot select anything else, itself included. Whoever holds the set of
 * participants owns the order they are driven in. The select verbs are quick
 * — park or unpark, never block. consolidate() is the slow one, and it is
 * refused unless this participant is already parked, so the work can never
 * run over live inference.
 *
 * The mode word here is the delivered truth — nothing else publishes it. It
 * lands only when the hook returns OK, mirroring the phase rule: trouble
 * leaves the old reading in place, "it ran, it did not land". It is atomic
 * because the flip happens on the driving thread while the participant's own
 * thread reads it.
 */
class RrModeParticipant : public RrLc {
public:
    // Park inference for this participant; the word lands on CONSOLIDATE.
    [[nodiscard]] rr_emod_types::DiagnosticState select_consolidate();

    // Unpark — inference resumes; the word lands on ARM.
    [[nodiscard]] rr_emod_types::DiagnosticState select_arm();

    // Back to the boot mode: the testing door, and teardown symmetry — UNSET
    // is the last mode as well as the first.
    [[nodiscard]] rr_emod_types::DiagnosticState select_unset();

    // Perform this participant's consolidation work. Slow, blocks; refused
    // unless already parked.
    [[nodiscard]] rr_emod_types::DiagnosticState consolidate();

    // What mode this participant was last cleanly selected into. Safe to read
    // from the participant's own thread.
    [[nodiscard]] rr_emod_types::Mode mode() const { return mode_.load(std::memory_order_acquire); }

protected:
    explicit RrModeParticipant(const char* name) : RrLc(name) {}

    // Park inference for this participant. Quick: latch, wake, return.
    virtual rr_emod_types::DiagnosticState on_select_consolidate() = 0;

    // Unpark. Quick.
    virtual rr_emod_types::DiagnosticState on_select_arm() = 0;

    // Most participants have nothing extra to undo on the way out; the
    // default keeps the empty case honest instead of forcing a stub.
    virtual rr_emod_types::DiagnosticState on_select_unset() {
        return rr_emod_types::DiagnosticState::OK;
    }

    // The consolidation work itself. A participant that only parks — its
    // training happens elsewhere — leaves this as the default.
    virtual rr_emod_types::DiagnosticState on_consolidate() {
        return rr_emod_types::DiagnosticState::OK;
    }

private:
    // The shared shape of the three select verbs: guard, run the hook, land
    // the word only on OK.
    [[nodiscard]] rr_emod_types::DiagnosticState select_mode(rr_emod_types::Mode next);

    std::atomic<rr_emod_types::Mode> mode_{rr_emod_types::Mode::UNSET};
};
}  // namespace rr_emod_lc

#endif  // RR_EMOD_SERDE_RR_MODE_PARTICIPANT_HPP
