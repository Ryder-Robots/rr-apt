// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <Eigen/Dense>
#include <atomic>
#include <condition_variable>
#include <memory>
#include <mutex>
#include <utility>

#include "rr_emod_serde/rr_emod_types.hpp"

namespace rr_emod_serde {

/**
 * provides subsample of averages of statitics as they flow through.
 *
 * calculations are performed when diagnostic_ is true.
 */
struct DiagStats {
    double u_sum = 0, w_sum = 0, acc_sum = 0, loss_sum = 0;
    double u_count = 0, w_count = 0, acc_count = 0, loss_count = 0;
};

/**
 * used to provide channel between cognition and the control loop. Expected to
 * a shared pointer available to both cognition, and control loop objects.
 */
class RRCognitionCom {
public:
    RRCognitionCom() = default;
    ~RRCognitionCom() = default;

    rr_emod_types::InterruptSource get_interrupt();
    rr_emod_types::CognitiveState get_state();
    std::pair<rr_emod_types::Engram, rr_emod_types::ChannelIdMask> get_request();
    // SESSION-0047: Query resource capacity state (memory, battery, bandwidth, etc.)
    rr_emod_types::CapacityState get_capacity_state();

    // intended to be only used by cognition
    void set_interrupt(rr_emod_types::InterruptSource interrupt);
    void set_state(rr_emod_types::CognitiveState state);
    void inbound(rr_emod_types::Engram inbound, rr_emod_types::ChannelIdMask mask);
    void set_request(rr_emod_types::Engram query);
    void set_decision(rr_emod_types::Engram decision);
    rr_emod_types::Engram decision();
    // SESSION-0047: Control loop broadcasts resource capacity to cognition
    void set_capacity_state(rr_emod_types::CapacityState capacity);
    void set_consolidating(bool on);
    bool get_consolidating();

    std::mutex mtx;
    std::condition_variable cv;
    DiagStats stats;
    std::atomic<bool> diagnostic{false};
    

protected:
    // Boot state = READY ("waiting for next inbound engram"). Without this initializer
    // zero-init lands on CONTEMPLATING(0) and a freshly-activated cognition thread
    // steps a phantom percept before the first real one arrives (PR #4 review).
    rr_emod_types::CognitiveState state_{rr_emod_types::CognitiveState::READY};
    rr_emod_types::InterruptSource interrupt_;
    rr_emod_types::CapacityState capacity_ = rr_emod_types::CapacityState::OK;
    rr_emod_types::Engram inbound_;
    rr_emod_types::ChannelIdMask channel_mask_{};
    rr_emod_types::Engram decision_;
    std::atomic<bool> consolidating_{false};
};
}  // namespace rr_emod_serde