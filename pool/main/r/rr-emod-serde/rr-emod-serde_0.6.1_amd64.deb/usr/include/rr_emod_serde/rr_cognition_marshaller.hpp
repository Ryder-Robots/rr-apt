// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_RR_COGNITION_MARSHALLER_HPP
#define RR_EMOD_SERDE_RR_COGNITION_MARSHALLER_HPP

#include <Eigen/Dense>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <rr_emod_serde/rr_emod_types.hpp>
#include <rr_emod_serde/rr_logger.hpp>
#include <span>

namespace rr_emod_serde {

// What the net produced, in the brain's own types. Every field is a value the rest of
// the brain can already read, which is the whole point: nothing that comes out of here
// needs a modelling library to be understood, so nothing downstream has to link one.
struct Fused {
    Eigen::VectorXf embedding;  // fused engram; what a recall is matched on
    Eigen::VectorXf logits;     // the net's own readout, as wide as the weights that made it
    float u;                    // normalised softmax uncertainty, on [0, 1]
};

// The ways a set of weights can be wrong once it is already in hand. Absence and
// unreadability are not here: those are settled before these bytes are asked for, and
// what is left is only what the model itself can rule on.
//
// Not a health, and not a store result. This object has no lifecycle, so it has no
// condition to report — it reports on the thing it was handed. Turning that into a
// verdict about the brain belongs to whoever owns one.
enum class ModelFault : uint8_t {
    None = 0,
    NotAnArchive = 1,       // the bytes are not weights at all
    DimensionMismatch = 2,  // read, and does not fit this brain
    NotFinite = 3           // read, fits, and produces numbers that are not numbers
};

// The size of what the net is holding, in two numbers, taken where they are still cheap.
// Not a health and not a measurement of quality — only enough to tell an untrained net
// from an unread one, which is a distinction nothing downstream can otherwise make.
struct WeightNorms {
    float absent;       // every masked-off channel routes onto this; zero means it is untrained
    float fuse_weight;  // the control: separates that from nothing having been read at all
};

/**
 * Holds the net, and is the only thing that does.
 *
 * The modelling library appears here and nowhere else. It is not in this header
 * either: the net lives behind Impl, which is declared in the implementation file, so
 * a caller can hold one of these without the library ever reaching its translation
 * unit. That is the reason the class exists — not to make the net swappable, but to
 * stop the fact of it from spreading.
 *
 * There is one implementation, chosen when the brain is built rather than when it
 * runs, so none of this is virtual and every call through it can be resolved where it
 * is written.
 *
 * Marshalling is the job. Values arrive as the brain's own types and leave as them,
 * and the conversion at each edge belongs on this side of it: a caller that had to
 * shape its input for the net would know what the net wanted, which is the knowledge
 * this class exists to keep.
 */
class RrCognitionMarshaller {
public:
    // Takes only somewhere to log. How wide the readout is belongs to the weights and
    // is read back off them, never declared here: a width told to the net is a width
    // that can disagree with the net, and nothing downstream could say which of the two
    // was the right one.
    explicit RrCognitionMarshaller(RrLogger& logger);

    // Out of line because the net is an incomplete type above: this is where it needs
    // a complete one, and that belongs beside the code that built it.
    ~RrCognitionMarshaller();

    // Sole owner of the net. A copy would be a second set of weights that looked like
    // the same one; a move would leave a brain holding nothing to think with.
    RrCognitionMarshaller(const RrCognitionMarshaller&) = delete;
    RrCognitionMarshaller& operator=(const RrCognitionMarshaller&) = delete;
    RrCognitionMarshaller(RrCognitionMarshaller&&) = delete;
    RrCognitionMarshaller& operator=(RrCognitionMarshaller&&) = delete;

    // One percept in, one thought out.
    //
    // The mask says which channels are really present; the ones that are not are
    // replaced by the net's own learned stand-ins rather than by zeros, so an absent
    // channel reads as absence instead of as silence.
    //
    // An empty embedding is a percept that carried no content, which is a real thing
    // to be handed and not a fault. It is answered here rather than refused, because
    // the mask has already decided that none of those values will reach the fusion.
    [[nodiscard]] Fused fuse(const Eigen::VectorXf& embedding, rr_emod_types::ChannelIdMask mask);

    // Reads a set of weights and proves it fits before letting it stand.
    //
    // Bytes, not a path. Every way a disk can fail is somebody else's to settle, and
    // settling it before this is called is what leaves only the model's own answer
    // here. This is the airlock: whatever the library does when it is handed something
    // it does not like stops at this boundary and leaves as a value.
    [[nodiscard]] ModelFault apply_weights(std::span<const std::byte> archive);

    // Puts the net back where an emptied brain has to leave it.
    //
    // In place. The shapes were built once, at construction, and nothing after that
    // may build them again.
    void reset();

    // What the net is carrying, for whoever has to say so out loud. Reading it costs a
    // pass over two tensors, so it is asked for rather than published.
    [[nodiscard]] WeightNorms weight_norms() const;

private:
    // The net, and everything the net needs, declared where the modelling library is
    // already in scope. Nothing about it is visible from here, which is the whole
    // reason the class is shaped this way: holding one of these does not put that
    // library in front of the holder.
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

}  // namespace rr_emod_serde

#endif  // RR_EMOD_SERDE_RR_COGNITION_MARSHALLER_HPP
