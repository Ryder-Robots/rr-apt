// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <array>
#include <atomic>
#include <cstddef>
#include <memory>
#include <string>
#include <thread>
#include <vector>
#include <chrono>
#include <cstdint>

#include <rr_emod_serde/rr_cognition_com.hpp>
#include <rr_emod_serde/rr_ledger.hpp>
#include <rr_emod_serde/rr_logger.hpp>
#include <rr_emod_serde/rr_xlstm_memory.hpp>
#include <rr_emod_serde/supervisor.hpp>

namespace rr_emod_serde {

// Forward-declared so this header stays light (doesn't pull in the loop or cognition,
// and thus the whole brain — rr_cognition.hpp would drag torch in here). The ctor/dtor
// that need the complete types live in the .cpp.
class RrControlLoop;
class RrCognition;
class InferenceMemoryIO;
class RrCortexSocket;
class RrRendezvous;

// Same lightness pact: forward-declared so this header never drags in debugio.pb.h.
// DebugPort is the observing-port interface (nullable = the consent gate); DebugMailbox
// is the single-slot query inbox run_loop() drains. Both are pointer-held below and
// only completed in the .cpp (rr_debug_port.hpp).
class DebugPort;
class DebugMailbox;

}  // namespace rr_emod_serde

// Same pact again: the gate headers drag in <sys/ioctl.h>, <linux/if.h> and
// <netinet/ether.h> (the outbound gate reads the MAC for source_id), none of which
// belongs in every translation unit that sees a supervisor.
namespace rr_inbound_gate {
class InboundChannelGate;
}
namespace rr_outbound_gate {
class OutboundChannelGate;
}

namespace rr_emod_serde {

struct RrSupervisorConfig {
    // Empty = use the persistent compile-time default (resolved in the ctor, where
    // RR_LEDGER_FILE stays private to the .cpp and never leaks into this header).
    std::string ledger_file = "";
    // Action space for cognition's zone head. 7 = scene6ch default; EXP-0019's
    // 8x3 grid uses 24. The harness overrides per experiment.
    std::size_t n_zones = 7;
    // Empty = the memory's compile-time default store. Experiments MUST set a
    // per-run path (EXP-0021 §5.1) — the sleep/wake rung del/recreates the
    // supervisor, and doing that against the production store would trample it.
    std::string memory_base_path = "";
};

// Composition root AND lifecycle controller for the brain. Owns the modules, wires the
// shared coms, and walks lifecycle transitions in dependency order:
//   activate:   memory -> cognition -> loop -> (gate, when wired)   [senses on LAST]
//   deactivate: (gate) -> loop -> cognition -> memory               [senses off FIRST]
// Activation ABORTS on the first non-OK (never open the faucet on a dead brain);
// deactivation is BEST-EFFORT (walks the whole chain, reports the worst diag).
class RrSupervisor : public SupervisorBase {
public:
    RrSupervisor(const RrSupervisorConfig& config);

    ~RrSupervisor();

    void run();

    EngramSessionMeta cmd_ledger();

    rr_emod_types::DiagnosticState cmd_start_session_log() override;

    rr_emod_types::DiagnosticState cmd_end_session_log() override;

    std::vector<rr_log_item> cmd_session_log() override;

    rr_emod_types::DiagnosticState cmd_start_session() override;

    rr_emod_types::DiagnosticState cmd_end_session() override;

    // Consolidation itself is PYTHON-side until cortexes exist (decision 2026-07-03).
    // start/end only bracket it: park the brain (consolidating pause-gate), let the
    // Python trainer own the weights, then persist + resume.
    //
    // TEMP SWITCH (decision 2026-07-03): the supervisor is the SOLE authority over
    // both consolidating flags (the loop's is_consolidating_ and the coms pause-gate)
    // — the brain reactivates only when the supervisor says so, via these commands.
    // This trio is the DELIBERATE python-binding surface: the harness (which owns
    // training until cortexes) grips the brain here — bind start, poll check, end.
    // The loop's flag is deliberately KEPT (not simplified away) as the seam where
    // post-cortex autonomous consolidation (CapacityState-triggered) plugs in and
    // this manual, binding-driven bracket retires.
    rr_emod_types::DiagnosticState cmd_start_consilidation() override;

    // returns true if backpropagation is in progress.
    ConsilidationState cmd_check_consilidation() override;

    rr_emod_types::DiagnosticState cmd_end_consilidation() override;

    // DIAG surface: diagnostics are gated (silent unless enabled) and drained by the
    // supervisor — drain returns the accumulated running sums and resets them.
    void cmd_set_diagnostic(bool on) override;

    DiagStats cmd_drain_diag();

    rr_emod_types::CapacityState cmd_capacity_state() override;

    // TERMINAL. The mirror of run(): run() is configure+activate, this is the way out —
    // the one command that does not return to an operable brain.
    //
    // Deliberately NOT on SupervisorBase (like cmd_ledger and cmd_drain_diag). Making it
    // pure virtual there would force every implementor to commit to a terminal verb before
    // the debug channel has decided how it routes commands and how provenance is carried;
    // it moves down when that lands.
    rr_emod_types::DiagnosticState cmd_shutdown();

    // The address plane, handed out — NOT the sockets. An out-of-process cortex finds the
    // brain by dialling a host:port; an in-process one finds it through this registry, and
    // there is no other way in. Handing back the registry (rather than a socket, a port, or
    // the memory IO) is what keeps the in-process case honest: the caller still has to
    // make_cortex_client() on MEMORY and speak protobuf, exactly as the gRPC stub will.
    // Nothing here grants reach past the wire — find() only returns sockets, and every
    // socket's surface is send()/connect(), not the objects behind it.
    //
    // Empty until on_configure() runs (bind_sockets() mints it); a client built on a null
    // registry is a wiring error, not a degraded run.
    std::shared_ptr<RrRendezvous> rendezvous() const { return rendezvous_; }

    // life cycle handles.
    rr_emod_types::DiagnosticState on_configure() override;

    rr_emod_types::DiagnosticState on_activate() override;

    rr_emod_types::DiagnosticState on_deactivate() override;

    rr_emod_types::DiagnosticState on_cleanup() override;

    rr_emod_types::DiagnosticState on_shutdown() override;

private:
    // Lifecycle internals, NOT commands — deliberately off the cmd_* binding surface
    // above. Called from outside in the wrong order they would bind a socket against a
    // slot whose mutex/cv the gates have not minted yet (see ORDERING IS LOAD-BEARING
    // below), so privacy here makes that order unreachable rather than merely
    // documented. A debug command is the only route in from outside.
    bool bind_sockets();
    void connect_sockets();
    void clear_wake_hooks();

    std::shared_ptr<RrLedger> ledger_;
    std::shared_ptr<RrLogger> logger_;
    std::shared_ptr<XLSTMMemory> xlstm_;

    // The wiring table: channels + coms are supervisor-owned and shared into the
    // modules (the gate wake-hook wires against cognition_com_ when the gate lands).
    std::shared_ptr<rr_emod_types::InboundChannel> inbound_;
    std::shared_ptr<rr_emod_types::OutboundChannel> outbound_;
    std::shared_ptr<RRCognitionCom> cognition_com_;

    // Cortex<->frontal seam (inferenceio.proto): the passive IO the control loop consumes
    // (EngramQuery/Prompt in, results back via respond()). Supervisor-owned like the memory
    // and shared INTO the loop; a cortex reaches it through receiver(channel) — or a gRPC
    // stub later. In ordered_children() so its mailbox lifecycle rides the brain's.
    std::shared_ptr<InferenceMemoryIO> memory_io_;

    // Supervisor is the composition root for the brain. The atomics are held here
    // (the loop takes them by reference) and MUST outlive loop_ — declared before it.
    // Member order = reverse destruction order: loop_ dies first (joins its thread),
    // then cognition_, then the shared plumbing above.
    std::atomic<bool> is_shutdown_{false};
    std::atomic<bool> is_consolidating_{false};
    std::shared_ptr<RrCognition> cognition_;
    std::unique_ptr<RrControlLoop> loop_;

    // ── the sensory plane ────────────────────────────────────────────────────────
    // TWO arrays, one per gate, and they must never be the same one: the gates take
    // opposite roles on a slot (inbound READS, outbound WRITES), so sharing an array
    // would let the outbound gate's ready flag trip the inbound gate's predicate and
    // drain cognition's own output straight back into its input.
    //
    // Supervisor-owned because the slots outlive both the gates and the cortex sockets
    // that will later bind to them, and because only the composition root can hand the
    // same slot to exactly two parties. A cortex socket receives ONE index of each
    // array in its RrSockOpts and can never see another channel — that isolation is
    // the point, and it is why one cortex going slow or absent cannot reach the
    // other five.
    //
    // ORDERING IS LOAD-BEARING: a slot's mutex/cv do not exist until its gate's
    // on_configure() mints them, so gates configure BEFORE any socket binds. Declared
    // after loop_ so they are destroyed FIRST — "senses off first", and the gate
    // threads must join while the channels they push into are still alive.
    using IOComArray = std::array<std::shared_ptr<rr_emod_types::IOCom>,
                                  static_cast<size_t>(rr_emod_types::ChannelId::COUNT)>;
    IOComArray rx_coms_;  // cortex -> inbound gate -> cognition
    IOComArray tx_coms_;  // cognition -> outbound gate -> cortex
    std::unique_ptr<rr_outbound_gate::OutboundChannelGate> outbound_gate_;
    std::unique_ptr<rr_inbound_gate::InboundChannelGate> inbound_gate_;

    // ── the cortex connection plane ──────────────────────────────────────────────
    // Three kinds of socket, and channel_map() IS the topology: SERVERS on this brain's
    // own service channels, one CLIENT per sense channel. The frontal dials OUT to the
    // senses and serves FRONTAL/MEMORY; a cortex mirrors it. sense_cli_ is indexed by
    // ChannelId and sized COUNT, so the services are excluded by construction — the same
    // "< COUNT" guard the receivers use, spelled as an array bound.
    //
    // rendezvous_ FIRST so it is destroyed LAST: its claims_ holds the strong reference
    // to every socket and the socket holds only a weak_ptr back, which makes the REGISTRY
    // the owner and these three members handles. Dropping a handle frees nothing.
    //
    // Declared AFTER the gates so the sockets are destroyed before them and before the
    // slots they push into, and BEFORE run_thread_ so that thread is destroyed first —
    // which is exactly why run_thread_ stays declared last: it will service DIAG and the
    // watchdog against these very sockets, and must never still be running once they are
    // gone. clear_wake_hooks() severs the one edge this ordering cannot: tx_coms_[i]->
    // on_ready captures a socket, and until the hook is cleared that capture keeps the
    // socket alive past the registry that owns it.
    std::shared_ptr<RrRendezvous> rendezvous_;
    std::shared_ptr<RrCortexSocket> frontal_srv_;
    std::shared_ptr<RrCortexSocket> memory_srv_;
    std::array<std::shared_ptr<RrCortexSocket>,
               static_cast<size_t>(rr_emod_types::ChannelId::COUNT)>
        sense_cli_;

    // MINTED, never echoed. A command down ANSWERS nothing: cognition's decision leaves
    // via OUTBOUND with no correlation back to the percept that provoked it
    // (cortex_port.hpp:107), and one cycle can fan out to several channels anyway. ONE
    // counter for the whole brain rather than one per socket — sender_id is server-owned
    // and meaningless downstream, so uniqueness rests on this field alone, and a single
    // sequence makes six cortexes' logs align without a join key. Atomic because the wake
    // hook runs on the gate thread while lifecycle commands run on run_thread_.
    // Pre-incremented at use: ids start at 1, so proto3's default 0 stays readable as
    // "never set".
    std::atomic<uint64_t> next_correlation_id_{0};

    // ── lifecycle fan-out ────────────────────────────────────────────────────────
    // Children in ACTIVATION order ("senses on last"); teardown walks this in REVERSE
    // ("off first") — RFC-0008 §8 invariant 6. This mirrors the member declaration order
    // above, which is itself reverse-destruction order, so the two never disagree.
    std::vector<rr_emod_lc::RrModLc*> ordered_children();

    // ── debug channel ────────────────────────────────────────────────────────────
    // Existence-as-consent: debug_ is the observing port, and its NULLNESS is the mode.
    // A bot that never chose to be watched holds a null port — run_loop() sees it and
    // does nothing (no separate mode flag to drift out of sync with reality). Entering
    // debug swaps in a LiveDebugPort; a deliberately-blind NullDebugPort is the plugged-
    // in-but-refusing state. Cognition takes ownership of that choice later.
    // debug_mailbox_ is the single-slot query inbox, always present (the seam a transport
    // posts to); the port is the gate. BOTH are declared before run_thread_ so the loop
    // that touches them is destroyed first — the reverse-destruction rule above extended.
    std::shared_ptr<DebugPort> debug_;
    std::unique_ptr<DebugMailbox> debug_mailbox_;

    // The supervisor's own steady-state thread: started by on_activate(), stopped and
    // joined by on_deactivate() (and by the dtor, so an active brain is never destroyed
    // with a live thread). For now it only parks until stop is requested; run_diag() —
    // servicing the DIAG channel — joins it here when that lands. Declared LAST so it is
    // destroyed FIRST, before anything the loop body touches.
    void run_loop();
    std::atomic<bool> stop_requested_{false};
    std::thread run_thread_;
};
}  // namespace rr_emod_serde