// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef RR_EMOD_SERDE_CORTEX_PORT_HPP
#define RR_EMOD_SERDE_CORTEX_PORT_HPP

#include <chrono>
#include <memory>
#include <optional>

#include <rr_emod_serde/cortex_transport.hpp>
#include <rr_emod_serde/rr_cortex_receiver.hpp>
#include <rr_emod_serde/rr_emod_types.hpp>

namespace cortex_serde {

/**
 * Outcome of one answering exchange on a CortexPort (retrieve / submit_percept).
 *
 * Three signal channels, one per layer — each layer gets exactly one voice:
 *   - line             (datalink/physical): health of the exchange itself
 *   - result           (session):           whether an answer arrived
 *   - result->status   (cognitive):         what memory said — FOUND / NOT_FOUND
 *
 * INVARIANTS (asserted in the implementation):
 *   - line != OK  =>  result disengaged. A broken exchange never carries an
 *     answer.
 *   - line == OK && result engaged  =>  result->status is FOUND or NOT_FOUND.
 *     DIAG_ERR never reaches the cortex: the port absorbs it and reports the
 *     fault through `line` — line vocabulary stays out of the cognitive
 *     channel.
 *   - line == OK && result disengaged  =>  no answer within the port's
 *     patience (timeout), or the mailbox closed for lifecycle reasons
 *     (deactivate / consolidation). Not a fault, and NOT "memory is empty" —
 *     empty recall is an engaged result with NOT_FOUND. The DNN must never
 *     read plumbing as cognition.
 *
 * [[nodiscard]] on the type: every function returning this — including the
 * future remote stub — inherits the can't-silently-drop-a-fault discipline.
 */
struct [[nodiscard]] RetrieveOutcome {
    rr_emod_types::DiagnosticState line;  // fault across the line; OK otherwise
    std::optional<rr_emod_serde::InferenceMemResult> result;
};

class CortexPort {
public:
    // The transport is the session-layer object: it carries the envelope and
    // owns the wait. Loose-bound deliberately — the harness implements
    // CortexTransport in Python (nanobind trampoline) to wire this port to
    // the control loop for the §4 parity rig; production swaps in an
    // in-process or gRPC implementation without this class changing. Once
    // the receiver-backed transport exists it will own MINTED identity, and
    // the raw ChannelId here — identity as claim, scaffold only — retires.
    explicit CortexPort(rr_emod_types::ChannelId channel_id,
                        std::shared_ptr<CortexTransport> transport,
                        std::chrono::milliseconds timeout)
        : channel_id_(channel_id), transport_(std::move(transport)), timeout_(timeout) {}

    ~CortexPort() = default;

    // passthrough from the minted identity; the port never claims, only reports
    rr_emod_types::ChannelId channel() const { return channel_id_; }

    /**
     * Request a memory engram of the control loop. This is the whole
     * DNN-facing contract: vectors in, RetrieveOutcome out. The channel mask
     * is derived from the port's identity, patience is port policy (ctor),
     * and transport / session / wire all live below this line — the cortex
     * neither knows nor cares how the exchange happens.
     *
     * Blocking is the one behavioural promise this signature makes: parks up
     * to the configured timeout for the response, then returns per the
     * RetrieveOutcome invariants. Any implementation behind this surface —
     * in-process mailbox today, remote stub later — must honour the same
     * call, the same patience, and the same two no-engram meanings.
     */
    RetrieveOutcome retrieve(Eigen::VectorXf query, std::optional<Eigen::VectorXf> salience);

    /**
     * Deliver a percept to the control loop via the full inbound cognitive
     * path (InterruptSource::INPUT_CHANNEL), as distinct from retrieve()'s
     * direct memory query (MEMORY_RETRIEVAL). An answering exchange like
     * retrieve(): parks up to the configured timeout, and the outcome
     * carries cognition's response per the RetrieveOutcome invariants.
     *
     * LOUD DEFERRAL (2026-07-26, two-mailbox ingress): the loop now ADMITS
     * the percept — it forwards to the prompt mailbox and enters cognition
     * when cognition is READY — but the response leg does not exist yet
     * (cognition's decision leaves via OUTBOUND with no correlation back to
     * this envelope). Until PromptResponse is designed, every well-formed
     * submit_percept rides out its patience and returns OK + disengaged;
     * only a malformed percept answers early (DIAG_ERR -> WTAF here). The
     * parity rig must expect the timeout, not the former demux WTAF.
     */
    RetrieveOutcome submit_percept(Eigen::VectorXf percept);

    /**
     * The cortex's reaction to a brain-issued lifecycle command (proto arms
     * 30-39, supervisor-originated): map the transition onto the session
     * mechanism — DEACTIVATE/SHUTDOWN -> transport close(), ACTIVATE ->
     * transport reopen() — and return the ack envelope: STATUS_OK with the
     * transition echoed, or STATUS_ERROR + detail for a non-lifecycle
     * envelope or an unknown transition. Reactions are level-shaped, so a
     * repeated command acks OK again (idempotence over the wire).
     *
     * There are deliberately NO close()/reopen() verbs on this surface: the
     * brain is the authority, the transport is the mechanism, and the
     * DNN-facing surface stays two answering exchanges — a DNN must not
     * close its own ear, so the port offers it no verb to do so. Session
     * state lives in the transport alone: after close(), a parked answering
     * exchange wakes and returns OK + disengaged, and subsequent exchanges
     * return the same immediately (the transport contract) — the port holds
     * no shadow closed-flag to drift out of sync.
     *
     * The ack ANSWERS the brain: its correlation_id is echoed from the
     * command, never minted — the port's own counter belongs to requests
     * this port originates. sender_id is left untouched (server-owned
     * upstream, same as every request). The CALLER carries the ack back —
     * the transport receive path, the parity rig, or the future stream
     * handler; the port judges, it does not move.
     *
     * Called from the transport/supervisor thread, by design possibly while
     * the DNN thread is parked in an answering exchange — that is how a
     * DEACTIVATE unblocks a parked cortex.
     */
    rr_inference::CortexEnvelope handle_lifecycle(
        const rr_inference::CortexEnvelope& command);

private:
    // Envelope metadata is minted HERE, once, for every verb: protocol
    // version, correlation (pre-incremented — ids start at 1, so proto3's
    // default 0 stays distinguishable as "never set"), and the diagnostic
    // timestamp. sender_id is deliberately untouched: server-owned.
    rr_inference::CortexEnvelope create_envelope();

    // §4 parity seeding (planting known engrams as ground truth for the
    // cosine-NN comparison) is a TEST concern: it supplies what production
    // computes — engram placement (the STORING path) and W (the W formula) —
    // so it lives on a befriended fixture in test/, never as a verb on this
    // surface. A production port cannot inject memory cognition never vetted.
    friend class CortexPortFixture;

    rr_emod_types::ChannelId channel_id_;
    std::shared_ptr<CortexTransport> transport_;
    std::chrono::milliseconds timeout_;
    // Plain uint64 on purpose: a port belongs to exactly ONE cortex thread
    // (the mailbox single-consumer invariant, inherited). If ports are ever
    // shared across threads this becomes a torn correlation — revisit then.
    uint64_t next_correlation_id_ = 0;
};

}  // namespace cortex_serde

#endif  // RR_EMOD_SERDE_CORTEX_PORT_HPP
