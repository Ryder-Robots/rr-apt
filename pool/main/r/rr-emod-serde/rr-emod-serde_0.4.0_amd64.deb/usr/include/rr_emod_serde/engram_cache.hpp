// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots

#pragma once

#include <Eigen/Dense>
#include <memory>
#include <unordered_map>
#include <vector>

#include "rr_emod_serde/engram.hpp"
#include "rr_emod_serde/rr_emod_types.hpp"
#include "rr_emod_serde/rr_fstream.hpp"

namespace rr_emod_serde {

class EngramCache {
public:
    // Full DI constructor: accepts pre-created proxy instances
    EngramCache(const std::string& engram_file, const std::string& index_file,
                std::shared_ptr<RrFstreamProxy> file_engrams,
                std::shared_ptr<RrFstreamProxy> file_index);

    // Factory constructor: creates proxy instances internally (OS-appropriate based on build config)
    static std::unique_ptr<EngramCache> create(const std::string& engram_file,
                                                const std::string& index_file);

    ~EngramCache() = default;

    EngramCache(const EngramCache&) = delete;
    EngramCache& operator=(const EngramCache&) = delete;

    // Get engram from cache or disk. Returns nullptr if not found.
    rr_emod_types::Engram* get(const rr_emod_types::EngramID& id);

    // Add engram to cache. Never evicts, signals capacity state instead.
    void add(rr_emod_types::Engram&& engram);

    // Check current cache utilization.
    // Capacity check: call capacity_state() before/after consolidation
    rr_emod_types::CapacityState capacity_state() const;

    // Check if cache is empty.
    bool empty() const;

    // Find engram closest to query vector (searches all engrams in index).
    // Lazy-loads from disk if needed. Skips dormant engrams based on decay threshold.
    // current_session: session counter from XLSTMMemory for decay calculations
    rr_emod_types::Engram* find_closest(const Eigen::VectorXf& query, std::uint64_t current_session);

    // Load index from disk (call at boot).
    void load_index();

    // Persist all cached engrams and index to disk. Fire-and-forget, non-blocking.
    void persist();

    // Serialize engram to bytes for writing to disk.
    static std::vector<std::byte> serialize(const rr_emod_types::Engram& engram);

    // Deserialize bytes to engram.
    static rr_emod_types::Engram deserialize(const std::vector<std::byte>& bytes);

    size_t get_serialized_size() const;

    // Read-only view of the resident engrams (the in-memory working set: this
    // session's promoted + retrieved engrams). Used by consolidation to walk the
    // set that gets written to the training TFRecord.
    const std::unordered_map<rr_emod_types::EngramID, rr_emod_types::Engram>& entries() const {
        return cache_;
    }

    // Reset: clear engram_map for next session, reset access_count in all engrams
    void reset();

private:
    struct EngramMetadata {
        bool loaded = false;
        uint64_t access_count = 0;
    };

    std::unordered_map<rr_emod_types::EngramID, rr_emod_types::Engram> cache_;
    std::unordered_map<rr_emod_types::EngramID, rr_emod_types::IndexEntry> index_;
    std::unordered_map<rr_emod_types::EngramID, EngramMetadata> metadata_;

    std::shared_ptr<RrFstreamProxy> file_engrams_;
    std::shared_ptr<RrFstreamProxy> file_index_;
    std::string engram_file_path_;
    std::string index_file_path_;

    size_t max_cache_size_;

    size_t compute_max_cache_size() const;

    rr_emod_types::Engram lazy_load_from_disk(const rr_emod_types::EngramID& id);

    void persist_index();
};

}  // namespace rr_emod_serde
