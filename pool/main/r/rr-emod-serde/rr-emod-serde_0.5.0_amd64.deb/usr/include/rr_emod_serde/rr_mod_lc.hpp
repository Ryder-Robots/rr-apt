// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once
#include <cstdint>
#include <memory>
#include "rr_emod_serde/rr_emod_types.hpp"

namespace rr_emod_lc
{

using DiagnosticState = rr_emod_types::DiagnosticState;  // Return type for all lifecycle methods
using State = rr_emod_types::State;                      // Shared eModule state — held as shared_ptr

/**
 * Abstract lifecycle interface for eModule components.
 *
 * Mirrors the ROS2 managed node lifecycle (configure → activate → deactivate → cleanup)
 * adapted for the eModule context. All methods receive shared ownership of State so that
 * the cognitive loop, SalienceSampler, and persistence layer operate on the same instance.
 *
 * All methods return DiagnosticState. On anything other than OK the caller is responsible
 * for deciding whether to retry, deactivate, or escalate to FUBAR.
 */
class RrModLc
{
public:
  virtual ~RrModLc() = default;

  /**
   * Initialise the component.
   *
   * Called once before activation. Implementations should load configuration, initialise
   * the EP from training data, and prepare any resources needed for activation. State is
   * populated here but the cognitive loop does not start yet.
   */
  virtual DiagnosticState on_configure() = 0;

  /**
   * Start the component.
   *
   * Called after a successful on_configure. The cognitive loop begins — engrams are
   * restored from disk if they exist, the queue starts processing, and the eModule is
   * ready to receive input. If no engrams exist on disk the EP fires immediately.
   */
  virtual DiagnosticState on_activate() = 0;

  /**
   * Pause the component.
   *
   * Queue processing stops and the current engram is preserved in State. The component
   * can be re-activated without reconfiguring. Resources are held — this is a pause,
   * not a teardown.
   */
  virtual DiagnosticState on_deactivate() = 0;

  /**
   * Release resources after deactivation.
   *
   * Called after on_deactivate. Flushes the queue to disk, releases held resources,
   * and returns the component to a pre-configure state. State is left intact so that
   * a subsequent on_configure can restore from it if needed.
   */
  virtual DiagnosticState on_cleanup() = 0;

  virtual DiagnosticState on_shutdown() = 0;
};

}  // namespace rr_emod_lc