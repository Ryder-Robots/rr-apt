// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ryder Robots
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
#ifndef RR_EMOD_SERDE_RR_CORTEX_SOCKET_LOCAL_HPP
#define RR_EMOD_SERDE_RR_CORTEX_SOCKET_LOCAL_HPP

// The in-process implementation of RrCortexSocket — the §4 parity rig's socket
// layer, and the shape the gRPC one has to fit.
//
// THE STATE MACHINE IS NOT HERE ANY MORE (2026-08-02). bound -> listening ->
// connected, the role gates, the claim and the one-peer grant all moved to
// RrCortexSocketBase, which owns the four verbs as `final`. What is left below
// is exactly what "in process" means and nothing else: the peer is a weak_ptr
// rather than a stub, the dial is a registry lookup rather than a TCP connect,
// and a send runs the far handler INLINE on the caller's thread.
//
// What is still NOT real is the parking: do_await_dial() grants immediately
// rather than waiting for a dialer.
//
// THIS SOCKET IS POINT-TO-POINT. Fan-out lives in the SET of sockets a supervisor
// holds, never inside one — a cortex has one server socket plus clients to MEMORY
// and FRONTAL, and the output mask picks among sockets, not among peers within a
// socket. That is why peer_ is a single weak_ptr and not a container.

#include <memory>
#include <mutex>
#include <optional>

#include <rr_emod_serde/rr_cortex_socket_base.hpp>

namespace rr_emod_serde {

class RrLogger;
class RrRendezvous;

class RrCortexSocketLocal : public RrCortexSocketBase {
public:
    // Forwards to the base, the way a derived rclcpp LifecycleNode forwards its
    // node name and options. The collaborators are not members of this class to
    // assign — they are a base to construct, so a transport cannot come up with
    // no registry wired.
    explicit RrCortexSocketLocal(std::weak_ptr<RrRendezvous> rendezvous, RrLogger& logger)
        : RrCortexSocketBase(std::move(rendezvous), logger) {}

    // The SYN's arrival, server side. In process there is no wire to demux, so
    // the dialer hands it over directly; remotely gRPC's service handler plays
    // this part — a different signature over the same grant(), which is why this
    // is a plain method and not a hook.
    //
    // Take mtx_, call the base's grant(), and on acceptance record `dialer` as
    // peer_. Do NOT write connected_ (private in the base, so this path and
    // accept() cannot grant by two different rules) and do NOT lock back into
    // the dialer — this runs with the DIALER's mtx_ held, and reciprocal locking
    // is a two-socket deadlock that only appears under a simultaneous dial.
    rr_conn::OpenChannelAck submit(const rr_conn::OpenChannel& syn,
                                   std::weak_ptr<RrCortexSocketLocal> dialer);

protected:
    const char* tag() const noexcept override { return "RrCortexSocketLocal"; }

    rr_conn::ConnStatus do_await_dial(std::unique_lock<std::mutex>& lk,
                                      rr_conn::OpenChannel& syn) override;
    rr_conn::ConnStatus do_dial(const RrSockOpts& opts) override;

    // In process the far end is a pointer away, so "deliver" is a call: reach
    // the peer and run ITS handler on our thread. The answer comes straight back
    // as a return value — there is no reply address to record and therefore none
    // to get wrong, which is what keeps a many-peer service from crossing two
    // cortexes' answers.
    rr_conn::ConnStatus do_deliver(const rr_inference::CortexEnvelope& msg,
                                   std::optional<rr_inference::CortexEnvelope>& reply) override;

private:
    // shared_from_this() now yields the BASE: exactly one enable_shared_from_this
    // may sit in the hierarchy, and two would make the call ambiguous with one
    // weak reference left unset. submit() wants the derived type, and this object
    // IS one, so the downcast is sound and costs nothing.
    std::weak_ptr<RrCortexSocketLocal> weak_self();

    // WEAK by design: the far supervisor can tear down at any time, and a dead
    // peer must surface as a silent no-op rather than a use-after-free. Guarded
    // by the base's mtx_.
    std::weak_ptr<RrCortexSocketLocal> peer_;
};

}  // namespace rr_emod_serde

#endif  // RR_EMOD_SERDE_RR_CORTEX_SOCKET_LOCAL_HPP
